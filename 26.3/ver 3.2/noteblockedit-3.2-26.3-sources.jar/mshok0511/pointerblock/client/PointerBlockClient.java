package mshok0511.pointerblock.client;

import mshok0511.pointerblock.client.network.PointerClientPacket;
import net.fabricmc.api.ClientModInitializer;

public class PointerBlockClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        PointerClientPacket.register();
    }
}