package mshok0511.pointerblock.client.screen;

import mshok0511.pointerblock.network.PointerPackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;

public class PointerBlockScreen extends Screen {
    private final BlockPos blockPos;
    private final String initialName;
    private final BlockPos initialTargetPos;

    private EditBox nameField;
    private EditBox xField, yField, zField;
    private Direction currentFacing;

    public PointerBlockScreen(BlockPos pos, String name, BlockPos targetPos, int facingIndex) {
        super(Component.literal("Pointer Settings"));
        this.blockPos = pos;
        this.initialName = name;
        this.initialTargetPos = targetPos;
        this.currentFacing = Direction.from2DDataValue(facingIndex);
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;

        this.nameField = new EditBox(this.font, centerX - 100, 45, 200, 20, Component.empty());
        this.nameField.setValue(initialName);
        // ASCIIのみ許可
        this.nameField.setResponder(text -> {
            // ASCII 以外の文字が含まれていたら除去してセットし直す
            if (!text.matches("^[\\x00-\\x7F]*$")) {
                String filtered = text.replaceAll("[^\\x00-\\x7F]", "");
                this.nameField.setValue(filtered);
            }
        });
        this.addRenderableWidget(this.nameField);

        this.xField = new EditBox(this.font, centerX - 100, 85, 60, 20, Component.empty());
        this.yField = new EditBox(this.font, centerX - 30, 85, 60, 20, Component.empty());
        this.zField = new EditBox(this.font, centerX + 40, 85, 60, 20, Component.empty());

        // 数字のみ許可（負の数可）
        this.xField.setResponder(text -> filterNumberInput(this.xField, text));
        this.yField.setResponder(text -> filterNumberInput(this.yField, text));
        this.zField.setResponder(text -> filterNumberInput(this.zField, text));

        this.xField.setValue(String.valueOf(initialTargetPos.getX()));
        this.yField.setValue(String.valueOf(initialTargetPos.getY()));
        this.zField.setValue(String.valueOf(initialTargetPos.getZ()));

        this.addRenderableWidget(this.xField);
        this.addRenderableWidget(this.yField);
        this.addRenderableWidget(this.zField);

        Button facingButton = Button.builder(Component.literal("向き: " + currentFacing.getName().toUpperCase()), button -> {
            this.currentFacing = this.currentFacing.getClockWise();
            button.setMessage(Component.literal("向き: " + currentFacing.getName().toUpperCase()));
        }).bounds(centerX - 100, 125, 200, 20).build();
        this.addRenderableWidget(facingButton);

        this.addRenderableWidget(Button.builder(Component.literal("完了"), b -> saveAndClose()).bounds(centerX - 105, 160, 100, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("キャンセル"), b -> this.onClose()).bounds(centerX + 5, 160, 100, 20).build());
    }

    // 数値以外の入力を弾くヘルパーメソッド
    private void filterNumberInput(EditBox box, String text) {
        if (!text.matches("^-?\\d*$")) {
            String filtered = text.replaceAll("[^-\\d]", "");
            // 先頭以外の '-' を除去
            if (filtered.indexOf('-') > 0) {
                filtered = filtered.replace("-", "");
            }
            box.setValue(filtered);
        }
    }

    private void saveAndClose() {
        try {
            int tx = Integer.parseInt(xField.getValue());
            int ty = Integer.parseInt(yField.getValue());
            int tz = Integer.parseInt(zField.getValue());
            BlockPos targetPos = new BlockPos(tx, ty, tz);
            ClientPlayNetworking.send(new PointerPackets.SavePointerDataPayload(blockPos, nameField.getValue(), targetPos, currentFacing.get2DDataValue()));
            this.onClose();
        } catch (NumberFormatException e) {
            this.onClose();
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);
        int centerX = this.width / 2;
        context.centeredText(this.font, this.title, centerX, 10, 0xFFFFFFFF);
        context.text(this.font, "ポインター名称:", centerX - 100, 32, 0xFFA0A0A0);
        context.text(this.font, "ターゲット座標 (X/Y/Z):", centerX - 100, 72, 0xFFA0A0A0);
        context.text(this.font, "ポインターの向き:", centerX - 100, 112, 0xFFA0A0A0);
    }
}