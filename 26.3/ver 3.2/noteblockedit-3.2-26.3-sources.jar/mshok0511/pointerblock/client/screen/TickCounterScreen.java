package mshok0511.pointerblock.client.screen;

import mshok0511.pointerblock.network.PointerPackets;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

@Environment(EnvType.CLIENT)
public class TickCounterScreen extends Screen {
    private final BlockPos pos;
    private final int currentDelay;
    private EditBox delayField;

    public TickCounterScreen(BlockPos pos, int currentDelay) {
        super(Component.literal("ティックカウンター設定"));
        this.pos = pos;
        this.currentDelay = currentDelay;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        // 左右矢印ボタン
        this.addRenderableWidget(Button.builder(Component.literal("<"), b -> changeDelay(-1))
                .bounds(centerX - 100, centerY - 18, 20, 20).build());

        this.delayField = new EditBox(this.font, centerX - 75, centerY - 18, 150, 20, Component.empty());
        this.delayField.setValue(String.valueOf(this.currentDelay));
        this.delayField.setMaxLength(5);
        this.delayField.setResponder(text -> {
            if (!text.matches("^\\d*$")) {
                this.delayField.setValue(text.replaceAll("[^\\d]", ""));
            }
        });
        this.addRenderableWidget(this.delayField);

        this.addRenderableWidget(Button.builder(Component.literal(">"), b -> changeDelay(1))
                .bounds(centerX + 80, centerY - 18, 20, 20).build());

        // 下部ボタン (完了 / キャンセル)
        this.addRenderableWidget(Button.builder(Component.literal("完了"), button -> saveAndClose())
                .bounds(centerX - 100, centerY + 20, 95, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("キャンセル"), button -> this.onClose())
                .bounds(centerX + 5, centerY + 20, 95, 20).build());
    }

    private void changeDelay(int delta) {
        int val = 0;
        try {
            String text = this.delayField.getValue().trim();
            if (!text.isEmpty()) {
                val = Integer.parseInt(text);
            }
        } catch (NumberFormatException ignored) {
        }
        val += delta;
        if (val < 0) val = 0;
        if (val > 8) val = 8;
        this.delayField.setValue(String.valueOf(val));
    }

    private void saveAndClose() {
        try {
            int delay = Integer.parseInt(this.delayField.getValue().trim());
            if (delay < 0) delay = 0;
            if (delay > 8) delay = 8;
            ClientPlayNetworking.send(new PointerPackets.SaveTickCounterPayload(this.pos, delay));
        } catch (NumberFormatException ignored) {
        }
        this.onClose();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        context.centeredText(this.font, this.title, centerX, centerY - 50, 0xFFFFFFFF);
        context.text(this.font, "遅延時間 (0 ~ 8 ティック):", centerX - 100, centerY - 32, 0xFFA0A0A0);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}