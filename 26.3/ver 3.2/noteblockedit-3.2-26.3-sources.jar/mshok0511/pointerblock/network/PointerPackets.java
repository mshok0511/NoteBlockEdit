package mshok0511.pointerblock.network;

import mshok0511.pointerblock.PointerBlockMod;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public class PointerPackets {

    // 1. Save Pointer Data (C2S)
    public record SavePointerDataPayload(BlockPos pos, String name, BlockPos targetPos, int facingIndex) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<SavePointerDataPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(PointerBlockMod.MOD_ID, "save_pointer_data"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SavePointerDataPayload> CODEC = StreamCodec.composite(
                BlockPos.STREAM_CODEC, SavePointerDataPayload::pos,
                ByteBufCodecs.STRING_UTF8, SavePointerDataPayload::name,
                BlockPos.STREAM_CODEC, SavePointerDataPayload::targetPos,
                ByteBufCodecs.INT, SavePointerDataPayload::facingIndex,
                SavePointerDataPayload::new
        );

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // 2. Open Pointer Screen (S2C)
    public record OpenPointerScreenPayload(BlockPos pos, String currentName, BlockPos targetPos, int facingIndex) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<OpenPointerScreenPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(PointerBlockMod.MOD_ID, "open_pointer_screen"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenPointerScreenPayload> CODEC = StreamCodec.composite(
                BlockPos.STREAM_CODEC, OpenPointerScreenPayload::pos,
                ByteBufCodecs.STRING_UTF8, OpenPointerScreenPayload::currentName,
                BlockPos.STREAM_CODEC, OpenPointerScreenPayload::targetPos,
                ByteBufCodecs.INT, OpenPointerScreenPayload::facingIndex,
                OpenPointerScreenPayload::new
        );

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // 3. Sync Settings (S2C)
    public record SyncSettingsPayload(boolean transparency) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<SyncSettingsPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(PointerBlockMod.MOD_ID, "sync_settings"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SyncSettingsPayload> CODEC = StreamCodec.composite(
                ByteBufCodecs.BOOL, SyncSettingsPayload::transparency,
                SyncSettingsPayload::new
        );

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // 4. Open Tick Counter (S2C)
    public record OpenTickCounterPayload(BlockPos pos, int currentDelay) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<OpenTickCounterPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(PointerBlockMod.MOD_ID, "open_tick_counter"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenTickCounterPayload> CODEC = StreamCodec.composite(
                BlockPos.STREAM_CODEC, OpenTickCounterPayload::pos,
                ByteBufCodecs.INT, OpenTickCounterPayload::currentDelay,
                OpenTickCounterPayload::new
        );

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // 5. Save Tick Counter (C2S)
    public record SaveTickCounterPayload(BlockPos pos, int delay) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<SaveTickCounterPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(PointerBlockMod.MOD_ID, "save_tick_counter"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SaveTickCounterPayload> CODEC = StreamCodec.composite(
                BlockPos.STREAM_CODEC, SaveTickCounterPayload::pos,
                ByteBufCodecs.INT, SaveTickCounterPayload::delay,
                SaveTickCounterPayload::new
        );

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public static void registerPackets() {
        PayloadTypeRegistry.serverboundPlay().register(SavePointerDataPayload.TYPE, SavePointerDataPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(OpenPointerScreenPayload.TYPE, OpenPointerScreenPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(SyncSettingsPayload.TYPE, SyncSettingsPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(OpenTickCounterPayload.TYPE, OpenTickCounterPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(SaveTickCounterPayload.TYPE, SaveTickCounterPayload.CODEC);
    }
}