package mshok0511.pointerblock.block;

import mshok0511.pointerblock.PointerBlockMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PointerBlockEntity extends BlockEntity {
    public static final Map<BlockPos, PointerBlockEntity> TRACKED_POINTERS = new ConcurrentHashMap<>();

    private String pointerName;
    private BlockPos targetPos;

    public PointerBlockEntity(BlockPos pos, BlockState state) {
        super(PointerBlockMod.POINTER_BLOCK_ENTITY_TYPE, pos, state);
        this.targetPos = pos;
        this.pointerName = pos.getX() + "," + pos.getY() + "," + pos.getZ();
        TRACKED_POINTERS.put(pos.immutable(), this);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);

        // getStringOr(キー名, デフォルト値) を使用
        String defaultName = this.worldPosition.getX() + "," + this.worldPosition.getY() + "," + this.worldPosition.getZ();
        this.pointerName = input.getStringOr("PointerName", defaultName);

        // getLongOr(キー名, デフォルト値) を使用
        this.targetPos = BlockPos.of(input.getLongOr("TargetPos", this.worldPosition.asLong()));

        TRACKED_POINTERS.put(this.worldPosition.immutable(), this);
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        output.putString("PointerName", this.pointerName);
        output.putLong("TargetPos", this.targetPos.asLong());
        super.saveAdditional(output);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider provider) {
        return super.getUpdateTag(provider);
    }

    public String getPointerName() {
        return pointerName;
    }

    public void setPointerName(String name) {
        this.pointerName = name;
        setChanged();
        sync();
    }

    public BlockPos getTargetPos() {
        return targetPos;
    }

    public void setTargetPos(BlockPos pos) {
        this.targetPos = pos;
        setChanged();
        sync();
    }

    private void sync() {
        if (this.level != null && !this.level.isClientSide()) {
            this.level.sendBlockUpdated(this.worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        TRACKED_POINTERS.remove(this.worldPosition);
    }
}