package mshok0511.pointerblock.block;

import mshok0511.pointerblock.PointerBlockMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

public class TickCounterBlockEntity extends BlockEntity {
    private int delay = 0;

    public TickCounterBlockEntity(BlockPos pos, BlockState state) {
        super(PointerBlockMod.TICK_COUNTER_BLOCK_ENTITY_TYPE, pos, state);
    }

    public int getDelay() { return delay; }
    public void setDelay(int delay) {
        this.delay = Math.max(0, Math.min(8, delay));
        setChanged();
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        this.delay = input.getIntOr("Delay", 0);
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        output.putInt("Delay", delay);
        super.saveAdditional(output);
    }
}