package mshok0511.pointerblock.util;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import mshok0511.pointerblock.PointerBlockMod;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

public class PointerState extends SavedData {
    public static boolean transparency = false;

    // Codec 用のゲッター/セッターアクセス構造
    public PointerState() {
    }

    public PointerState(boolean transparency) {
        PointerState.transparency = transparency;
    }

    public boolean isTransparency() {
        return transparency;
    }

    // 1. Codec の定義 (boolean フィールド "transparency" をシリアライズ)
    public static final Codec<PointerState> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    Codec.BOOL.optionalFieldOf("transparency", false).forGetter(PointerState::isTransparency)
            ).apply(instance, PointerState::new)
    );

    // 2. SavedDataType の定義
    public static final SavedDataType<PointerState> TYPE = new SavedDataType<>(
            Identifier.fromNamespaceAndPath(PointerBlockMod.MOD_ID, "pointer_block_data"), // 保存キー ID
            PointerState::new,                                                              // コンスタラクタ
            CODEC,                                                                          // Codec
            DataFixTypes.SAVED_DATA_COMMAND_STORAGE                                         // DataFixer 用タイプ
    );

    public static PointerState getServerState(MinecraftServer server) {
        ServerLevel level = server.getLevel(Level.OVERWORLD);
        if (level == null) return null;

        // 26.3 仕様: SavedDataType を渡して取得または生成
        return level.getDataStorage().computeIfAbsent(TYPE);
    }

    public static void markDirty(MinecraftServer server) {
        PointerState state = getServerState(server);
        if (state != null) {
            state.setDirty();
        }
    }
}