package mshok0511.pointerblock.command;

import mshok0511.pointerblock.PointerBlockMod;
import mshok0511.pointerblock.util.PointerDataManager;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class PointerPlayRunner {

    private static class PendingPlayTask {
        final ServerPlayer player;
        final ServerLevel world;
        final String pointerName;
        final BlockPos pPos;
        final Direction facing;
        int elapsedTicks = 0;

        PendingPlayTask(ServerPlayer player, ServerLevel world, String pointerName, BlockPos pPos, Direction facing) {
            this.player = player;
            this.world = world;
            this.pointerName = pointerName;
            this.pPos = pPos;
            this.facing = facing;
        }
    }

    private static final List<PendingPlayTask> pendingTasks = new ArrayList<>();
    private static boolean registered = false;

    public static void registerTickEvent() {
        if (!registered) {
            ServerTickEvents.END_SERVER_TICK.register(PointerPlayRunner::tick);
            registered = true;
        }
    }

    /**
     * 指定されたポインター名称からテレポートを行い、周囲4チャンクの読み込み完了を確認後にティックカウンターを実行します。
     */
    public static int execute(ServerPlayer player, MinecraftServer server, String pointerName) {
        registerTickEvent();

        // 1. JSONからポインターのデータを取得
        Map<String, int[]> allPointers = PointerDataManager.getWorldPointers(server);
        if (!allPointers.containsKey(pointerName)) return -1; // ポインター名が見つからない場合

        int[] pData = allPointers.get(pointerName);
        BlockPos pPos = new BlockPos(pData[0], pData[1], pData[2]);
        int facingIndex = pData[3];
        Direction facing = Direction.from2DDataValue(facingIndex);
        ServerLevel world = player.level();

        // 2. ポインター位置へテレポート
        TeleportTransition transition = new TeleportTransition(
                world,
                new Vec3(pPos.getX() + 0.5, pPos.getY() + 1.0, pPos.getZ() + 0.5),
                Vec3.ZERO,
                player.getYRot(),
                player.getXRot(),
                TeleportTransition.DO_NOTHING
        );
        player.teleport(transition);

        // 開始メッセージの送信
        player.sendSystemMessage(Component.literal("§aポインター「" + pointerName + "」へテレポートしました。周囲チャンクの読み込みを確認中..."));

        // 3. チャンクロード監視タスクをキューに追加
        pendingTasks.add(new PendingPlayTask(player, world, pointerName, pPos, facing));
        return 0; // 正常に処理開始
    }

    private static void tick(MinecraftServer server) {
        if (pendingTasks.isEmpty()) return;

        Iterator<PendingPlayTask> iterator = pendingTasks.iterator();
        while (iterator.hasNext()) {
            PendingPlayTask task = iterator.next();
            task.elapsedTicks++;

            // テレポート先周囲4チャンクの読み込み確認 (中心±4チャンク)
            if (areSurroundingChunksLoaded(task.world, task.pPos, 4)) {
                // 周囲4チャンク読み込み完了 -> タイムラグカウント（scheduleTick）開始
                int count = triggerTickCounters(task.world, task.pPos, task.facing, server);
                if (task.player != null && !task.player.hasDisconnected()) {
                    task.player.sendSystemMessage(Component.literal("§aポインター「" + task.pointerName + "」を実行しました。(対象: " + count + "個)"));
                }
                iterator.remove();
            } else if (task.elapsedTicks > 200) { // 10秒 (200 ticks) 超過
                if (task.player != null && !task.player.hasDisconnected()) {
                    task.player.sendSystemMessage(Component.literal("§c[NBE] 座標周囲4チャンクの読み込み時間が10秒を超えたため、ポインターの実行を中止しました。"));
                }
                iterator.remove();
            }
        }
    }

    private static boolean areSurroundingChunksLoaded(ServerLevel world, BlockPos pos, int radius) {
        int centerChunkX = pos.getX() >> 4;
        int centerChunkZ = pos.getZ() >> 4;

        for (int cx = centerChunkX - radius; cx <= centerChunkX + radius; cx++) {
            for (int cz = centerChunkZ - radius; cz <= centerChunkZ + radius; cz++) {
                if (!world.getChunkSource().hasChunk(cx, cz)) {
                    return false;
                }
            }
        }
        return true;
    }

    private static int triggerTickCounters(ServerLevel world, BlockPos pPos, Direction facing, MinecraftServer server) {
        Map<String, int[]> allTickCounters = PointerDataManager.getWorldTickCounters(server);
        int foundCount = 0;

        for (int[] tData : allTickCounters.values()) {
            int tx = tData[0];
            int ty = tData[1];
            int tz = tData[2];
            int delay = tData[3];

            boolean isInArea = false;
            boolean yInRange = (ty >= pPos.getY() - 55 && ty <= pPos.getY() + 55);

            if (facing == Direction.EAST || facing == Direction.WEST) {
                boolean xMatch = (tx == pPos.getX());
                boolean zInRange = (tz >= pPos.getZ() - 55 && tz <= pPos.getZ() + 55);
                if (xMatch && yInRange && zInRange) isInArea = true;
            } else {
                boolean zMatch = (tz == pPos.getZ());
                boolean xInRange = (tx >= pPos.getX() - 55 && tx <= pPos.getX() + 55);
                if (zMatch && yInRange && xInRange) isInArea = true;
            }

            if (isInArea) {
                BlockPos targetPos = new BlockPos(tx, ty, tz);
                world.getChunk(targetPos);
                BlockState tState = world.getBlockState(targetPos);

                if (tState.is(PointerBlockMod.TICK_COUNTER_BLOCK)) {
                    int totalDelay = 8 + delay;
                    world.scheduleTick(targetPos, tState.getBlock(), totalDelay);
                    foundCount++;
                }
            }
        }
        return foundCount;
    }
}