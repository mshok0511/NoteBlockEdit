package mshok0511.pointerblock.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import mshok0511.noteblockedit.util.ModulationHistoryManager;
import mshok0511.pointerblock.PointerBlockMod;
import mshok0511.pointerblock.block.TickCounterBlockEntity;
import mshok0511.pointerblock.network.PointerPackets;
import mshok0511.pointerblock.util.PointerDataManager;
import mshok0511.pointerblock.util.PointerState;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

public class NbeCommands {
    private static final SuggestionProvider<CommandSourceStack> SUGGESTION_PROVIDER = (context, builder) -> SharedSuggestionProvider.suggest(PointerDataManager.getWorldPointers(context.getSource().getServer()).keySet(), builder);

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(literal("nbe")
                .then(literal("getPointerBlock").executes(context -> giveItem(context.getSource(), new ItemStack(PointerBlockMod.POINTER_BLOCK_ITEM))))
                .then(literal("getTickCounterBlock").executes(context -> giveItem(context.getSource(), new ItemStack(PointerBlockMod.TICK_COUNTER_ITEM))))

                .then(literal("pointerTeleport").then(argument("name", StringArgumentType.string()).suggests(SUGGESTION_PROVIDER).executes(context -> {
                    String name = StringArgumentType.getString(context, "name");
                    Map<String, int[]> pointers = PointerDataManager.getWorldPointers(context.getSource().getServer());
                    ServerPlayer player = context.getSource().getPlayer();
                    if (pointers.containsKey(name) && player != null) {
                        int[] d = pointers.get(name);
                        TeleportTransition transition = new TeleportTransition(
                                (ServerLevel) player.level(),
                                new Vec3(d[0] + 0.5, d[1] + 1.0, d[2] + 0.5),
                                Vec3.ZERO,
                                player.getYRot(),
                                player.getXRot(),
                                TeleportTransition.DO_NOTHING
                        );
                        player.teleport(transition);
                        return 1;
                    }
                    context.getSource().sendFailure(Component.literal("ポインターが見つかりません: " + name));
                    return 0;
                })))

                .then(literal("pointerPlay").then(argument("name", StringArgumentType.string()).suggests(SUGGESTION_PROVIDER).executes(context -> {
                    String name = StringArgumentType.getString(context, "name");
                    ServerPlayer player = context.getSource().getPlayer();
                    if (player != null) {
                        int result = PointerPlayRunner.execute(player, context.getSource().getServer(), name);
                        if (result < 0) {
                            context.getSource().sendFailure(Component.literal("ポインターが見つかりません: " + name));
                            return 0;
                        }
                        return 1;
                    }
                    return 0;
                })))

                .then(literal("pointerTransparency").then(argument("value", BoolArgumentType.bool()).executes(context -> {
                    PointerState.transparency = BoolArgumentType.getBool(context, "value");
                    PointerState.markDirty(context.getSource().getServer());
                    syncTransparency(context.getSource());
                    return 1;
                })))

                .then(literal("pointerList").executes(context -> {
                    Map<String, int[]> pointers = PointerDataManager.getWorldPointers(context.getSource().getServer());
                    context.getSource().sendSuccess(() -> Component.literal("§6--- ポインター一覧 ---"), false);
                    for (Map.Entry<String, int[]> entry : pointers.entrySet()) {
                        int[] val = entry.getValue();
                        context.getSource().sendSuccess(() -> Component.literal("§e- " + entry.getKey() + " §7(X:" + val[0] + " Y:" + val[1] + " Z:" + val[2] + ")"), false);
                    }
                    return 1;
                }))

                .then(literal("tickCounterBlockCopy").then(argument("name", StringArgumentType.string()).suggests(SUGGESTION_PROVIDER).executes(context -> {
                    String name = StringArgumentType.getString(context, "name");
                    Map<String, int[]> pointers = PointerDataManager.getWorldPointers(context.getSource().getServer());
                    if (!pointers.containsKey(name)) {
                        context.getSource().sendFailure(Component.literal("ポインターが見つかりません: " + name));
                        return 0;
                    }
                    int[] pData = pointers.get(name);
                    BlockPos pPos = new BlockPos(pData[0], pData[1], pData[2]);
                    Direction facing = Direction.from2DDataValue(pData[3]);

                    Map<String, int[]> allTickCounters = PointerDataManager.getWorldTickCounters(context.getSource().getServer());
                    List<PointerDataManager.TickCounterClipboardEntry> newClipboard = new ArrayList<>();

                    for (int[] tData : allTickCounters.values()) {
                        int tx = tData[0];
                        int ty = tData[1];
                        int tz = tData[2];
                        int delay = tData[3];

                        if (isInArea(pPos, facing, tx, ty, tz)) {
                            int hOffset = getHorizontalOffset(pPos, facing, tx, tz);
                            int vOffset = ty - pPos.getY();
                            newClipboard.add(new PointerDataManager.TickCounterClipboardEntry(hOffset, vOffset, delay));
                        }
                    }

                    PointerDataManager.setClipboard(newClipboard);
                    context.getSource().sendSuccess(() -> Component.literal("§aコピー完了 (" + newClipboard.size() + "個)"), false);
                    return 1;
                })))

                .then(literal("tickCounterBlockPaste").then(argument("name", StringArgumentType.string()).suggests(SUGGESTION_PROVIDER).executes(context -> {
                    String name = StringArgumentType.getString(context, "name");
                    Map<String, int[]> pointers = PointerDataManager.getWorldPointers(context.getSource().getServer());
                    if (!pointers.containsKey(name)) {
                        context.getSource().sendFailure(Component.literal("ポインターが見つかりません: " + name));
                        return 0;
                    }

                    List<PointerDataManager.TickCounterClipboardEntry> clipboard = PointerDataManager.getClipboard();
                    if (clipboard.isEmpty()) {
                        context.getSource().sendFailure(Component.literal("クリップボードが空です"));
                        return 0;
                    }

                    int[] pData = pointers.get(name);
                    BlockPos pPos = new BlockPos(pData[0], pData[1], pData[2]);
                    Direction facing = Direction.from2DDataValue(pData[3]);
                    ServerLevel world = context.getSource().getLevel();

                    List<ModulationHistoryManager.BlockChange> changes = new ArrayList<>();
                    int count = 0;
                    for (PointerDataManager.TickCounterClipboardEntry entry : clipboard) {
                        BlockPos targetPos = getRelativePosFromOffset(pPos, facing, entry.horizontalOffset, entry.verticalOffset);
                        world.getChunk(targetPos);
                        BlockState oldState = world.getBlockState(targetPos);
                        int oldDelay = -1;
                        if (world.getBlockEntity(targetPos) instanceof TickCounterBlockEntity tbe) {
                            oldDelay = tbe.getDelay();
                        }

                        world.setBlock(targetPos, PointerBlockMod.TICK_COUNTER_BLOCK.defaultBlockState(), 3);

                        if (world.getBlockEntity(targetPos) instanceof TickCounterBlockEntity tbe) {
                            tbe.setDelay(entry.delay);
                        }
                        PointerDataManager.addTickCounter(context.getSource().getServer(), targetPos, entry.delay);

                        BlockState newState = world.getBlockState(targetPos);
                        changes.add(new ModulationHistoryManager.BlockChange(targetPos, oldState, newState, oldDelay, entry.delay));
                        count++;
                    }

                    ServerPlayer player = context.getSource().getPlayer();
                    if (player != null && !changes.isEmpty()) {
                        ModulationHistoryManager.pushHistory(player.getUUID(), changes);
                    }

                    int finalCount = count;
                    context.getSource().sendSuccess(() -> Component.literal("§aペースト完了 (" + finalCount + "個)"), false);
                    return 1;
                })))
        );
    }

    private static void syncTransparency(CommandSourceStack source) {
        for (ServerPlayer player : source.getServer().getPlayerList().getPlayers()) {
            ServerPlayNetworking.send(player, new PointerPackets.SyncSettingsPayload(PointerState.transparency));
        }
    }

    private static int giveItem(CommandSourceStack source, ItemStack stack) {
        ServerPlayer player = source.getPlayer();
        if (player == null) return 0;

        if (!player.getInventory().add(stack)) {
            if (player.getOffhandItem().isEmpty()) {
                player.setItemInHand(InteractionHand.OFF_HAND, stack);
            } else {
                source.sendFailure(Component.literal("§cホットバーとオフハンドが埋まっています。"));
                return 0;
            }
        }
        return 1;
    }

    private static boolean isInArea(BlockPos pPos, Direction facing, int tx, int ty, int tz) {
        boolean yInRange = (ty >= pPos.getY() - 55 && ty <= pPos.getY() + 55);
        if (facing == Direction.EAST || facing == Direction.WEST) {
            return (tx == pPos.getX()) && yInRange && (tz >= pPos.getZ() - 55 && tz <= pPos.getZ() + 55);
        } else {
            return (tz == pPos.getZ()) && yInRange && (tx >= pPos.getX() - 55 && tx <= pPos.getX() + 55);
        }
    }

    private static int getHorizontalOffset(BlockPos pPos, Direction facing, int tx, int tz) {
        return switch (facing) {
            case EAST -> tz - pPos.getZ();
            case WEST -> pPos.getZ() - tz;
            case SOUTH -> pPos.getX() - tx;
            case NORTH -> tx - pPos.getX();
            default -> 0;
        };
    }

    private static BlockPos getRelativePosFromOffset(BlockPos pPos, Direction facing, int hOffset, int vOffset) {
        int targetY = pPos.getY() + vOffset;
        return switch (facing) {
            case EAST -> new BlockPos(pPos.getX(), targetY, pPos.getZ() + hOffset);
            case WEST -> new BlockPos(pPos.getX(), targetY, pPos.getZ() - hOffset);
            case SOUTH -> new BlockPos(pPos.getX() - hOffset, targetY, pPos.getZ());
            case NORTH -> new BlockPos(pPos.getX() + hOffset, targetY, pPos.getZ());
            default -> pPos;
        };
    }
}