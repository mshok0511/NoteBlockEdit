package mshok0511.pointerblock;

import mshok0511.pointerblock.block.PointerBlock;
import mshok0511.pointerblock.block.PointerBlockEntity;
import mshok0511.pointerblock.block.TickCounterBlock;
import mshok0511.pointerblock.block.TickCounterBlockEntity;
import mshok0511.pointerblock.command.NbeCommands;
import mshok0511.pointerblock.network.PointerPackets;
import mshok0511.pointerblock.util.PointerDataManager;
import mshok0511.pointerblock.util.PointerState;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Set;

public class PointerBlockMod implements ModInitializer {
    public static final String MOD_ID = "noteblockedit";

    // Block 用の Properties 生成ヘルパー
    private static BlockBehaviour.Properties createBlockProperties(String path) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, Identifier.fromNamespaceAndPath(MOD_ID, path));
        return BlockBehaviour.Properties.of().setId(key).noOcclusion().strength(1.5f);
    }

    // Item 用の Properties 生成ヘルパー（ResourceKey<Item> を埋め込む）
    private static Item.Properties createItemProperties(String path) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, path));
        return new Item.Properties().setId(key);
    }

    public static final Block POINTER_BLOCK = Registry.register(
            BuiltInRegistries.BLOCK,
            Identifier.fromNamespaceAndPath(MOD_ID, "pointer_block"),
            new PointerBlock(createBlockProperties("pointer_block"))
    );

    public static final Block TICK_COUNTER_BLOCK = Registry.register(
            BuiltInRegistries.BLOCK,
            Identifier.fromNamespaceAndPath(MOD_ID, "tick_counter_block"),
            new TickCounterBlock(createBlockProperties("tick_counter_block"))
    );

    public static final BlockItem POINTER_BLOCK_ITEM = Registry.register(
            BuiltInRegistries.ITEM,
            Identifier.fromNamespaceAndPath(MOD_ID, "pointer_block"),
            new BlockItem(POINTER_BLOCK, createItemProperties("pointer_block"))
    );

    public static final BlockItem TICK_COUNTER_ITEM = Registry.register(
            BuiltInRegistries.ITEM,
            Identifier.fromNamespaceAndPath(MOD_ID, "tick_counter_block"),
            new BlockItem(TICK_COUNTER_BLOCK, createItemProperties("tick_counter_block"))
    );

    public static final BlockEntityType<PointerBlockEntity> POINTER_BLOCK_ENTITY_TYPE = Registry.register(
            BuiltInRegistries.BLOCK_ENTITY_TYPE,
            Identifier.fromNamespaceAndPath(MOD_ID, "pointer_block_entity"),
            new BlockEntityType<>(PointerBlockEntity::new, Set.of(POINTER_BLOCK))
    );

    public static final BlockEntityType<TickCounterBlockEntity> TICK_COUNTER_BLOCK_ENTITY_TYPE = Registry.register(
            BuiltInRegistries.BLOCK_ENTITY_TYPE,
            Identifier.fromNamespaceAndPath(MOD_ID, "tick_counter_entity"),
            new BlockEntityType<>(TickCounterBlockEntity::new, Set.of(TICK_COUNTER_BLOCK))
    );

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> PointerDataManager.loadAll());
        ServerLifecycleEvents.SERVER_STARTED.register(PointerState::getServerState);
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> NbeCommands.register(dispatcher));

        // パケット（CustomPayload & Codec）の登録
        PointerPackets.registerPackets();

        // サーバー側パケットレシーバー
        ServerPlayNetworking.registerGlobalReceiver(PointerPackets.SavePointerDataPayload.TYPE, (payload, context) -> {
            BlockPos pos = payload.pos();
            String name = payload.name();
            BlockPos targetPos = payload.targetPos();
            int facingIndex = payload.facingIndex();

            context.server().execute(() -> {
                if (PointerDataManager.isNameDuplicate(context.server(), name, pos)) {
                    context.player().sendSystemMessage(Component.literal("§cエラー: 「" + name + "」は既に他のポインターで使用されています。"));
                    return;
                }
                Level world = context.player().level();
                if (world.getBlockEntity(pos) instanceof PointerBlockEntity pbe) {
                    pbe.setPointerName(name);
                    pbe.setTargetPos(targetPos);
                    pbe.setChanged();
                    BlockState state = world.getBlockState(pos);
                    if (state.hasProperty(PointerBlock.FACING)) {
                        Direction newFacing = Direction.from2DDataValue(facingIndex);
                        world.setBlock(pos, state.setValue(PointerBlock.FACING, newFacing), 3);
                        PointerDataManager.addPointer(context.server(), pos, name, facingIndex);
                    }
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(PointerPackets.SaveTickCounterPayload.TYPE, (payload, context) -> {
            BlockPos pos = payload.pos();
            int delay = payload.delay();
            context.server().execute(() -> {
                if (context.player().level().getBlockEntity(pos) instanceof TickCounterBlockEntity tbe) {
                    tbe.setDelay(delay);
                    PointerDataManager.addTickCounter(context.server(), pos, delay);
                }
            });
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayNetworking.send(handler.player, new PointerPackets.SyncSettingsPayload(PointerState.transparency));
        });
    }
}