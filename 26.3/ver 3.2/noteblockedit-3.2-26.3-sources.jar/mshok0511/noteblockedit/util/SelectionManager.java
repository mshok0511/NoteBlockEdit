package mshok0511.noteblockedit.util;

import mshok0511.noteblockedit.network.NbeNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SelectionManager {
    private static final Map<UUID, BlockPos> pos1 = new HashMap<>();
    private static final Map<UUID, BlockPos> pos2 = new HashMap<>();

    // プレイヤーエンティティを受け取るように変更（同期のため）
    public static void setPos1(ServerPlayer player, BlockPos pos) {
        pos1.put(player.getUUID(), pos);
        // 要件1: クライアントに通知して枠を表示させる
        syncToClient(player);
    }

    public static void setPos2(ServerPlayer player, BlockPos pos) {
        pos2.put(player.getUUID(), pos);
        // 要件1: クライアントに通知して枠を表示させる
        syncToClient(player);
    }

    public static BlockPos getPos1(UUID player) { return pos1.get(player); }
    public static BlockPos getPos2(UUID player) { return pos2.get(player); }

    public static void clear(ServerPlayer player) {
        pos1.remove(player.getUUID());
        pos2.remove(player.getUUID());
        syncToClient(player);
    }

    private static void syncToClient(ServerPlayer player) {
        BlockPos p1 = pos1.get(player.getUUID());
        BlockPos p2 = pos2.get(player.getUUID());
        // ネットワーク経由でクライアント側の ClientSelectionManager を更新する
        NbeNetworking.sendSelectionS2C(player, p1, p2);
    }
}