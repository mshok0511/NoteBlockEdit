package mshok0511.noteblockedit.util;

import mshok0511.pointerblock.PointerBlockMod;
import mshok0511.pointerblock.block.TickCounterBlockEntity;
import mshok0511.pointerblock.util.PointerDataManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.state.BlockState;

import java.util.*;

public class ModulationHistoryManager {
    // 1つの操作による全ブロック変更の記録 (TickCounterBlockなどの遅延保持対応)
    public record BlockChange(BlockPos pos, BlockState oldState, BlockState newState, int oldDelay, int newDelay) {
        public BlockChange(BlockPos pos, BlockState oldState, BlockState newState) {
            this(pos, oldState, newState, -1, -1);
        }
    }

    // プレイヤーUUIDごとのUndo/Redoスタック
    private static final Map<UUID, Deque<List<BlockChange>>> undoStacks = new HashMap<>();
    private static final Map<UUID, Deque<List<BlockChange>>> redoStacks = new HashMap<>();

    private static final int MAX_HISTORY = 20; // 履歴の最大保持数

    public static void pushHistory(UUID uuid, List<BlockChange> changes) {
        undoStacks.computeIfAbsent(uuid, k -> new ArrayDeque<>()).push(changes);
        if (undoStacks.get(uuid).size() > MAX_HISTORY) undoStacks.get(uuid).removeLast();
        redoStacks.remove(uuid); // 新しい操作をしたらRedo履歴は消去
    }

    public static int undo(ServerPlayer player, int amount) {
        Deque<List<BlockChange>> stack = undoStacks.get(player.getUUID());
        if (stack == null || stack.isEmpty()) return -1;

        int count = 0;
        for (int i = 0; i < amount && !stack.isEmpty(); i++) {
            List<BlockChange> changes = stack.pop();
            // 戻す前に現在の状態をRedo用に保存
            redoStacks.computeIfAbsent(player.getUUID(), k -> new ArrayDeque<>()).push(changes);

            // ブロックを古い状態に戻す
            for (BlockChange change : changes) {
                player.level().setBlock(change.pos(), change.oldState(), 3);
                if (change.oldState().is(PointerBlockMod.TICK_COUNTER_BLOCK)) {
                    if (player.level().getBlockEntity(change.pos()) instanceof TickCounterBlockEntity tbe) {
                        if (change.oldDelay() >= 0) {
                            tbe.setDelay(change.oldDelay());
                        }
                    }
                    player.level();
                    PointerDataManager.addTickCounter(player.level().getServer(), change.pos(), Math.max(0, change.oldDelay()));
                } else {
                    player.level();
                    PointerDataManager.removeTickCounter(player.level().getServer(), change.pos());
                }
            }
            count++;
        }
        return count;
    }

    public static int redo(ServerPlayer player, int amount) {
        Deque<List<BlockChange>> stack = redoStacks.get(player.getUUID());
        if (stack == null || stack.isEmpty()) return -1;

        int count = 0;
        for (int i = 0; i < amount && !stack.isEmpty(); i++) {
            List<BlockChange> changes = stack.pop();
            undoStacks.computeIfAbsent(player.getUUID(), k -> new ArrayDeque<>()).push(changes);

            // ブロックを新しい状態にする
            for (BlockChange change : changes) {
                player.level().setBlock(change.pos(), change.newState(), 3);
                if (change.newState().is(PointerBlockMod.TICK_COUNTER_BLOCK)) {
                    if (player.level().getBlockEntity(change.pos()) instanceof TickCounterBlockEntity tbe) {
                        if (change.newDelay() >= 0) {
                            tbe.setDelay(change.newDelay());
                        }
                    }
                    player.level();
                    PointerDataManager.addTickCounter(player.level().getServer(), change.pos(), Math.max(0, change.newDelay()));
                } else {
                    player.level();
                    PointerDataManager.removeTickCounter(player.level().getServer(), change.pos());
                }
            }
            count++;
        }
        return count;
    }
}