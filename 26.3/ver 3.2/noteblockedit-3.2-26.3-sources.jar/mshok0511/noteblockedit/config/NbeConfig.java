package mshok0511.noteblockedit.config;

import java.util.*;

public class NbeConfig {
    // 最大3つのキーを組み合わせ可能にするためのキーリスト設定
    public List<String> openGuiKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.alt", "key.keyboard.c"));
    public List<String> resetKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.shift", "key.keyboard.r"));

    // 旧設定との互換性保持用フィールド
    public String openGuiKey = null;
    public String resetKey = null;

    public Map<String, List<String>> instrumentSets = new LinkedHashMap<>();

    // 音源一覧タブ用パス設定
    public String resourcePackPath = "";
    public String noteBetterConfigPath = "";

    public NbeConfig() {
        // デフォルト設定
        instrumentSets.put("Harp", new ArrayList<>(Arrays.asList(
                "minecraft:diamond_ore", "minecraft:barrier", "minecraft:diamond_block"
        )));
    }

    /**
     * 旧設定フォーマットからの自動移行処理
     */
    public void migrateOldConfig() {
        if (openGuiKey != null && !openGuiKey.isEmpty()) {
            openGuiKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.alt", openGuiKey));
            openGuiKey = null;
        }
        if (resetKey != null && !resetKey.isEmpty()) {
            resetKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.shift", resetKey));
            resetKey = null;
        }
        if (resourcePackPath == null) resourcePackPath = "";
        if (noteBetterConfigPath == null) noteBetterConfigPath = "";
    }
}
