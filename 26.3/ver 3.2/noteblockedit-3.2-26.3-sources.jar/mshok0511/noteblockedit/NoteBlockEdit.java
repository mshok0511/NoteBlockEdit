package mshok0511.noteblockedit;

import mshok0511.noteblockedit.command.NbeCommand;
import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.network.NbeNetworking;
import mshok0511.noteblockedit.util.SelectionManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;

public class NoteBlockEdit implements ModInitializer {
    public static final String MOD_ID = "noteblockedit";

    @Override
    public void onInitialize() {
        ConfigManager.load();
        NbeNetworking.registerServerReceivers();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> NbeCommand.register(dispatcher));

        // 1. 左クリック時：木の剣で破壊検知して復元
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (!world.isClientSide() && isHoldingWoodenSword(player) && hand == InteractionHand.MAIN_HAND) {
                BlockState originalState = world.getBlockState(pos);
                SelectionManager.setPos1((ServerPlayer) player, pos);
                player.sendOverlayMessage(Component.literal("§c[NBE] Start (赤) をセットしました"));

                // 復元処理 (UPDATE_CLIENTS | UPDATE_KNOWN_SHAPE 相当のフラグ 34 を指定)
                world.setBlock(pos, originalState, 34);
                return InteractionResult.FAIL;
            }
            return InteractionResult.PASS;
        });

        // 2. 右クリック時：木の剣で変更検知して復元
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.isClientSide() && isHoldingWoodenSword(player) && hand == InteractionHand.MAIN_HAND) {
                BlockPos pos = hitResult.getBlockPos();
                BlockState originalState = world.getBlockState(pos);
                SelectionManager.setPos2((ServerPlayer) player, pos);
                player.sendOverlayMessage(Component.literal("§a[NBE] Goal (緑) をセットしました"));

                // 復元処理
                world.setBlock(pos, originalState, 34);
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });
    }

    private boolean isHoldingWoodenSword(Player player) {
        // 木の剣に固定
        return player.getItemInHand(InteractionHand.MAIN_HAND).is(Items.WOODEN_SWORD);
    }
}