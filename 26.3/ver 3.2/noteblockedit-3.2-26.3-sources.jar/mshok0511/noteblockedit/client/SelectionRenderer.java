package mshok0511.noteblockedit.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.util.ARGB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class SelectionRenderer {

    public static void renderCustomSelections(CameraRenderState cameraState, SubmitNodeCollector consumers) {
        BlockPos p1 = ClientSelectionManager.getPos1();
        BlockPos p2 = ClientSelectionManager.getPos2();
        if ((p1 == null && p2 == null) || consumers == null || cameraState == null) return;

        Vec3 cameraPos = cameraState.pos;
        PoseStack poseStack = new PoseStack();

        // 1. Start地点 (赤色)
        if (p1 != null) {
            renderBoxOutline(poseStack, consumers, cameraPos, p1, p1, ARGB.color(255, 255, 0, 0));
        }

        // 2. Goal地点 (黄緑色)
        if (p2 != null) {
            renderBoxOutline(poseStack, consumers, cameraPos, p2, p2, ARGB.color(255, 153, 255, 0));
        }

        // 3. 全体範囲 (水色)
        if (p1 != null && p2 != null) {
            renderBoxOutline(poseStack, consumers, cameraPos, p1, p2, ARGB.color(255, 0, 255, 255));
        }
    }

    private static void renderBoxOutline(PoseStack poseStack, SubmitNodeCollector consumers, Vec3 cameraPos, BlockPos pos1, BlockPos pos2, int color) {
        int minX = Math.min(pos1.getX(), pos2.getX());
        int minY = Math.min(pos1.getY(), pos2.getY());
        int minZ = Math.min(pos1.getZ(), pos2.getZ());

        int maxX = Math.max(pos1.getX(), pos2.getX()) + 1;
        int maxY = Math.max(pos1.getY(), pos2.getY()) + 1;
        int maxZ = Math.max(pos1.getZ(), pos2.getZ()) + 1;

        double offset = 0.002;

        double x1 = (minX - cameraPos.x) - offset;
        double y1 = (minY - cameraPos.y) - offset;
        double z1 = (minZ - cameraPos.z) - offset;
        double x2 = (maxX - cameraPos.x) + offset;
        double y2 = (maxY - cameraPos.y) + offset;
        double z2 = (maxZ - cameraPos.z) + offset;

        // 指定した範囲の VoxelShape (ボックス形状) を生成
        VoxelShape boxShape = Shapes.create(x1, y1, z1, x2, y2, z2);

        // バニラ標準の submitShapeOutline メソッドで描画を依頼 (線幅: 2.0f, 地形の後ろにも適用)
        consumers.submitShapeOutline(
                poseStack,
                boxShape,
                RenderTypes.lines(),
                color,
                2.0f,
                false
        );
    }
}