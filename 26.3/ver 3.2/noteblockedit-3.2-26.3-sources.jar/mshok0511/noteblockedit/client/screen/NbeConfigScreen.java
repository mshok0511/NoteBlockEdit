package mshok0511.noteblockedit.client.screen;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.InputConstants;
import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.config.NbeConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import org.lwjgl.sdl.SDLKeycode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.text.Collator;
import java.util.*;

public class NbeConfigScreen extends Screen {
    private static final Logger LOGGER = LoggerFactory.getLogger("NoteBlockEdit");
    private final Screen parent;

    private int currentTab = 0;

    private Button openGuiKeyBtn;
    private Button resetKeyBtn;
    private List<String> tempOpenGuiKeys = new ArrayList<>();
    private List<String> tempResetKeys = new ArrayList<>();
    private String waitingForKeyFor = null;

    private EditBox groupNameField;
    private final List<String> sortedGroupNames = new ArrayList<>();
    private int currentGroupIndex = 0;
    private final List<String> currentBlocks = new ArrayList<>();

    public enum SortMode {
        REGISTER("登録順"),
        NAME("名称順");
        final String label;
        SortMode(String label) { this.label = label; }
    }

    public enum SortOrder {
        ASC("低い順"),
        DESC("高い順");
        final String label;
        SortOrder(String label) { this.label = label; }
    }

    private SortMode currentSortMode = SortMode.REGISTER;
    private SortOrder currentSortOrder = SortOrder.ASC;

    private Button sortModeBtn;
    private Button sortOrderBtn;

    private EditBox rpPathField;
    private EditBox nbPathField;
    private EditBox soundNameField;
    private EditBox volumeField;
    private EditBox pitchField;
    private EditBox soundsPathField;

    private Button soundPathBrowseBtn;
    private Button addSoundBtn;
    private Button deleteSoundBtn;

    private final List<NoteBetterMapping> soundMappings = new ArrayList<>();
    private int selectedSoundIndex = -1;
    private int soundListScrollOffset = 0;
    private int groupListScrollOffset = 0;
    private boolean soundTabValid = false;

    private Component statusMessage = Component.empty();

    public static class NoteBetterConfig {
        public List<NoteBetterMapping> mappings = new ArrayList<>();
    }

    public static class NoteBetterMapping {
        public String block = "";
        public NoteBetterSound sound = new NoteBetterSound();
    }

    public static class NoteBetterSound {
        public String sound = "";
        public double volume = 3.0;
        public double pitch = 1.0;
    }

    public NbeConfigScreen(Screen parent) {
        super(Component.literal("NoteBlockEdit Config"));
        this.parent = parent;
        ConfigManager.load();
        NbeConfig config = ConfigManager.getConfig();
        if (config.openGuiKeys != null) this.tempOpenGuiKeys.addAll(config.openGuiKeys);
        if (config.resetKeys != null) this.tempResetKeys.addAll(config.resetKeys);
    }

    @Override
    protected void init() {
        this.clearWidgets();
        NbeConfig config = ConfigManager.getConfig();
        int centerX = this.width / 2;

        this.addRenderableWidget(Button.builder(
                Component.literal(currentTab == 0 ? "§a[ ショートカット設定 ]" : "ショートカット設定"),
                b -> switchTab(0)
        ).bounds(centerX - 180, 22, 115, 20).build());

        this.addRenderableWidget(Button.builder(
                Component.literal(currentTab == 1 ? "§a[ 楽器グループ設定 ]" : "楽器グループ設定"),
                b -> switchTab(1)
        ).bounds(centerX - 60, 22, 115, 20).build());

        this.addRenderableWidget(Button.builder(
                Component.literal(currentTab == 2 ? "§a[ 音源一覧 ]" : "音源一覧"),
                b -> switchTab(2)
        ).bounds(centerX + 60, 22, 115, 20).build());

        if (currentTab == 0) {
            initTab0(centerX);
        } else if (currentTab == 1) {
            initTab1(centerX, config);
        } else if (currentTab == 2) {
            initTab2(centerX, config);
        }

        this.addRenderableWidget(Button.builder(Component.literal("保存する"), b -> saveConfig())
                .bounds(centerX - 100, 210, 60, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("保存して閉じる"), b -> {
            saveConfig();
            closeScreen();
        }).bounds(centerX - 35, 210, 80, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("キャンセル"), b -> {
            ConfigManager.load();
            closeScreen();
        }).bounds(centerX + 50, 210, 50, 20).build());
    }

    private void switchTab(int targetTab) {
        if (currentTab == 1) saveCurrentGroupToMemory();
        if (currentTab == 2) {
            saveCurrentSoundEdits(); // ★タブ移動前に書き込み
            onSoundTabPathsChanged();
        }
        currentTab = targetTab;
        init();
    }

    private void initTab0(int centerX) {
        this.openGuiKeyBtn = this.addRenderableWidget(Button.builder(getFriendlyKeyName("open", tempOpenGuiKeys), button -> {
            this.waitingForKeyFor = "open";
            this.tempOpenGuiKeys.clear();
            updateButtonLabels();
        }).bounds(centerX - 100, 75, 200, 20).build());

        this.resetKeyBtn = this.addRenderableWidget(Button.builder(getFriendlyKeyName("reset", tempResetKeys), button -> {
            this.waitingForKeyFor = "reset";
            this.tempResetKeys.clear();
            updateButtonLabels();
        }).bounds(centerX - 100, 115, 200, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("キーをリセット (GUI)"), b -> {
            tempOpenGuiKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.alt", "key.keyboard.c"));
            updateButtonLabels();
        }).bounds(centerX - 100, 145, 95, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("キーをリセット (範囲)"), b -> {
            tempResetKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.shift", "key.keyboard.r"));
            updateButtonLabels();
        }).bounds(centerX + 5, 145, 95, 20).build());
    }

    private void initTab1(int centerX, NbeConfig config) {
        if (config.instrumentSets.isEmpty()) {
            config.instrumentSets.put("Harp", new ArrayList<>());
        }

        this.sortModeBtn = this.addRenderableWidget(Button.builder(
                Component.literal("並び: " + currentSortMode.label), b -> toggleSortMode()
        ).bounds(centerX - 180, 63, 80, 18).build());

        this.sortOrderBtn = this.addRenderableWidget(Button.builder(
                Component.literal("順序: " + currentSortOrder.label), b -> toggleSortOrder()
        ).bounds(centerX - 95, 63, 80, 18).build());

        refreshSortedGroupList(null);

        this.groupNameField = new EditBox(this.font, centerX + 10, 75, 110, 18, Component.empty());
        this.addRenderableWidget(this.groupNameField);

        this.addRenderableWidget(Button.builder(Component.literal("ブロックを追加..."), b -> {
            if (this.minecraft != null) {
                // 画面遷移前に現在の選択状態・入力内容をメモリに確実に保存
                saveCurrentGroupToMemory();

                // 現在選択されているグループ名を保持しておく
                String selectedGroupName = getCurrentSelectedGroupName();

                this.minecraft.setScreenAndShow(new NbeItemSelectorScreen(this, (newIds) -> {
                    // 現在選択中のグループ名でソート・インデックスを再同期
                    refreshSortedGroupList(selectedGroupName);
                    updateGroupFields();

                    // 選択中のグループのリスト（currentBlocks）にブロックを追加
                    this.currentBlocks.addAll(newIds);

                    // 変更内容をメモリ（Config）へ保存し、UI表示を更新
                    saveCurrentGroupToMemory();
                    updateGroupFields();
                }));
            }
        }).bounds(centerX + 10, 145, 80, 18).build());

        this.addRenderableWidget(Button.builder(Component.literal("リストを空にする"), b -> {
            currentBlocks.clear();
            saveCurrentGroupToMemory();
        }).bounds(centerX + 95, 145, 80, 18).build());

        this.addRenderableWidget(Button.builder(Component.literal("グループ追加"), b -> addGroup())
                .bounds(centerX + 10, 168, 80, 18).build());
        this.addRenderableWidget(Button.builder(Component.literal("グループ削除"), b -> removeGroup())
                .bounds(centerX + 95, 168, 80, 18).build());

        updateGroupFields();
    }

    private void initTab2(int centerX, NbeConfig config) {
        this.rpPathField = new EditBox(this.font, centerX - 30, 48, 195, 18, Component.empty());
        this.rpPathField.setMaxLength(500);
        this.rpPathField.setValue(config.resourcePackPath != null ? config.resourcePackPath : "");
        this.rpPathField.setResponder(s -> onSoundTabPathsChanged());
        this.addRenderableWidget(this.rpPathField);

        this.nbPathField = new EditBox(this.font, centerX - 30, 70, 195, 18, Component.empty());
        this.nbPathField.setMaxLength(500);
        this.nbPathField.setValue(config.noteBetterConfigPath != null ? config.noteBetterConfigPath : "");
        this.nbPathField.setResponder(s -> onSoundTabPathsChanged());
        this.addRenderableWidget(this.nbPathField);

        this.soundNameField = new EditBox(this.font, centerX + 70, 106, 120, 16, Component.empty());
        this.addRenderableWidget(this.soundNameField);

        this.volumeField = new EditBox(this.font, centerX + 70, 126, 120, 16, Component.empty());
        this.addRenderableWidget(this.volumeField);

        this.pitchField = new EditBox(this.font, centerX + 70, 146, 120, 16, Component.empty());
        this.addRenderableWidget(this.pitchField);

        this.soundsPathField = new EditBox(this.font, centerX + 70, 166, 80, 16, Component.empty());
        this.addRenderableWidget(this.soundsPathField);

        this.soundPathBrowseBtn = this.addRenderableWidget(Button.builder(Component.literal("参照..."), b -> {
            String initialDir = getBaseGameDir();
            if (!config.resourcePackPath.isEmpty()) {
                String rpFolderName = config.resourcePackPath.trim().replace("\"", "");
                initialDir = getBaseGameDir() + "/resourcepacks/" + rpFolderName + "/assets/minecraft/sounds";
            }

            // 非同期でOSネイティブのファイル選択ダイアログを開く
            openNativeFileDialogAsync("音源 (.ogg) ファイルを選択", initialDir, file -> {
                if (file != null && !file.isEmpty()) {
                    // UI（テキストボックス）の更新は必ずマイクラのメインスレッドに戻して実行する
                    if (this.minecraft != null) {
                        this.minecraft.execute(() -> {
                            String safeFile = file.replace("\\", "/");
                            String rpFolderName = config.resourcePackPath.trim().replace("\"", "");
                            String soundsBase = getBaseGameDir().replace("\\", "/") + "/resourcepacks/" + rpFolderName + "/assets/minecraft/sounds/";

                            if (safeFile.startsWith(soundsBase)) {
                                this.soundsPathField.setValue(safeFile.substring(soundsBase.length()));
                            } else {
                                File f = new File(safeFile);
                                this.soundsPathField.setValue(f.getName());
                            }
                        });
                    }
                }
            });
        }).bounds(centerX + 153, 166, 38, 16).build());

        this.addSoundBtn = this.addRenderableWidget(Button.builder(Component.literal("追加"), b -> {
            onSoundTabPathsChanged();
            if (this.minecraft != null) {
                this.minecraft.setScreenAndShow(new NbeSoundAddScreen(this));
            }
        }).bounds(centerX + 5, 185, 55, 18).build());

        this.deleteSoundBtn = this.addRenderableWidget(Button.builder(Component.literal("削除"), b -> confirmDeleteSelectedSoundEntry())
                .bounds(centerX + 65, 185, 55, 18).build());

        onSoundTabPathsChanged();
    }

    private String getBaseGameDir() {
        if (this.minecraft != null && this.minecraft.gameDirectory != null) {
            return this.minecraft.gameDirectory.getAbsolutePath().replace("\\", "/");
        }
        return new File(".").getAbsolutePath().replace("\\", "/");
    }

    public boolean isSoundTabPathsValid() {
        if (rpPathField == null || nbPathField == null) return false;
        String rpFolderName = rpPathField.getValue().trim().replace("\"", "");
        String nbFileName = nbPathField.getValue().trim().replace("\"", "");

        if (rpFolderName.isEmpty() || nbFileName.isEmpty()) return false;

        String baseDir = getBaseGameDir();
        File soundsJson = new File(baseDir + "/resourcepacks/" + rpFolderName + "/assets/minecraft/sounds.json");
        File nbJson = new File(baseDir + "/config/" + nbFileName);

        return soundsJson.exists() && nbJson.exists() && nbJson.isFile();
    }

    public void onSoundTabPathsChanged() {
        if (rpPathField == null || nbPathField == null) return;
        NbeConfig config = ConfigManager.getConfig();
        config.resourcePackPath = rpPathField.getValue().trim().replace("\"", "");
        config.noteBetterConfigPath = nbPathField.getValue().trim().replace("\"", "");

        soundTabValid = isSoundTabPathsValid();

        boolean detailEditable = soundTabValid && selectedSoundIndex >= 0;
        if (soundNameField != null) soundNameField.setEditable(detailEditable);
        if (volumeField != null) volumeField.setEditable(detailEditable);
        if (pitchField != null) pitchField.setEditable(detailEditable);
        if (soundsPathField != null) soundsPathField.setEditable(detailEditable);

        if (soundPathBrowseBtn != null) soundPathBrowseBtn.active = detailEditable;
        if (addSoundBtn != null) addSoundBtn.active = soundTabValid;
        if (deleteSoundBtn != null) deleteSoundBtn.active = soundTabValid && selectedSoundIndex >= 0;

        if (soundTabValid) {
            loadNoteBetterConfig();
        } else {
            soundMappings.clear();
            selectedSoundIndex = -1;
            selectSoundEntry(-1);
        }
    }

    public void loadNoteBetterConfig() {
        soundMappings.clear();
        selectedSoundIndex = -1;

        NbeConfig config = ConfigManager.getConfig();
        String nbFileName = config.noteBetterConfigPath.trim().replace("\"", "");
        if (nbFileName.isEmpty()) return;

        File nbFile = new File(getBaseGameDir() + "/config/" + nbFileName);
        if (!nbFile.exists() || !nbFile.isFile()) return;

        Gson gson = new Gson();
        try (Reader reader = new FileReader(nbFile)) {
            NoteBetterConfig cfg = gson.fromJson(reader, NoteBetterConfig.class);
            if (cfg != null && cfg.mappings != null) {
                soundMappings.addAll(cfg.mappings);
            }
        } catch (Exception e) {
            LOGGER.warn("[NBE] notebetterfabric.json の読込に失敗しました: ", e);
        }

        if (selectedSoundIndex >= soundMappings.size()) {
            selectedSoundIndex = -1;
        }
        selectSoundEntry(selectedSoundIndex);
    }

    public String resolveSoundsPath(String fullSoundName) {
        if (fullSoundName == null || fullSoundName.isEmpty()) return "";
        String rawName = fullSoundName.startsWith("minecraft:") ? fullSoundName.substring(10) : fullSoundName;

        NbeConfig config = ConfigManager.getConfig();
        String rpFolderName = config.resourcePackPath.trim().replace("\"", "");
        if (rpFolderName.isEmpty()) return rawName + ".ogg";

        String rpPath = getBaseGameDir() + "/resourcepacks/" + rpFolderName;
        File soundsJsonFile = new File(rpPath, "assets/minecraft/sounds.json");
        if (soundsJsonFile.exists() && soundsJsonFile.isFile()) {
            try (Reader reader = new FileReader(soundsJsonFile)) {
                JsonElement rootElem = JsonParser.parseReader(reader);
                if (rootElem != null && rootElem.isJsonObject()) {
                    JsonObject rootObj = rootElem.getAsJsonObject();

                    JsonObject soundEventObj = null;
                    if (rootObj.has(rawName)) {
                        soundEventObj = rootObj.getAsJsonObject(rawName);
                    } else if (rootObj.has("minecraft:" + rawName)) {
                        soundEventObj = rootObj.getAsJsonObject("minecraft:" + rawName);
                    }

                    if (soundEventObj != null && soundEventObj.has("sounds")) {
                        JsonElement soundsElem = soundEventObj.get("sounds");
                        if (soundsElem != null && soundsElem.isJsonArray()) {
                            JsonArray soundsArray = soundsElem.getAsJsonArray();
                            if (!soundsArray.isEmpty()) {
                                JsonElement firstElem = soundsArray.get(0);
                                String soundPathStr = null;
                                if (firstElem.isJsonPrimitive()) {
                                    soundPathStr = firstElem.getAsString();
                                } else if (firstElem.isJsonObject()) {
                                    JsonObject sObj = firstElem.getAsJsonObject();
                                    if (sObj.has("name")) {
                                        soundPathStr = sObj.get("name").getAsString();
                                    }
                                }

                                if (soundPathStr != null && !soundPathStr.isEmpty()) {
                                    if (!soundPathStr.endsWith(".ogg")) {
                                        soundPathStr += ".ogg";
                                    }
                                    return soundPathStr;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                LOGGER.warn("[NBE] sounds.json の解析に失敗しました: ", e);
            }
        }

        File soundsDir = new File(rpPath, "assets/minecraft/sounds");
        if (soundsDir.exists() && soundsDir.isDirectory()) {
            File foundFile = findOggFileRecursive(soundsDir, rawName + ".ogg");
            if (foundFile != null) {
                try {
                    return soundsDir.toPath().relativize(foundFile.toPath()).toString().replace("\\", "/");
                } catch (Exception ignored) {}
            }
        }

        return rawName + ".ogg";
    }

    private File findOggFileRecursive(File dir, String filename) {
        File[] files = dir.listFiles();
        if (files == null) return null;
        for (File f : files) {
            if (f.isDirectory()) {
                File sub = findOggFileRecursive(f, filename);
                if (sub != null) return sub;
            } else if (f.isFile() && f.getName().equalsIgnoreCase(filename)) {
                return f;
            }
        }
        return null;
    }

    private void selectSoundEntry(int index) {
        if (index < 0 || index >= soundMappings.size()) {
            selectedSoundIndex = -1;
            if (soundNameField != null) soundNameField.setValue("");
            if (volumeField != null) volumeField.setValue("3.0");
            if (pitchField != null) pitchField.setValue("1.0");
            if (soundsPathField != null) soundsPathField.setValue("");

            // 選択解除時は詳細設定項目・ボタンを非アクティブ化
            if (soundNameField != null) soundNameField.setEditable(false);
            if (volumeField != null) volumeField.setEditable(false);
            if (pitchField != null) pitchField.setEditable(false);
            if (soundsPathField != null) soundsPathField.setEditable(false);
            if (soundPathBrowseBtn != null) soundPathBrowseBtn.active = false;
            if (deleteSoundBtn != null) deleteSoundBtn.active = false;
            return;
        }

        selectedSoundIndex = index;
        // 項目選択時は有効なパス条件のもとでアクティブ化
        boolean detailEditable = soundTabValid;
        if (soundNameField != null) soundNameField.setEditable(detailEditable);
        if (volumeField != null) volumeField.setEditable(detailEditable);
        if (pitchField != null) pitchField.setEditable(detailEditable);
        if (soundsPathField != null) soundsPathField.setEditable(detailEditable);
        if (soundPathBrowseBtn != null) soundPathBrowseBtn.active = detailEditable;
        if (deleteSoundBtn != null) deleteSoundBtn.active = detailEditable;

        NoteBetterMapping mapping = soundMappings.get(index);
        String sndName = (mapping.sound != null && mapping.sound.sound != null) ? mapping.sound.sound : "";
        String cleanName = sndName.startsWith("minecraft:") ? sndName.substring(10) : sndName;

        if (soundNameField != null) soundNameField.setValue(cleanName);
        if (volumeField != null) volumeField.setValue(String.valueOf(mapping.sound != null ? mapping.sound.volume : 3.0));
        if (pitchField != null) pitchField.setValue(String.valueOf(mapping.sound != null ? mapping.sound.pitch : 1.0));

        String resolvedPath = resolveSoundsPath(sndName);
        if (soundsPathField != null) soundsPathField.setValue(resolvedPath);
    }

    private void confirmDeleteSelectedSoundEntry() {
        if (selectedSoundIndex < 0 || selectedSoundIndex >= soundMappings.size()) return;

        if (this.minecraft != null) {
            this.minecraft.setScreenAndShow(new ConfirmScreen(
                    result -> {
                        if (result) {
                            deleteSelectedSoundEntry();
                        }
                        this.minecraft.setScreenAndShow(this);
                    },
                    Component.literal("音源の削除"),
                    Component.literal("本当に削除しますか？\nsounds.jsonとnotebetterfabric.jsonに記述した内容と\n保存された.oggファイルも完全に削除されます。")
            ));
        }
    }

    private void deleteSelectedSoundEntry() {
        if (selectedSoundIndex < 0 || selectedSoundIndex >= soundMappings.size()) return;

        NoteBetterMapping mappingToRemove = soundMappings.get(selectedSoundIndex);
        String soundName = (mappingToRemove.sound != null && mappingToRemove.sound.sound != null) ? mappingToRemove.sound.sound : "";
        String soundKey = soundName.replace("minecraft:", "");

        soundMappings.remove(selectedSoundIndex);
        selectedSoundIndex = -1;
        selectSoundEntry(-1);

        NbeConfig config = ConfigManager.getConfig();

        if (config.resourcePackPath != null && !config.resourcePackPath.isEmpty()) {
            String rpPath = getBaseGameDir() + "/resourcepacks/" + config.resourcePackPath.trim().replace("\"", "");
            File soundsJsonFile = new File(rpPath, "assets/minecraft/sounds.json");
            if (soundsJsonFile.exists()) {
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                JsonObject soundsObj = new JsonObject();
                try (Reader reader = new FileReader(soundsJsonFile)) {
                    JsonObject loaded = JsonParser.parseReader(reader).getAsJsonObject();
                    if (loaded != null) {
                        soundsObj = loaded;
                    }
                } catch (Exception ignored) {}

                if (soundsObj.has(soundKey)) {
                    JsonObject entry = soundsObj.getAsJsonObject(soundKey);
                    if (entry.has("sounds")) {
                        JsonArray soundsArray = entry.getAsJsonArray("sounds");
                        for (JsonElement el : soundsArray) {
                            String path = "";
                            if (el.isJsonPrimitive()) {
                                path = el.getAsString();
                            } else if (el.isJsonObject() && el.getAsJsonObject().has("name")) {
                                path = el.getAsJsonObject().get("name").getAsString();
                            }

                            if (!path.isEmpty()) {
                                File oggFile = new File(rpPath, "assets/minecraft/sounds/" + path + ".ogg");
                                if (oggFile.exists()) {
                                    boolean ignored = oggFile.delete();
                                }
                            }
                        }
                    }
                    soundsObj.remove(soundKey);

                    try (Writer writer = new FileWriter(soundsJsonFile)) {
                        gson.toJson(soundsObj, writer);
                    } catch (IOException ignored) {}
                }
            }
        }

        String nbFileName = config.noteBetterConfigPath != null ? config.noteBetterConfigPath.trim().replace("\"", "") : "";
        if (!nbFileName.isEmpty()) {
            File configFile = new File(getBaseGameDir() + "/config/" + nbFileName);
            NoteBetterConfig cfg = new NoteBetterConfig();
            cfg.mappings = soundMappings;

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            try (Writer writer = new FileWriter(configFile)) {
                gson.toJson(cfg, writer);
                statusMessage = Component.literal("§a選択された音源を完全に削除しました。");
            } catch (IOException e) {
                statusMessage = Component.literal("§cJSONファイルの保存に失敗しました。");
            }
        }
    }

    private void toggleSortMode() {
        saveCurrentGroupToMemory();
        String currentSelected = getCurrentSelectedGroupName();
        currentSortMode = (currentSortMode == SortMode.REGISTER) ? SortMode.NAME : SortMode.REGISTER;
        if (sortModeBtn != null) sortModeBtn.setMessage(Component.literal("並び: " + currentSortMode.label));
        refreshSortedGroupList(currentSelected);
    }

    private void toggleSortOrder() {
        saveCurrentGroupToMemory();
        String currentSelected = getCurrentSelectedGroupName();
        currentSortOrder = (currentSortOrder == SortOrder.ASC) ? SortOrder.DESC : SortOrder.ASC;
        if (sortOrderBtn != null) sortOrderBtn.setMessage(Component.literal("順序: " + currentSortOrder.label));
        refreshSortedGroupList(currentSelected);
    }

    private String getCurrentSelectedGroupName() {
        if (sortedGroupNames.isEmpty() || currentGroupIndex < 0 || currentGroupIndex >= sortedGroupNames.size()) {
            return null;
        }
        return sortedGroupNames.get(currentGroupIndex);
    }

    private void refreshSortedGroupList(String keepSelectedName) {
        NbeConfig config = ConfigManager.getConfig();
        List<String> rawKeys = new ArrayList<>(config.instrumentSets.keySet());

        if (currentSortMode == SortMode.NAME) {
            Collator collator = Collator.getInstance(Locale.JAPANESE);
            rawKeys.sort(collator::compare);
        }

        if (currentSortOrder == SortOrder.DESC) {
            Collections.reverse(rawKeys);
        }

        sortedGroupNames.clear();
        sortedGroupNames.addAll(rawKeys);

        if (keepSelectedName != null && sortedGroupNames.contains(keepSelectedName)) {
            currentGroupIndex = sortedGroupNames.indexOf(keepSelectedName);
        } else {
            currentGroupIndex = 0;
        }
        groupListScrollOffset = 0;
    }

    private void addGroup() {
        saveCurrentGroupToMemory();
        NbeConfig config = ConfigManager.getConfig();
        int counter = config.instrumentSets.size() + 1;
        String newName = "NewGroup" + counter;
        while (config.instrumentSets.containsKey(newName)) {
            newName = "NewGroup" + (++counter);
        }
        config.instrumentSets.put(newName, new ArrayList<>());
        refreshSortedGroupList(newName);
        updateGroupFields();
    }

    private void removeGroup() {
        NbeConfig config = ConfigManager.getConfig();
        if (config.instrumentSets.size() <= 1) {
            statusMessage = Component.literal("§cグループは最低1つ必要です。");
            return;
        }
        String removedName = getCurrentSelectedGroupName();
        if (removedName != null) {
            config.instrumentSets.remove(removedName);
        }
        refreshSortedGroupList(null);
        updateGroupFields();
    }

    private void updateGroupFields() {
        if (sortedGroupNames.isEmpty()) return;
        if (currentGroupIndex < 0) currentGroupIndex = 0;
        if (currentGroupIndex >= sortedGroupNames.size()) {
            currentGroupIndex = Math.max(0, sortedGroupNames.size() - 1);
        }

        String name = sortedGroupNames.get(currentGroupIndex);
        if (this.groupNameField != null) {
            this.groupNameField.setValue(name);
        }

        NbeConfig config = ConfigManager.getConfig();
        currentBlocks.clear();
        List<String> list = config.instrumentSets.get(name);
        if (list != null) {
            currentBlocks.addAll(list);
        }
    }

    private void saveCurrentGroupToMemory() {
        if (groupNameField == null || sortedGroupNames.isEmpty()) return;
        if (currentGroupIndex < 0 || currentGroupIndex >= sortedGroupNames.size()) return;

        String oldName = sortedGroupNames.get(currentGroupIndex);
        String newName = groupNameField.getValue().trim();
        if (newName.isEmpty()) newName = oldName;

        NbeConfig config = ConfigManager.getConfig();
        if (!oldName.equals(newName)) {
            List<String> blocks = config.instrumentSets.remove(oldName);
            if (blocks == null) blocks = new ArrayList<>(currentBlocks);
            config.instrumentSets.put(newName, blocks);
            refreshSortedGroupList(newName);
        } else {
            config.instrumentSets.put(newName, new ArrayList<>(currentBlocks));
        }
    }

    private void saveConfig() {
        if (currentTab == 1) saveCurrentGroupToMemory();
        if (currentTab == 2) {
            saveCurrentSoundEdits(); // ★保存前に書き込み
            onSoundTabPathsChanged();
        }
        NbeConfig config = ConfigManager.getConfig();
        config.openGuiKeys = new ArrayList<>(tempOpenGuiKeys);
        config.resetKeys = new ArrayList<>(tempResetKeys);
        ConfigManager.save();
        statusMessage = Component.literal("§a設定を保存しました。");
    }

    private void saveCurrentSoundEdits() {
        if (currentTab != 2 || !soundTabValid || selectedSoundIndex < 0 || selectedSoundIndex >= soundMappings.size()) return;
        if (soundNameField == null || volumeField == null || pitchField == null || soundsPathField == null) return;

        NoteBetterMapping mapping = soundMappings.get(selectedSoundIndex);

        // 変更前のIDを保持（sounds.jsonの古いキーを削除するため）
        String oldSoundId = (mapping.sound != null && mapping.sound.sound != null) ? mapping.sound.sound : "";
        String oldSoundKey = oldSoundId.replace("minecraft:", "");

        // UIから新しい値を取得
        String newSoundName = soundNameField.getValue().trim();
        if (newSoundName.isEmpty()) return; // 空の場合は保存をスキップ
        String newSoundId = newSoundName.startsWith("minecraft:") ? newSoundName : "minecraft:" + newSoundName;
        String newSoundKey = newSoundName.replace("minecraft:", "");

        double newVolume = 3.0;
        double newPitch = 1.0;
        try { newVolume = Double.parseDouble(volumeField.getValue().trim()); } catch (Exception ignored) {}
        try { newPitch = Double.parseDouble(pitchField.getValue().trim()); } catch (Exception ignored) {}

        // Sounds Path から .ogg を取り除く処理
        String rawSoundsPath = soundsPathField.getValue().trim().replace("\\", "/");
        String jsonSoundsPath = rawSoundsPath;
        if (jsonSoundsPath.toLowerCase(Locale.ROOT).endsWith(".ogg")) {
            jsonSoundsPath = jsonSoundsPath.substring(0, jsonSoundsPath.length() - 4);
        }

        // メモリ上のマッピングを更新
        if (mapping.sound == null) mapping.sound = new NoteBetterSound();
        mapping.sound.sound = newSoundId;
        mapping.sound.volume = newVolume;
        mapping.sound.pitch = newPitch;

        NbeConfig config = ConfigManager.getConfig();
        String rpFolderName = config.resourcePackPath.trim().replace("\"", "");
        String nbFileName = config.noteBetterConfigPath.trim().replace("\"", "");

        // 1. sounds.json への書き込み
        if (!rpFolderName.isEmpty()) {
            File soundsJsonFile = new File(getBaseGameDir() + "/resourcepacks/" + rpFolderName + "/assets/minecraft/sounds.json");
            if (soundsJsonFile.exists()) {
                JsonObject soundsObj = new JsonObject();
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                try (Reader reader = new FileReader(soundsJsonFile)) {
                    JsonObject loaded = JsonParser.parseReader(reader).getAsJsonObject();
                    if (loaded != null) {
                        soundsObj = loaded;
                    }
                } catch (Exception ignored) {}

                JsonObject soundEntry = null;
                if (soundsObj.has(oldSoundKey)) {
                    soundEntry = soundsObj.getAsJsonObject(oldSoundKey);
                    // IDが変更された場合は古いキーを削除
                    if (!oldSoundKey.equals(newSoundKey) && !oldSoundKey.isEmpty()) {
                        soundsObj.remove(oldSoundKey);
                    }
                }

                if (soundEntry == null) {
                    soundEntry = new JsonObject();
                    soundEntry.addProperty("category", "record");
                    soundEntry.addProperty("replace", false);
                }

                JsonArray soundsArray = new JsonArray();
                soundsArray.add(jsonSoundsPath);
                soundEntry.add("sounds", soundsArray);

                soundsObj.add(newSoundKey, soundEntry);

                try (Writer writer = new FileWriter(soundsJsonFile)) {
                    gson.toJson(soundsObj, writer);
                } catch (IOException e) {
                    LOGGER.error("[NBE] sounds.json の保存に失敗しました: ", e);
                }
            }
        }

        // 2. notebetterfabric.json への書き込み
        if (!nbFileName.isEmpty()) {
            File configFile = new File(getBaseGameDir() + "/config/" + nbFileName);
            NoteBetterConfig cfg = new NoteBetterConfig();
            cfg.mappings = soundMappings;

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            try (Writer writer = new FileWriter(configFile)) {
                gson.toJson(cfg, writer);
            } catch (IOException e) {
                LOGGER.error("[NBE] notebetterfabric.json の保存に失敗しました: ", e);
            }
        }
    }

    private void closeScreen() {
        if (this.minecraft != null) {
            this.minecraft.setScreenAndShow(this.parent);
        }
    }

    private void updateButtonLabels() {
        if (this.openGuiKeyBtn != null) {
            this.openGuiKeyBtn.setMessage(getFriendlyKeyName("open", tempOpenGuiKeys));
        }
        if (this.resetKeyBtn != null) {
            this.resetKeyBtn.setMessage(getFriendlyKeyName("reset", tempResetKeys));
        }
    }

    private Component getFriendlyKeyName(String type, List<String> keys) {
        if (type.equals(waitingForKeyFor)) {
            if (keys.isEmpty()) {
                return Component.literal("§e[ キーを押してください (最大3つ) ]");
            } else {
                return Component.literal("§e[ " + formatKeys(keys) + " + ... ]");
            }
        }
        if (type.equals("open")) {
            return Component.literal("設定GUI: " + formatKeys(keys));
        } else {
            return Component.literal("選択リセット: " + formatKeys(keys));
        }
    }

    private String formatKeys(List<String> keys) {
        if (keys == null || keys.isEmpty()) return "なし";
        List<String> names = new ArrayList<>();
        for (String k : keys) {
            String clean = k.replace("key.keyboard.", "").replace("left.", "").replace("right.", "").toUpperCase();
            names.add(clean);
        }
        return String.join(" + ", names);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (waitingForKeyFor != null) {
            if (event.isEscape() || event.key() == SDLKeycode.SDLK_ESCAPE) {
                waitingForKeyFor = null;
                updateButtonLabels();
                return true;
            }

            // 26.3 仕様: InputConstants.getKey(event) を直接呼び出し
            InputConstants.Key key = InputConstants.getKey(event);
            String newTranslationKey = key.getName();

            List<String> targetList = "open".equals(waitingForKeyFor) ? tempOpenGuiKeys : tempResetKeys;
            if (!targetList.contains(newTranslationKey)) {
                targetList.add(newTranslationKey);
            }

            if (targetList.size() >= 3) {
                waitingForKeyFor = null;
            }
            updateButtonLabels();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mouseX = event.x();
        double mouseY = event.y();

        if (currentTab == 1) {
            int centerX = this.width / 2;
            int listX = centerX - 180;
            int listY = 85;
            int listW = 165;
            int itemH = 18;
            int maxVisible = 6;

            if (mouseX >= listX && mouseX <= listX + listW && mouseY >= listY && mouseY <= listY + (maxVisible * itemH)) {
                int clickedIndex = (int) ((mouseY - listY) / itemH) + groupListScrollOffset;
                if (clickedIndex >= 0 && clickedIndex < sortedGroupNames.size()) {
                    saveCurrentGroupToMemory();
                    currentGroupIndex = clickedIndex;
                    updateGroupFields();
                    return true;
                }
            }
        } else if (currentTab == 2 && soundTabValid) {
            int centerX = this.width / 2;
            int listX = centerX - 180;
            int listY = 106;
            int listW = 175;
            int itemH = 18;
            int maxVisible = 4;

            if (mouseX >= listX && mouseX <= listX + listW && mouseY >= listY && mouseY <= listY + (maxVisible * itemH)) {
                int clickedIdx = (int) ((mouseY - listY) / itemH) + soundListScrollOffset;
                if (clickedIdx >= 0 && clickedIdx < soundMappings.size()) {
                    saveCurrentSoundEdits(); // ★別の音源を選択する前に現在の内容を保存
                    selectSoundEntry(clickedIdx);
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (currentTab == 1) {
            int maxVisible = 6;
            if (verticalAmount > 0 && groupListScrollOffset > 0) {
                groupListScrollOffset--;
                return true;
            } else if (verticalAmount < 0 && (groupListScrollOffset + maxVisible) < sortedGroupNames.size()) {
                groupListScrollOffset++;
                return true;
            }
        } else if (currentTab == 2 && soundTabValid) {
            int maxVisible = 4;
            if (verticalAmount > 0 && soundListScrollOffset > 0) {
                soundListScrollOffset--;
                return true;
            } else if (verticalAmount < 0 && (soundListScrollOffset + maxVisible) < soundMappings.size()) {
                soundListScrollOffset++;
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        context.centeredText(this.font, this.title, centerX, 8, 0xFFFFFFFF);

        ItemStack hoveredStack = null;

        if (currentTab == 0) {
            renderTab0UI(context, centerX);
        } else if (currentTab == 1) {
            hoveredStack = renderTab1UI(context, mouseX, mouseY, centerX);
        } else if (currentTab == 2) {
            hoveredStack = renderTab2UI(context, mouseX, mouseY, centerX);
        }

        if (!statusMessage.getString().isEmpty()) {
            context.centeredText(this.font, statusMessage, centerX, 230, 0xFFFFFF55);
        }

        if (hoveredStack != null) {
            context.setTooltipForNextFrame(this.font, hoveredStack, mouseX, mouseY);
        }
    }

    private void renderTab0UI(GuiGraphicsExtractor context, int centerX) {
        context.centeredText(this.font, Component.literal("【設定GUIキーバインド】"), centerX, 60, 0xFFAAAAAA);
        context.centeredText(this.font, Component.literal("【選択範囲リセットキーバインド】"), centerX, 102, 0xFFAAAAAA);
        context.centeredText(this.font, Component.literal("※最大3つのキーの組み合わせを順番に押して設定できます (Escで完了/Xキーで「なし」"), centerX, 180, 0xFF888888);
    }

    private ItemStack renderTab1UI(GuiGraphicsExtractor context, int mouseX, int mouseY, int centerX) {
        ItemStack hovered = null;

        int listX = centerX - 180;
        int listY = 85;
        int listW = 165;
        int itemH = 18;
        int maxVisible = 6;

        context.fill(listX - 1, listY - 1, listX + listW + 1, listY + (maxVisible * itemH) + 1, 0xFF000000);
        context.fill(listX, listY, listX + listW, listY + (maxVisible * itemH), 0xF0202020);
        context.outline(listX, listY, listW, maxVisible * itemH, 0xFF888888);

        for (int i = 0; i < maxVisible; i++) {
            int idx = i + groupListScrollOffset;
            if (idx >= sortedGroupNames.size()) break;
            String groupName = sortedGroupNames.get(idx);
            int itemY = listY + (i * itemH);
            boolean isSelected = (idx == currentGroupIndex);

            if (isSelected) {
                context.fill(listX + 1, itemY + 1, listX + listW - 1, itemY + itemH - 1, 0x4000FF00);
            }

            String prefix = isSelected ? "§a✓ " : "  ";
            context.text(this.font, prefix + groupName, listX + 5, itemY + 5, 0xFFFFFFFF);
        }

        context.text(this.font, "グループ名:", centerX + 10, 65, 0xFFCCCCCC);
        context.text(this.font, "登録ブロック一覧:", centerX + 10, 99, 0xFFFFFFFF);

        int gridX = centerX + 10;
        int gridY = 115;
        int itemSize = 18;
        int totalCount = currentBlocks.size();
        int itemsPerRow = 7;

        for (int i = 0; i < totalCount; i++) {
            String blockId = currentBlocks.get(i);
            Block block = BuiltInRegistries.BLOCK.getValue(Identifier.parse(blockId));
            ItemStack stack = new ItemStack(block);

            int row = i / itemsPerRow;
            int col = i % itemsPerRow;
            int x = gridX + col * itemSize;
            int y = gridY + row * itemSize;

            context.fill(x - 1, y - 1, x + 17, y + 17, 0x80000000);
            context.outline(x - 1, y - 1, 18, 18, 0xFF555555);
            context.item(stack, x, y);

            if (mouseX >= x && mouseX <= x + 16 && mouseY >= y && mouseY <= y + 16) {
                context.fill(x, y, x + 16, y + 16, 0x50FFFFFF);
                hovered = stack;
            }
        }

        return hovered;
    }

    private ItemStack renderTab2UI(GuiGraphicsExtractor context, int mouseX, int mouseY, int centerX) {
        ItemStack hovered = null;

        context.text(this.font, "resourcepack path:", centerX - 170, 52, 0xFFCCCCCC);
        context.text(this.font, "notebetter.config path:", centerX - 170, 74, 0xFFCCCCCC);

        if (soundTabValid) {
            context.text(this.font, "§a[パス状態: 有効]", centerX - 180, 185, 0xFF55FF55);
        } else {
            context.text(this.font, "§c[パス状態: 無効または未入力]", centerX - 180, 185, 0xFFFF5555);
        }

        context.text(this.font, "追加音源一覧:", centerX - 180, 96, 0xFFFFFFFF);
        int listX = centerX - 180;
        int listY = 106;
        int listW = 175;
        int itemH = 18;
        int maxVisible = 4;

        context.fill(listX - 1, listY - 1, listX + listW + 1, listY + (maxVisible * itemH) + 1, 0xFF000000);
        context.fill(listX, listY, listX + listW, listY + (maxVisible * itemH), 0xF0202020);
        context.outline(listX, listY, listW, maxVisible * itemH, 0xFF888888);

        if (soundTabValid) {
            for (int i = 0; i < maxVisible; i++) {
                int idx = i + soundListScrollOffset;
                if (idx >= soundMappings.size()) break;

                NoteBetterMapping mapping = soundMappings.get(idx);
                int itemY = listY + (i * itemH);
                boolean isSelected = (idx == selectedSoundIndex);

                if (isSelected) {
                    context.fill(listX + 1, itemY + 1, listX + listW - 1, itemY + itemH - 1, 0x4000FF00);
                }

                if (mapping.block != null && !mapping.block.isEmpty()) {
                    Identifier blockId = Identifier.parse(mapping.block);
                    Block b = BuiltInRegistries.BLOCK.getValue(blockId);
                    if (b != Blocks.AIR) {
                        ItemStack stack = new ItemStack(b);
                        context.item(stack, listX + 2, itemY + 1);
                        if (mouseX >= listX + 2 && mouseX <= listX + 18 && mouseY >= itemY + 1 && mouseY <= itemY + 17) {
                            hovered = stack;
                        }
                    }
                }

                String sndName = (mapping.sound != null && mapping.sound.sound != null) ? mapping.sound.sound : "";
                if (sndName.startsWith("minecraft:")) sndName = sndName.substring(10);
                context.text(this.font, sndName, listX + 22, itemY + 5, 0xFFFFFFFF);
            }
        } else {
            context.text(this.font, "§7(パスを設定すると一覧が表示されます)", listX + 10, listY + 30, 0xFF888888);
        }

        context.text(this.font, "音源詳細設定", centerX + 5, 96, 0xFFFFFFFF);
        context.text(this.font, "ID:", centerX + 5, 110, 0xFFCCCCCC);
        context.text(this.font, "Volume:", centerX + 5, 130, 0xFFCCCCCC);
        context.text(this.font, "Pitch:", centerX + 5, 150, 0xFFCCCCCC);
        context.text(this.font, "Sounds Path:", centerX + 5, 170, 0xFFCCCCCC);

        return hovered;
    }

    private void openNativeFileDialogAsync(String title, String initialPath, java.util.function.Consumer<String> callback) {
        java.util.concurrent.CompletableFuture.supplyAsync(() -> {
            try {
                net.minecraft.util.Util.OS os = net.minecraft.util.Util.getPlatform();

                if (os == net.minecraft.util.Util.OS.WINDOWS) {
                    // Windows: PowerShellを使用してネイティブダイアログを展開
                    String safePath = (initialPath != null) ? initialPath.replace("/", "\\") : "";
                    String script = "Add-Type -AssemblyName System.Windows.Forms; " +
                            "$f = New-Object System.Windows.Forms.OpenFileDialog; " +
                            "$f.Filter = 'OGG Sound File (*.ogg)|*.ogg'; " +
                            "$f.Title = '" + title + "'; " +
                            (safePath.isEmpty() ? "" : "$f.InitialDirectory = '" + safePath + "'; ") +
                            "if ($f.ShowDialog() -eq 'OK') { [Console]::Out.WriteLine($f.FileName) }";

                    Process process = new ProcessBuilder("powershell", "-Command", script).start();
                    try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()))) {
                        String result = reader.readLine();
                        process.waitFor();
                        if (result != null && !result.trim().isEmpty()) {
                            return result.trim();
                        }
                    }
                } else if (os == net.minecraft.util.Util.OS.OSX) {
                    // macOS: AppleScript (osascript) を使用してFinderダイアログを展開
                    String macPath = (initialPath != null) ? initialPath.replace("\\", "/") : "";
                    String script = "tell application \"System Events\" to activate\n" +
                            "set f to choose file with prompt \"" + title + "\" " +
                            // macOSは拡張子フィルタを無視することが多いので緩めています
                            (macPath.isEmpty() ? "" : "default location POSIX file \"" + macPath + "\" ") + "\n" +
                            "POSIX path of f";

                    Process process = new ProcessBuilder("osascript", "-e", script).start();
                    try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()))) {
                        String result = reader.readLine();
                        process.waitFor();
                        if (result != null && !result.trim().isEmpty()) {
                            return result.trim();
                        }
                    }
                } else {
                    // Linux: Zenity を使用
                    String linuxPath = (initialPath != null) ? initialPath.replace("\\", "/") : "";
                    Process process = new ProcessBuilder("zenity", "--file-selection", "--title=" + title,
                            "--file-filter=*.ogg", "--filename=" + linuxPath + "/").start();
                    try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()))) {
                        String result = reader.readLine();
                        process.waitFor();
                        if (result != null && !result.trim().isEmpty()) {
                            return result.trim();
                        }
                    }
                }
            } catch (Throwable t) {
                LOGGER.error("[NBE] OSネイティブダイアログの起動に失敗しました: ", t);
            }
            return "";
        }).thenAccept(callback);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}