package mshok0511.noteblockedit.client.screen;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import net.minecraft.client.input.MouseButtonEvent;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class NbeItemSelectorScreen extends Screen {
    private final Screen parent;
    private final Consumer<List<String>> onConfirm;
    private final Set<String> disabledBlocks;
    private final int maxSelectionCount;

    private EditBox searchBox;
    private final List<Item> allBlocks;
    private List<Item> displayItems;
    private final List<Item> selectedItems = new ArrayList<>();
    private int scrollOffset = 0;

    public enum Category {
        ALL("すべて"), WOOD("木材"), STONE("石材"), ORE("鉱石"), REDSTONE("回路"), DECORATION("装飾");
        final String label;
        Category(String label) { this.label = label; }
    }
    private Category currentCategory = Category.ALL;

    public NbeItemSelectorScreen(Screen parent, Consumer<List<String>> onConfirm) {
        this(parent, onConfirm, new HashSet<>(), 0);
    }

    public NbeItemSelectorScreen(Screen parent, Consumer<List<String>> onConfirm, Set<String> disabledBlocks) {
        this(parent, onConfirm, disabledBlocks, 0);
    }

    public NbeItemSelectorScreen(Screen parent, Consumer<List<String>> onConfirm, Set<String> disabledBlocks, int maxSelectionCount) {
//        super(Component.literal("Block Selector"));
        super(Component.literal(""));
        this.parent = parent;
        this.onConfirm = onConfirm;
        this.disabledBlocks = disabledBlocks != null ? disabledBlocks : new HashSet<>();
        this.maxSelectionCount = maxSelectionCount;

        this.allBlocks = new ArrayList<>();
        BuiltInRegistries.ITEM.forEach(item -> {
            if (item instanceof BlockItem) this.allBlocks.add(item);
        });
        this.displayItems = new ArrayList<>(allBlocks);
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;

        this.searchBox = new EditBox(this.font, centerX - 100, 12, 200, 18, Component.empty());
        this.searchBox.setResponder(s -> updateFilter());
        this.addRenderableWidget(this.searchBox);

        int btnW = 46;
        int startX = centerX - ((btnW + 2) * Category.values().length) / 2;
        for (int i = 0; i < Category.values().length; i++) {
            Category cat = Category.values()[i];
            this.addRenderableWidget(Button.builder(Component.literal(cat.label), b -> {
                this.currentCategory = cat;
                updateFilter();
            }).bounds(startX + (i * (btnW + 2)), 34, btnW, 18).build());
        }

        this.addRenderableWidget(Button.builder(Component.literal("選択したブロックを追加"), b -> {
            List<String> ids = selectedItems.stream()
                    .map(item -> BuiltInRegistries.ITEM.getKey(item).toString())
                    .collect(Collectors.toList());

            // 親画面に先に戻し、親が再初期化されてからテキストを反映させる
            closeScreen();
            onConfirm.accept(ids);
        }).bounds(centerX - 105, 212, 100, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("設定画面に戻る"), b -> closeScreen())
                .bounds(centerX + 5, 212, 100, 20).build());

        updateFilter();
    }

    private void updateFilter() {
        String query = searchBox.getValue().toLowerCase();
        this.displayItems = allBlocks.stream()
                .filter(item -> {
                    Identifier id = BuiltInRegistries.ITEM.getKey(item);
                    String path = id.getPath();
                    boolean matchCategory = currentCategory == Category.ALL || matchCategory(path, currentCategory);
                    boolean matchQuery = query.isEmpty() || path.contains(query) || item.getDefaultInstance().getHoverName().getString().toLowerCase().contains(query);
                    return matchCategory && matchQuery;
                })
                .collect(Collectors.toList());
        this.scrollOffset = 0;
    }

    private boolean matchCategory(String path, Category category) {
        if (category == Category.WOOD) return path.contains("wood") || path.contains("log") || path.contains("planks");
        if (category == Category.STONE) return path.contains("stone") || path.contains("cobblestone") || path.contains("andesite") || path.contains("diorite") || path.contains("granite");
        if (category == Category.ORE) return path.contains("ore") || path.contains("block_of");
        if (category == Category.REDSTONE) return path.contains("redstone") || path.contains("piston") || path.contains("observer") || path.contains("repeater");
        if (category == Category.DECORATION) return path.contains("glass") || path.contains("wool") || path.contains("terracotta") || path.contains("concrete");
        return true;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        this.parent.extractRenderState(context, -1, -1, delta);

        context.fill(0, 0, this.width, this.height, 0x80000000);

        int centerX = this.width / 2;
        int panelW = 200;
        int panelH = 150;
        int panelX = centerX - panelW / 2;
        int panelY = 56;

        context.fill(panelX - 4, panelY - 4, panelX + panelW + 4, panelY + panelH + 4, 0xF0101010);
        context.outline(panelX - 4, panelY - 4, panelW + 8, panelH + 8, 0xFF333333);

        super.extractRenderState(context, mouseX, mouseY, delta);

        context.centeredText(this.font, this.title, centerX, 12, 0xFFFFFFFF);

        int startX = panelX + 4;
        int startY = panelY + 4;
        int columns = 9;
        int rows = 7;
        int slotSize = 21;

        ItemStack hoveredStack = null;
        boolean hoveredDisabled = false;

        for (int i = 0; i < columns * rows; i++) {
            int index = i + (scrollOffset * columns);
            if (index >= displayItems.size()) break;

            int col = i % columns;
            int row = i / columns;
            int x = startX + col * slotSize;
            int y = startY + row * slotSize;

            context.fill(x, y, x + 18, y + 18, 0xFF373737);
            context.outline(x, y, 18, 18, 0xFF8B8B8B);

            Item item = displayItems.get(index);
            String idStr = BuiltInRegistries.ITEM.getKey(item).toString();
            boolean isDisabled = disabledBlocks.contains(idStr);
            ItemStack stack = item.getDefaultInstance();

            if (isDisabled) {
                context.fill(x + 1, y + 1, x + 17, y + 17, 0x80FF0000);
            } else if (selectedItems.contains(item)) {
                context.fill(x + 1, y + 1, x + 17, y + 17, 0x8000FF00);
            }

            context.item(stack, x + 1, y + 1);

            if (isDisabled) {
                context.text(this.font, "×", x + 5, y + 3, 0xFFFF5555);
            }

            if (mouseX >= x && mouseX <= x + 18 && mouseY >= y && mouseY <= y + 18) {
                context.fill(x + 1, y + 1, x + 17, y + 17, 0x50FFFFFF);
                hoveredStack = stack;
                hoveredDisabled = isDisabled;
            }
        }

        int totalRows = (int) Math.ceil((double) displayItems.size() / columns);
        if (totalRows > rows) {
            int scrollbarX = panelX + panelW - 12;
            int scrollbarY = panelY + 4;
            int scrollbarH = panelH - 8;
            context.fill(scrollbarX, scrollbarY, scrollbarX + 8, scrollbarY + scrollbarH, 0xFF555555);

            int thumbH = Math.max(10, scrollbarH * rows / totalRows);
            int thumbY = scrollbarY + (scrollbarH - thumbH) * scrollOffset / Math.max(1, totalRows - rows);
            context.fill(scrollbarX, thumbY, scrollbarX + 8, thumbY + thumbH, 0xFFAAAAAA);
        }

        context.text(this.font, "選択中: " + selectedItems.size() + "個", centerX + 110, 217, 0xFFFFFF00);

        if (hoveredStack != null) {
            if (hoveredDisabled) {
                List<Component> tooltip = List.of(hoveredStack.getHoverName(), Component.literal("§c(すでに追加済み)"));
                context.setComponentTooltipForNextFrame(this.font, tooltip, mouseX, mouseY);
            } else {
                context.setTooltipForNextFrame(this.font, hoveredStack.getHoverName(), mouseX, mouseY);
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mouseX = event.x();
        double mouseY = event.y();

        int centerX = this.width / 2;
        int panelX = centerX - 100;
        int startX = panelX + 4;
        int startY = 60;
        int columns = 9;
        int rows = 7;
        int slotSize = 21;

        for (int i = 0; i < columns * rows; i++) {
            int index = i + (scrollOffset * columns);
            if (index >= displayItems.size()) break;

            int col = i % columns;
            int row = i / columns;
            int x = startX + col * slotSize;
            int y = startY + row * slotSize;

            if (mouseX >= x && mouseX <= x + 18 && mouseY >= y && mouseY <= y + 18) {
                Item item = displayItems.get(index);
                String idStr = BuiltInRegistries.ITEM.getKey(item).toString();
                if (disabledBlocks.contains(idStr)) {
                    return true;
                }

                if (maxSelectionCount == 1) {
                    selectedItems.clear();
                    selectedItems.add(item);
                } else {
                    if (selectedItems.contains(item)) {
                        selectedItems.remove(item);
                    } else {
                        selectedItems.add(item);
                    }
                }
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount > 0 && scrollOffset > 0) scrollOffset--;
        else if (verticalAmount < 0 && (scrollOffset + 7) * 9 < displayItems.size()) scrollOffset++;
        return true;
    }

    private void closeScreen() {
        if (this.minecraft != null) {
            this.minecraft.setScreenAndShow(this.parent);
        }
    }
}