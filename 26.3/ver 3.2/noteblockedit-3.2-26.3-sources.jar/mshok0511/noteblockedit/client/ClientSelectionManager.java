package mshok0511.noteblockedit.client;

import net.minecraft.core.BlockPos;

public class ClientSelectionManager {
    private static BlockPos pos1 = null;
    private static BlockPos pos2 = null;

    public static void setPos1(BlockPos pos) { pos1 = pos; }
    public static void setPos2(BlockPos pos) { pos2 = pos; }
    public static BlockPos getPos1() { return pos1; }
    public static BlockPos getPos2() { return pos2; }

    public static void clear() {
        pos1 = null;
        pos2 = null;
    }
}