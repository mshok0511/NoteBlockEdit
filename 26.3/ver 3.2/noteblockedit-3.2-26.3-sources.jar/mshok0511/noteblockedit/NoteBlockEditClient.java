package mshok0511.noteblockedit;

import mshok0511.noteblockedit.client.screen.NbeConfigScreen;
import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.config.NbeConfig;
import mshok0511.noteblockedit.network.NbeNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.network.chat.Component;

import java.util.List;

public class NoteBlockEditClient implements ClientModInitializer {
    private boolean openGuiKeyWasPressed = false;
    private boolean resetKeyWasPressed = false;

    @Override
    public void onInitializeClient() {
        NbeNetworking.registerClientReceivers();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.gui.screen() != null) {
                openGuiKeyWasPressed = false;
                resetKeyWasPressed = false;
                return;
            }

            NbeConfig config = ConfigManager.getConfig();

            boolean resetPressed = areAllKeysPressed(config.resetKeys);
            boolean openGuiPressed = areAllKeysPressed(config.openGuiKeys);

            // 1. 選択範囲リセットショートカットを優先判定
            if (resetPressed) {
                if (!resetKeyWasPressed) {
                    NbeNetworking.sendResetRequestC2S();
                    client.player.sendOverlayMessage(Component.literal("§b[NBE] 選択範囲と各座標をリセットしました"));
                }
                // リセットキーが押されている間は、同じキーセットが割り当てられていても設定画面を開かないようにフラグをガード
                resetKeyWasPressed = true;
                openGuiKeyWasPressed = true;
                return;
            } else {
                resetKeyWasPressed = false;
            }

            // 2. 設定画面ショートカット (リセットキーが押されていない場合のみ実行)
            if (openGuiPressed) {
                if (!openGuiKeyWasPressed) {
                    client.setScreenAndShow(new NbeConfigScreen(null));
                }
                openGuiKeyWasPressed = true;
            } else {
                openGuiKeyWasPressed = false;
            }
        });
    }

    /**
     * リスト内のすべてのキーが押されているか判定
     */
    private boolean areAllKeysPressed(List<String> keyTranslationKeys) {
        if (keyTranslationKeys == null || keyTranslationKeys.isEmpty()) return false;
        for (String translationKey : keyTranslationKeys) {
            try {
                InputConstants.Key key = InputConstants.getKey(translationKey);
                if (!InputConstants.isKeyDown(key.getValue())) {
                    return false;
                }
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }
}