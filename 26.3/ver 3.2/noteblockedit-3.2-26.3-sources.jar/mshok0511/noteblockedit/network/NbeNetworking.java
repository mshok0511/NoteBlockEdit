package mshok0511.noteblockedit.network;

import mshok0511.noteblockedit.NoteBlockEdit;
import mshok0511.noteblockedit.client.ClientSelectionManager;
import mshok0511.noteblockedit.client.screen.NbeConfigScreen;
import mshok0511.noteblockedit.util.SelectionManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;

public class NbeNetworking {
    public record SelectionSyncPayload(BlockPos p1, BlockPos p2) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<SelectionSyncPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(NoteBlockEdit.MOD_ID, "selection_sync"));

        public static final StreamCodec<RegistryFriendlyByteBuf, SelectionSyncPayload> CODEC = StreamCodec.of(
                (buf, value) -> {
                    buf.writeBoolean(value.p1 != null);
                    if (value.p1 != null) buf.writeBlockPos(value.p1);
                    buf.writeBoolean(value.p2 != null);
                    if (value.p2 != null) buf.writeBlockPos(value.p2);
                },
                buf -> {
                    boolean hasP1 = buf.readBoolean();
                    BlockPos p1 = hasP1 ? buf.readBlockPos() : null;
                    boolean hasP2 = buf.readBoolean();
                    BlockPos p2 = hasP2 ? buf.readBlockPos() : null;
                    return new SelectionSyncPayload(p1, p2);
                }
        );

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record OpenConfigPayload() implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<OpenConfigPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(NoteBlockEdit.MOD_ID, "open_config"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenConfigPayload> CODEC = StreamCodec.unit(new OpenConfigPayload());

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record ResetRequestPayload() implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<ResetRequestPayload> TYPE = new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(NoteBlockEdit.MOD_ID, "reset_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf, ResetRequestPayload> CODEC = StreamCodec.unit(new ResetRequestPayload());

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    // --- パケット登録 ---

    public static void registerPayloads() {
        PayloadTypeRegistry.clientboundPlay().register(SelectionSyncPayload.TYPE, SelectionSyncPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(OpenConfigPayload.TYPE, OpenConfigPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(ResetRequestPayload.TYPE, ResetRequestPayload.CODEC);
    }

    // --- 送信メソッド ---

    public static void sendSelectionS2C(ServerPlayer player, BlockPos p1, BlockPos p2) {
        ServerPlayNetworking.send(player, new SelectionSyncPayload(p1, p2));
    }

    public static void sendOpenConfigS2C(ServerPlayer player) {
        ServerPlayNetworking.send(player, new OpenConfigPayload());
    }

    @Environment(EnvType.CLIENT)
    public static void sendResetRequestC2S() {
        ClientPlayNetworking.send(new ResetRequestPayload());
    }

    // --- 受信レシーバー登録 ---

    @SuppressWarnings("resource")
    public static void registerServerReceivers() {
        registerPayloads();
        ServerPlayNetworking.registerGlobalReceiver(ResetRequestPayload.TYPE, (payload, context) ->
                context.server().execute(() -> SelectionManager.clear(context.player()))
        );
    }

    @Environment(EnvType.CLIENT)
    @SuppressWarnings("resource")
    public static void registerClientReceivers() {
        ClientPlayNetworking.registerGlobalReceiver(SelectionSyncPayload.TYPE, (payload, context) ->
                context.client().execute(() -> {
                    ClientSelectionManager.setPos1(payload.p1());
                    ClientSelectionManager.setPos2(payload.p2());
                })
        );

        ClientPlayNetworking.registerGlobalReceiver(OpenConfigPayload.TYPE, (payload, context) ->
                context.client().execute(() -> context.client().setScreenAndShow(new NbeConfigScreen(null)))
        );
    }
}