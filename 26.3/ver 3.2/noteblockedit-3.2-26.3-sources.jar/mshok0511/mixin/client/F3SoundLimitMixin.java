package mshok0511.mixin.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.debug.DebugEntryVersion;
import net.minecraft.client.gui.components.debug.DebugScreenDisplayer;
import net.minecraft.client.sounds.SoundEngine;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;

// ターゲットを必ずF3に表示される DebugEntryVersion に変更
@Mixin(DebugEntryVersion.class)
public class F3SoundLimitMixin {
    @Unique
    private static int maxSourcesCache = -1;

    @Inject(method = "display", at = @At("RETURN"))
    private void appendSoundCount(DebugScreenDisplayer displayer, Level serverOrClientLevel, LevelChunk clientChunk, LevelChunk serverChunk, CallbackInfo ci) {
        // 要件3: 設定ファイルから m (最大音源数) を読み込む（F3を開いた初回のみ実行）
        if (maxSourcesCache == -1) {
            maxSourcesCache = 255;
            Path configPath = FabricLoader.getInstance().getConfigDir().resolve("rsls.properties");
            if (Files.exists(configPath)) {
                try (InputStream in = Files.newInputStream(configPath)) {
                    Properties props = new Properties();
                    props.load(in);
                    String maxVal = props.getProperty("maxSourcesCount");
                    if (maxVal != null) {
                        maxSourcesCache = Integer.parseInt(maxVal.trim());
                    }
                } catch (Exception ignored) {
                }
            }
        }

        int activeSounds = -1;
        try {
            SoundManager soundManager = Minecraft.getInstance().getSoundManager();

            // 難読化環境でも確実に SoundEngine を取得する
            Field soundEngineField = Arrays.stream(SoundManager.class.getDeclaredFields())
                    .filter(f -> f.getType() == SoundEngine.class)
                    .findFirst().orElse(null);

            if (soundEngineField != null) {
                soundEngineField.setAccessible(true);
                SoundEngine soundEngine = (SoundEngine) soundEngineField.get(soundManager);

                // instanceToChannel（またはそれに該当するMap）を自動検索して取得する
                Field mapField = Arrays.stream(SoundEngine.class.getDeclaredFields())
                        .filter(f -> Map.class.isAssignableFrom(f.getType()))
                        .filter(f -> f.getName().equals("instanceToChannel") || f.getName().equals("sources"))
                        .findFirst().orElse(null);

                if (mapField == null) {
                    // 見つからなければ最初の Map 変数を取得
                    mapField = Arrays.stream(SoundEngine.class.getDeclaredFields())
                            .filter(f -> Map.class.isAssignableFrom(f.getType()))
                            .findFirst().orElse(null);
                }

                if (mapField != null) {
                    mapField.setAccessible(true);
                    Map<?, ?> instanceToChannel = (Map<?, ?>) mapField.get(soundEngine);
                    activeSounds = instanceToChannel.size(); // 現在鳴っている音の数 (n)
                }
            }
        } catch (Exception e) {
            // エラー時はフェイルセーフとして処理をスキップ
        }

        // 要件1 & 2: 取得した n と m を用いて "Sound n/m" の形式でF3画面に追加
        String n = (activeSounds >= 0) ? String.valueOf(activeSounds) : "?";
        displayer.addLine("Sound " + n + "/" + maxSourcesCache);
    }
}