package mshok0511.mixin.client;

import mshok0511.noteblockedit.client.SelectionRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {

    @Inject(method = "submitFeatures", at = @At("RETURN"))
    private void onSubmitFeatures(
            LevelRenderState levelRenderState,
            SubmitNodeCollector submitNodeCollector,
            boolean renderOutline,
            CallbackInfo ci
    ) {
        // レベルレンダーステートからカメラ情報を取得してカスタム選択枠を描画ノードへ追加
        SelectionRenderer.renderCustomSelections(levelRenderState.cameraRenderState, submitNodeCollector);
    }
}