package mshok0511.soundsurveillance.manager;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import java.util.*;

public class SurveillanceManager {
    private static final Map<UUID, List<Integer>> recordHistory = new HashMap<>();
    private static final Map<UUID, List<Integer>> activeSoundLifetimes = new HashMap<>();
    private static final Map<UUID, Integer> newSoundsInTick = new HashMap<>();
    private static final int SOUND_DURATION_TICKS = 40;

    public static boolean isMonitoring(UUID uuid) {
        return recordHistory.containsKey(uuid);
    }

    public static void start(ServerPlayer player) {
        UUID uuid = player.getUUID();
        if (isMonitoring(uuid)) {
            player.sendSystemMessage(Component.literal("soundsSurveillanceは実行中です。"));
            return;
        }
        recordHistory.put(uuid, new ArrayList<>());
        activeSoundLifetimes.put(uuid, new ArrayList<>());
        newSoundsInTick.put(uuid, 0);
        player.sendSystemMessage(Component.literal("音符ブロック（残響込み）の監視を開始しました。"));
    }

    public static void incrementTickCount(UUID uuid) {
        if (isMonitoring(uuid)) {
            newSoundsInTick.put(uuid, newSoundsInTick.get(uuid) + 1);
        }
    }

    public static void tickEnd() {
        for (UUID uuid : recordHistory.keySet()) {
            List<Integer> lifetimes = activeSoundLifetimes.get(uuid);
            lifetimes.replaceAll(life -> life - 1);
            lifetimes.removeIf(life -> life <= 0);

            int newCount = newSoundsInTick.getOrDefault(uuid, 0);
            for (int i = 0; i < newCount; i++) {
                lifetimes.add(SOUND_DURATION_TICKS);
            }

            int currentTotalVolume = lifetimes.size();
            recordHistory.get(uuid).add(currentTotalVolume);
            newSoundsInTick.put(uuid, 0);
        }
    }

    public static void finish(ServerPlayer player) {
        UUID uuid = player.getUUID();
        if (!isMonitoring(uuid)) {
            player.sendSystemMessage(Component.literal("soundsSurveillanceは実行されていません。"));
            return;
        }

        List<Integer> values = recordHistory.get(uuid);
        if (values.isEmpty()) {
            player.sendSystemMessage(Component.literal("音は検出されませんでした。"));
        } else {
            double average = values.stream().mapToDouble(Integer::doubleValue).average().orElse(0.0);
            player.sendSystemMessage(Component.literal(String.format("監視終了。平均同時再生数(残響込): %.2f", average)));
        }

        recordHistory.remove(uuid);
        activeSoundLifetimes.remove(uuid);
        newSoundsInTick.remove(uuid);
    }

    public static void resetAll() {
        recordHistory.clear();
        activeSoundLifetimes.clear();
        newSoundsInTick.clear();
    }
}