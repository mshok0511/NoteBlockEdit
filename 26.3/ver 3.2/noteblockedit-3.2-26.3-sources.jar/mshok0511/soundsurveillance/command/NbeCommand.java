package mshok0511.soundsurveillance.command;

import com.mojang.brigadier.CommandDispatcher;
import mshok0511.soundsurveillance.manager.SurveillanceManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.server.level.ServerPlayer;

public class NbeCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("nbe")
                .then(Commands.literal("soundsSurveillance")
                        .then(Commands.argument("target", EntityArgument.player())
                                .then(Commands.literal("start")
                                        .executes(context -> {
                                            ServerPlayer target = EntityArgument.getPlayer(context, "target");
                                            SurveillanceManager.start(target);
                                            return 1;
                                        }))
                                .then(Commands.literal("finish")
                                        .executes(context -> {
                                            ServerPlayer target = EntityArgument.getPlayer(context, "target");
                                            SurveillanceManager.finish(target);
                                            return 1;
                                        }))
                        )
                )
        );
    }
}