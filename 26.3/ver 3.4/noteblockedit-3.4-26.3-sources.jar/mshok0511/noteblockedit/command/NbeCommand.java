package mshok0511.noteblockedit.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.network.NbeNetworking;
import mshok0511.noteblockedit.util.ModulationHistoryManager;
import mshok0511.noteblockedit.util.ModulationLogic;
import mshok0511.noteblockedit.util.SelectionManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class NbeCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("nbe")
                .then(Commands.literal("modulationSelectArea")
                        .then(Commands.literal("start")
                                .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                        .executes(ctx -> setPos(ctx, true, BlockPosArgument.getLoadedBlockPos(ctx, "pos"))))
                                .executes(ctx -> {
                                    ServerPlayer player = getPlayerOrThrow(ctx);
                                    return setPos(ctx, true, player.blockPosition());
                                }))
                        .then(Commands.literal("goal")
                                .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                        .executes(ctx -> setPos(ctx, false, BlockPosArgument.getLoadedBlockPos(ctx, "pos"))))
                                .executes(ctx -> {
                                    ServerPlayer player = getPlayerOrThrow(ctx);
                                    return setPos(ctx, false, player.blockPosition());
                                })))

                .then(Commands.literal("config")
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayer();
                            if (player != null) {
                                NbeNetworking.sendOpenConfigS2C(player);
                            }
                            return 1;
                        }))

                .then(Commands.literal("tickrate")
                        .then(Commands.argument("rate", FloatArgumentType.floatArg())
                                .executes(ctx -> {
                                    float rate = FloatArgumentType.getFloat(ctx, "rate");

                                    if (rate < 1.0f) rate = 1.0f;
                                    if (rate > 300.0f) rate = 300.0f;

                                    ctx.getSource().getServer().tickRateManager().setTickRate(rate);

                                    float finalRate = rate;
                                    ctx.getSource().sendSuccess(() -> Component.literal(String.format("§a[NBE] サーバーの Tick Rate を %.3f に設定しました", finalRate)), true);
                                    return (int) finalRate;
                                }))
                        .executes(ctx -> {
                            ctx.getSource().getServer().tickRateManager().setTickRate(20.0f);
                            ctx.getSource().sendSuccess(() -> Component.literal("§a[NBE] サーバーの Tick Rate をデフォルトの 20.000 に設定しました"), true);
                            return 20;
                        }))

                .then(Commands.literal("modulationUp")
                        .then(Commands.argument("amount", IntegerArgumentType.integer(1, 24))
                                .executes(ctx -> {
                                    int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                    int count = ModulationLogic.executeModulation(ctx.getSource(), amount, true);
                                    ctx.getSource().sendSuccess(() -> Component.literal("§b" + count + " 個の音符ブロックを上げました"), true);
                                    return count;
                                })))

                .then(Commands.literal("modulationDown")
                        .then(Commands.argument("amount", IntegerArgumentType.integer(1, 24))
                                .executes(ctx -> {
                                    int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                    int count = ModulationLogic.executeModulation(ctx.getSource(), amount, false);
                                    ctx.getSource().sendSuccess(() -> Component.literal("§b" + count + " 個の音符ブロックを下げました"), true);
                                    return count;
                                })))

                .then(Commands.literal("undo")
                        .then(Commands.argument("count", IntegerArgumentType.integer(1))
                                .executes(ctx -> runUndo(ctx, IntegerArgumentType.getInteger(ctx, "count"))))
                        .executes(ctx -> runUndo(ctx, 1)))

                .then(Commands.literal("redo")
                        .then(Commands.argument("count", IntegerArgumentType.integer(1))
                                .executes(ctx -> runRedo(ctx, IntegerArgumentType.getInteger(ctx, "count"))))
                        .executes(ctx -> runRedo(ctx, 1)))

                .then(Commands.literal("reload").executes(context -> {
                    ConfigManager.load();

                    context.getSource().sendSuccess(() -> Component.literal("§a[NBE] noteblockeditConfig.json を再読み込みしました。"), true);
                    return 1;
                }))
        );
    }

    private static int runUndo(CommandContext<CommandSourceStack> ctx, int amount) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) return 0;

        int result = ModulationHistoryManager.undo(player, amount);
        if (result == -1) {
            ctx.getSource().sendSuccess(() -> Component.literal("§c変更履歴が存在しません。"), false);
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.literal("§b" + result + " 回の操作を元に戻しました。"), false);
        return result;
    }

    private static int runRedo(CommandContext<CommandSourceStack> ctx, int amount) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) return 0;

        int result = ModulationHistoryManager.redo(player, amount);
        if (result == -1) {
            ctx.getSource().sendSuccess(() -> Component.literal("§c変更履歴が存在しません。"), false);
            return 0;
        }
        ctx.getSource().sendSuccess(() -> Component.literal("§b" + result + " 回の操作をやり直しました。"), false);
        return result;
    }

    private static int setPos(CommandContext<CommandSourceStack> ctx, boolean isStart, BlockPos pos) {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) return 0;

        if (isStart) {
            SelectionManager.setPos1(player, pos);
            ctx.getSource().sendSuccess(() -> Component.literal("§c[NBE] Start (赤) を整数座標でセット: " + pos.toShortString()), false);
        } else {
            SelectionManager.setPos2(player, pos);
            ctx.getSource().sendSuccess(() -> Component.literal("§a[NBE] Goal (緑) を整数座標でセット: " + pos.toShortString()), false);
        }
        return 1;
    }

    private static ServerPlayer getPlayerOrThrow(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayer();
        if (player == null) {
            throw new SimpleCommandExceptionType(Component.literal("コマンドブロックから実行する場合は座標を入力してください。")).create();
        }
        return player;
    }
}