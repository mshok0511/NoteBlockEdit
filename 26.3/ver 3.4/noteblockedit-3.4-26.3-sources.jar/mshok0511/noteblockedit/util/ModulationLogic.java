package mshok0511.noteblockedit.util;

import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.config.NbeConfig;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.NoteBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ModulationLogic {

    public static int executeModulation(CommandSourceStack source, int amount, boolean isUp) {
        ServerLevel world = source.getLevel();
        if (source.getPlayer() == null) return 0;

        BlockPos p1 = SelectionManager.getPos1(source.getPlayer().getUUID());
        BlockPos p2 = SelectionManager.getPos2(source.getPlayer().getUUID());

        if (p1 == null || p2 == null) {
            source.sendFailure(Component.literal("エリアが選択されていません。"));
            return 0;
        }

        int minX = Math.min(p1.getX(), p2.getX());
        int maxX = Math.max(p1.getX(), p2.getX());
        int minY = Math.min(p1.getY(), p2.getY());
        int maxY = Math.max(p1.getY(), p2.getY());
        int minZ = Math.min(p1.getZ(), p2.getZ());
        int maxZ = Math.max(p1.getZ(), p2.getZ());

        NbeConfig config = ConfigManager.getConfig();
        List<ModulationHistoryManager.BlockChange> history = new ArrayList<>();
        int affectedCount = 0;

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    BlockPos notePos = new BlockPos(x, y, z);
                    BlockState noteState = world.getBlockState(notePos);

                    if (noteState.is(Blocks.NOTE_BLOCK)) {
                        BlockPos basePos = notePos.below();
                        if (basePos.getX() < minX || basePos.getX() > maxX ||
                                basePos.getY() < minY || basePos.getY() > maxY ||
                                basePos.getZ() < minZ || basePos.getZ() > maxZ) continue;

                        BlockState baseState = world.getBlockState(basePos);

                        if (processAndRecord(source, world, notePos, basePos, noteState, baseState, config, amount, isUp, history)) {
                            affectedCount++;
                        }
                    }
                }
            }
        }

        if (!history.isEmpty()) {
            ModulationHistoryManager.pushHistory(source.getPlayer().getUUID(), history);
        }

        return affectedCount;
    }

    private static boolean processAndRecord(CommandSourceStack source, ServerLevel world, BlockPos notePos, BlockPos basePos,
                                            BlockState noteState, BlockState baseState, NbeConfig config,
                                            int amount, boolean isUp, List<ModulationHistoryManager.BlockChange> history) {

        String baseId = BuiltInRegistries.BLOCK.getKey(baseState.getBlock()).toString();

        for (Map.Entry<String, List<String>> entry : config.instrumentSets.entrySet()) {
            List<String> blocks = entry.getValue();
            if (blocks.contains(baseId)) {
                int currentNote = noteState.getValue(NoteBlock.NOTE);
                int targetNote = isUp ? (currentNote + amount) : (currentNote - amount);
                int currentIndex = blocks.indexOf(baseId);

                if (targetNote > 24) {
                    int nextIndex = currentIndex + 1;
                    if (nextIndex < blocks.size()) {
                        targetNote -= 24;
                        String nextBlock = blocks.get(nextIndex);
                        BlockState newBaseState = BuiltInRegistries.BLOCK.getValue(Identifier.parse(nextBlock)).defaultBlockState();

                        history.add(new ModulationHistoryManager.BlockChange(basePos, baseState, newBaseState));
                        world.setBlock(basePos, newBaseState, 3);

                        BlockState newNoteState = noteState.setValue(NoteBlock.NOTE, targetNote);
                        history.add(new ModulationHistoryManager.BlockChange(notePos, noteState, newNoteState));
                        world.setBlock(notePos, newNoteState, 3);
                        return true;
                    } else {
                        source.sendSuccess(() -> Component.literal("§c置換失敗(範囲外): " + notePos.toShortString()), false);
                        return false;
                    }
                } else if (targetNote < 0) {
                    int nextIndex = currentIndex - 1;
                    if (nextIndex >= 0) {
                        targetNote += 24;
                        String nextBlock = blocks.get(nextIndex);
                        BlockState newBaseState = BuiltInRegistries.BLOCK.getValue(Identifier.parse(nextBlock)).defaultBlockState();

                        history.add(new ModulationHistoryManager.BlockChange(basePos, baseState, newBaseState));
                        world.setBlock(basePos, newBaseState, 3);

                        BlockState newNoteState = noteState.setValue(NoteBlock.NOTE, targetNote);
                        history.add(new ModulationHistoryManager.BlockChange(notePos, noteState, newNoteState));
                        world.setBlock(notePos, newNoteState, 3);
                        return true;
                    } else {
                        source.sendSuccess(() -> Component.literal("§c置換失敗(範囲外): " + notePos.toShortString()), false);
                        return false;
                    }
                } else {
                    BlockState newNoteState = noteState.setValue(NoteBlock.NOTE, targetNote);
                    history.add(new ModulationHistoryManager.BlockChange(notePos, noteState, newNoteState));
                    world.setBlock(notePos, newNoteState, 3);
                    return true;
                }
            }
        }
        return false;
    }
}