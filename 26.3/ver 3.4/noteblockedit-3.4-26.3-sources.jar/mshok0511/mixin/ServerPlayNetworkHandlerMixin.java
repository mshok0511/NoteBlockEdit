package mshok0511.mixin;

import mshok0511.soundsurveillance.manager.SurveillanceManager;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ClientboundTickingStatePacket;
import net.minecraft.network.protocol.game.ClientboundTickingStepPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.server.network.ServerCommonPacketListenerImpl;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerCommonPacketListenerImpl.class)
public abstract class ServerPlayNetworkHandlerMixin {

    @Inject(
            method = "send(Lnet/minecraft/network/protocol/Packet;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onSendPacket(Packet<?> packet, CallbackInfo ci) {
        if (packet instanceof ClientboundTickingStatePacket || packet instanceof ClientboundTickingStepPacket) {
            ci.cancel();
            return;
        }

        if ((Object) this instanceof ServerGamePacketListenerImpl handler) {
            if (packet instanceof ClientboundSoundPacket soundPacket) {
                Identifier id = soundPacket.getSound().unwrapKey()
                        .map(ResourceKey::identifier)
                        .orElseGet(() -> soundPacket.getSound().value().location());

                if (id != null && id.getPath().contains("note_block")) {
                    if (handler.player != null) {
                        SurveillanceManager.incrementTickCount(handler.player.getUUID());
                    }
                }
            }
        }
    }
}