package mshok0511.noteblockedit.client.screen;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.config.NbeConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import org.lwjgl.system.Library;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;

public class NbeSoundAddScreen extends Screen {
    private final NbeConfigScreen parent;

    private EditBox blockIdField;
    private EditBox soundNameField;
    private EditBox volumeField;
    private EditBox pitchField;
    private EditBox soundsPathField;
    private EditBox savePathField;
    private EditBox renameField;

    private Button saveBtn;

    private String selectedOggFilePath = "";
    private Component statusMessage = Component.empty();

    public static class NoteBetterSound {
        public String sound;
        public double volume = 3.0;
        public double pitch = 1.0;
    }

    public static class NoteBetterMapping {
        public String block;
        public NoteBetterSound sound;
    }

    public static class NoteBetterConfig {
        public List<NoteBetterMapping> mappings = new ArrayList<>();
    }

    public NbeSoundAddScreen(NbeConfigScreen parent) {
        super(Component.literal("音源追加"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int y = 35;

        // 1. 対象ブロック
        this.blockIdField = new EditBox(this.font, centerX - 40, y, 120, 18, Component.empty());
        this.blockIdField.setValue("");
        this.blockIdField.setResponder(s -> updateSaveButtonState());
        this.addRenderableWidget(this.blockIdField);

        this.addRenderableWidget(Button.builder(Component.literal("選択..."), b -> {
            if (this.minecraft != null) {
                Set<String> disabledBlocks = getAddedBlockIds();
                this.minecraft.setScreenAndShow(new NbeItemSelectorScreen(this, (newIds) -> {
                    if (!newIds.isEmpty()) {
                        this.blockIdField.setValue(newIds.get(0));
                        updateSaveButtonState();
                    }
                }, disabledBlocks, 1));
            }
        }).bounds(centerX + 85, y, 55, 18).build());

        y += 24;
        // 2. 音源名
        this.soundNameField = new EditBox(this.font, centerX - 40, y, 180, 18, Component.empty());
        this.soundNameField.setValue("");
        this.soundNameField.setResponder(s -> updateSaveButtonState());
        this.addRenderableWidget(this.soundNameField);

        y += 24;
        // 3. Volume & 4. Pitch
        this.volumeField = new EditBox(this.font, centerX - 40, y, 60, 18, Component.empty());
        this.volumeField.setValue("3.0");
        this.volumeField.setResponder(s -> updateSaveButtonState());
        this.addRenderableWidget(this.volumeField);

        this.pitchField = new EditBox(this.font, centerX + 80, y, 60, 18, Component.empty());
        this.pitchField.setValue("1.0");
        this.pitchField.setResponder(s -> updateSaveButtonState());
        this.addRenderableWidget(this.pitchField);

        y += 24;
        // 5. Sounds Path
        this.soundsPathField = new EditBox(this.font, centerX - 40, y, 120, 18, Component.empty());
        this.soundsPathField.setMaxLength(500);
        this.soundsPathField.setHint(Component.literal("OGGファイル選択"));
        this.soundsPathField.setResponder(s -> updateSaveButtonState());
        this.addRenderableWidget(this.soundsPathField);

        this.addRenderableWidget(Button.builder(Component.literal("参照..."), b -> openOggFileDialog())
                .bounds(centerX + 85, y, 55, 18).build());

        y += 24;
        // 6. Save Path
        this.savePathField = new EditBox(this.font, centerX - 40, y, 120, 18, Component.empty());
        this.savePathField.setMaxLength(500);
        this.savePathField.setHint(Component.literal("sounds配下のフォルダパス"));
        this.savePathField.setResponder(s -> updateSaveButtonState());
        this.addRenderableWidget(this.savePathField);

        this.addRenderableWidget(Button.builder(Component.literal("参照..."), b -> openSaveFolderDialog())
                .bounds(centerX + 85, y, 55, 18).build());

        y += 24;
        // 7. Rename
        this.renameField = new EditBox(this.font, centerX - 40, y, 180, 18, Component.empty());
        this.renameField.setMaxLength(100);
        this.renameField.setHint(Component.literal("新しいファイル名 (.ogg除く)"));
        this.renameField.setResponder(s -> updateSaveButtonState());
        this.addRenderableWidget(this.renameField);

        // 下部ボタン (追加・保存, キャンセル)
        int bottomY = 195;
        this.saveBtn = this.addRenderableWidget(Button.builder(Component.literal("追加・保存"), b -> saveAndClose())
                .bounds(centerX - 80, bottomY, 70, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("キャンセル"), b -> closeScreen())
                .bounds(centerX + 10, bottomY, 70, 20).build());

        updateSaveButtonState();
    }

    private Set<String> getAddedBlockIds() {
        Set<String> set = new HashSet<>();
        NbeConfig config = ConfigManager.getConfig();
        if (config.noteBetterConfigPath != null && !config.noteBetterConfigPath.isEmpty()) {
            File configFile = new File(config.noteBetterConfigPath);
            if (configFile.exists()) {
                try (Reader reader = new FileReader(configFile)) {
                    Gson gson = new Gson();
                    NoteBetterConfig loaded = gson.fromJson(reader, NoteBetterConfig.class);
                    if (loaded != null && loaded.mappings != null) {
                        for (NoteBetterMapping m : loaded.mappings) {
                            if (m.block != null && !m.block.isEmpty()) {
                                set.add(m.block);
                            }
                        }
                    }
                } catch (Exception ignored) {}
            }
        }
        return set;
    }

    private void updateSaveButtonState() {
        if (saveBtn == null) return;
        boolean valid = !blockIdField.getValue().trim().isEmpty() &&
                !soundNameField.getValue().trim().isEmpty() &&
                !volumeField.getValue().trim().isEmpty() &&
                !pitchField.getValue().trim().isEmpty() &&
                !soundsPathField.getValue().trim().isEmpty() &&
                !savePathField.getValue().trim().isEmpty() &&
                !renameField.getValue().trim().isEmpty();
        saveBtn.active = valid;
    }

    private void openOggFileDialog() {
        NbeConfig config = ConfigManager.getConfig();
        String basePath = config.resourcePackPath;
        String initialDir = (basePath == null || basePath.isEmpty()) ? "" : basePath + "/assets/minecraft/sounds";

        // ファイルダイアログ呼び出し処理の直前
        try {
            Library.loadSystem("org.lwjgl", "lwjgl_tinyfd");
        } catch (Throwable ignored) {
            // すでにロード済みの場合などの例外を無視
        }

        String result = TinyFileDialogs.tinyfd_openFileDialog(
                "OGG音源ファイルを選択",
                initialDir,
                null,
                "OGG Sound Files (*.ogg)",
                false
        );

        if (result != null && !result.isEmpty()) {
            selectedOggFilePath = result.replace("\\", "/");
            this.soundsPathField.setValue(selectedOggFilePath);
            File f = new File(selectedOggFilePath);
            String nameWithoutExt = f.getName().replace(".ogg", "");
            this.renameField.setValue(nameWithoutExt);
            if (this.soundNameField.getValue().trim().isEmpty() || "custom_sound".equals(this.soundNameField.getValue().trim())) {
                this.soundNameField.setValue(nameWithoutExt);
            }
            updateSaveButtonState();
        }
    }

    private void openSaveFolderDialog() {
        NbeConfig config = ConfigManager.getConfig();
        String basePath = config.resourcePackPath;
        String soundsDir = (basePath == null || basePath.isEmpty()) ? "" : basePath + "/assets/minecraft/sounds";

        // ファイルダイアログ呼び出し処理の直前
        try {
            Library.loadSystem("org.lwjgl", "lwjgl_tinyfd");
        } catch (Throwable ignored) {
            // すでにロード済みの場合などの例外を無視
        }

        String result = TinyFileDialogs.tinyfd_selectFolderDialog("保存先のsoundsサブフォルダを選択", soundsDir);

        if (result != null && !result.isEmpty()) {
            String selectedPath = result.replace("\\", "/");
            String relFolder = extractRelativeSoundFolder(selectedPath, soundsDir);
            this.savePathField.setValue(relFolder);
            updateSaveButtonState();
        }
    }

    private String extractRelativeSoundFolder(String selectedPath, String soundsDir) {
        String normSelected = selectedPath.replace("\\", "/");
        String normSoundsDir = soundsDir.replace("\\", "/");

        if (normSelected.startsWith(normSoundsDir)) {
            String rel = normSelected.substring(normSoundsDir.length());
            if (rel.startsWith("/")) rel = rel.substring(1);
            return rel;
        }
        return normSelected;
    }

    private void saveAndClose() {
        NbeConfig config = ConfigManager.getConfig();
        String blockId = blockIdField.getValue().trim();
        String soundName = soundNameField.getValue().trim();
        String volStr = volumeField.getValue().trim();
        String pitchStr = pitchField.getValue().trim();
        String saveFolder = savePathField.getValue().trim();
        String rename = renameField.getValue().trim();

        if (blockId.isEmpty() || soundName.isEmpty() || saveFolder.isEmpty() || rename.isEmpty()) {
            statusMessage = Component.literal("§cすべての必須項目を入力してください。");
            return;
        }

        double volume = 3.0;
        double pitch = 1.0;
        try { volume = Double.parseDouble(volStr); } catch (Exception ignored) {}
        try { pitch = Double.parseDouble(pitchStr); } catch (Exception ignored) {}

        String soundIdStr = soundName.startsWith("minecraft:") ? soundName : "minecraft:" + soundName;
        String soundKey = soundName.replace("minecraft:", "");

        // 1. ogg ファイルをコピー保存
        if (!selectedOggFilePath.isEmpty() && config.resourcePackPath != null && !config.resourcePackPath.isEmpty()) {
            String relDestPath = saveFolder + "/" + rename + ".ogg";
            File destFile = new File(config.resourcePackPath, "assets/minecraft/sounds/" + relDestPath);
            try {
                File parentDir = destFile.getParentFile();
                if (parentDir != null && !parentDir.exists()) {
                    parentDir.mkdirs();
                }
                Files.copy(new File(selectedOggFilePath).toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                statusMessage = Component.literal("§c.oggファイルのコピーに失敗しました。");
                return;
            }
        }

        // 2. sounds.json に追記保存
        if (config.resourcePackPath != null && !config.resourcePackPath.isEmpty()) {
            File soundsJsonFile = new File(config.resourcePackPath, "assets/minecraft/sounds.json");
            JsonObject soundsObj = new JsonObject();
            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            if (soundsJsonFile.exists()) {
                try (Reader reader = new FileReader(soundsJsonFile)) {
                    JsonObject loaded = JsonParser.parseReader(reader).getAsJsonObject();
                    if (loaded != null) {
                        soundsObj = loaded;
                    }
                } catch (Exception ignored) {}
            }

            JsonObject soundEntry = new JsonObject();
            soundEntry.addProperty("category", "record");
            soundEntry.addProperty("replace", false);

            com.google.gson.JsonArray soundsArray = new com.google.gson.JsonArray();
            String soundPathInJson = saveFolder + "/" + rename;
            soundsArray.add(soundPathInJson);
            soundEntry.add("sounds", soundsArray);

            soundsObj.add(soundKey, soundEntry);

            try {
                File parentDir = soundsJsonFile.getParentFile();
                if (parentDir != null && !parentDir.exists()) {
                    parentDir.mkdirs();
                }
                try (Writer writer = new FileWriter(soundsJsonFile)) {
                    gson.toJson(soundsObj, writer);
                }
            } catch (IOException e) {
                statusMessage = Component.literal("§csounds.jsonの保存に失敗しました。");
                return;
            }
        }

        // 3. notebetterfabric.json に追記保存
        if (config.noteBetterConfigPath != null && !config.noteBetterConfigPath.isEmpty()) {
            File configFile = new File(config.noteBetterConfigPath);
            NoteBetterConfig jsonConfig = new NoteBetterConfig();
            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            if (configFile.exists()) {
                try (Reader reader = new FileReader(configFile)) {
                    NoteBetterConfig loaded = gson.fromJson(reader, NoteBetterConfig.class);
                    if (loaded != null && loaded.mappings != null) {
                        jsonConfig = loaded;
                    }
                } catch (Exception ignored) {}
            }

            if (jsonConfig.mappings == null) jsonConfig.mappings = new ArrayList<>();

            NoteBetterMapping newMapping = new NoteBetterMapping();
            newMapping.block = blockId;
            newMapping.sound = new NoteBetterSound();
            newMapping.sound.sound = soundIdStr;
            newMapping.sound.volume = volume;
            newMapping.sound.pitch = pitch;

            jsonConfig.mappings.add(newMapping);

            try {
                File parentDir = configFile.getParentFile();
                if (parentDir != null && !parentDir.exists()) {
                    parentDir.mkdirs();
                }
                try (Writer writer = new FileWriter(configFile)) {
                    gson.toJson(jsonConfig, writer);
                }
            } catch (IOException e) {
                statusMessage = Component.literal("§cnotebetterfabric.jsonの保存に失敗しました。");
                return;
            }
        }

        closeScreen();
    }

    private void closeScreen() {
        if (this.minecraft != null) {
            parent.init();
            this.minecraft.setScreenAndShow(this.parent);
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta) {
        super.extractRenderState(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        context.centeredText(this.font, this.title, centerX, 12, 0xFFFFFFFF);

        int y = 38;
        context.text(this.font, "対象ブロック:", centerX - 120, y + 3, 0xFFCCCCCC);
        y += 24;
        context.text(this.font, "音源名:", centerX - 120, y + 3, 0xFFCCCCCC);
        y += 24;
        context.text(this.font, "Volume:", centerX - 120, y + 3, 0xFFCCCCCC);
        context.text(this.font, "Pitch:", centerX + 40, y + 3, 0xFFCCCCCC);
        y += 24;
        context.text(this.font, "Sounds Path:", centerX - 120, y + 3, 0xFFCCCCCC);
        y += 24;
        context.text(this.font, "Save Path:", centerX - 120, y + 3, 0xFFCCCCCC);
        y += 24;
        context.text(this.font, "Rename:", centerX - 120, y + 3, 0xFFCCCCCC);

        // ブロックアイコンプレビュー
        String bId = blockIdField.getValue().trim();
        if (!bId.isEmpty()) {
            Identifier rl = Identifier.tryParse(bId);
            if (rl != null) {
                Block b = BuiltInRegistries.BLOCK.getValue(rl);
                if (b != null && b != Blocks.AIR) {
                    ItemStack stack = new ItemStack(b);
                    context.item(stack, centerX - 142, 35);
                }
            }
        }

        if (!statusMessage.getString().isEmpty()) {
            context.centeredText(this.font, statusMessage, centerX, 222, 0xFFFFFF55);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}