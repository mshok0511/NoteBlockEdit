package mshok0511.noteblockedit.config;

import java.util.*;

public class NbeConfig {
    // 最大3つのキーを組み合わせ可能にするためのキーリスト設定
    public List<String> openGuiKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.alt", "key.keyboard.c"));
    public List<String> resetKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.shift", "key.keyboard.r"));

    public String openGuiKey = null;
    public String resetKey = null;

    public Map<String, List<String>> instrumentSets = new LinkedHashMap<>();

    public String resourcePackPath = "";
    public String noteBetterConfigPath = "";

    public boolean isBlueRepeaterEnabled = true;

    public NbeConfig() {
        instrumentSets.put("Harp", new ArrayList<>(Arrays.asList(
                "minecraft:diamond_ore", "minecraft:barrier", "minecraft:diamond_block"
        )));
    }

    public void migrateOldConfig() {
        if (openGuiKey != null && !openGuiKey.isEmpty()) {
            openGuiKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.alt", openGuiKey));
            openGuiKey = null;
        }
        if (resetKey != null && !resetKey.isEmpty()) {
            resetKeys = new ArrayList<>(Arrays.asList("key.keyboard.left.shift", resetKey));
            resetKey = null;
        }
        if (resourcePackPath == null) resourcePackPath = "";
        if (noteBetterConfigPath == null) noteBetterConfigPath = "";
    }
}
