package mshok0511.pointerblock.client.network;

import mshok0511.pointerblock.client.screen.PointerBlockScreen;
import mshok0511.pointerblock.client.screen.TickCounterScreen;
import mshok0511.pointerblock.network.PointerPackets;
import mshok0511.pointerblock.util.PointerDataManager;
import mshok0511.pointerblock.util.PointerState;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;

import java.util.Map;

public class PointerClientPacket {
    @SuppressWarnings("resource")
    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(PointerPackets.OpenPointerScreenPayload.TYPE, (payload, context) -> {
            Minecraft client = context.client();
            client.execute(() -> client.setScreenAndShow(new PointerBlockScreen(payload.pos(), payload.currentName(), payload.targetPos(), payload.facingIndex())));
        });

        ClientPlayNetworking.registerGlobalReceiver(PointerPackets.SyncSettingsPayload.TYPE, (payload, context) -> {
            Minecraft client = context.client();
            client.execute(() -> {
                // 1. 設定値を更新
                PointerState.transparency = payload.transparency();

                if (client.level != null && client.levelRenderer != null) {
                    // シングルプレイサーバーのインスタンスが存在する場合に登録座標を取得
                    if (client.getSingleplayerServer() != null) {
                        Map<String, int[]> pointers = PointerDataManager.getWorldPointers(client.getSingleplayerServer());

                        for (int[] pData : pointers.values()) {
                            BlockPos pos = new BlockPos(pData[0], pData[1], pData[2]);
                            if (client.level.hasChunkAt(pos)) {
                                BlockState state = ((Level) client.level).getBlockState(pos);
                                // クライアント側の World に対してブロック更新を通知（描画再計算をキック）
                                client.level.sendBlockUpdated(pos, state, state, 3);
                            }
                        }
                    }

                    // チャンク全体のセクションキャッシュを無効化
                    client.levelRenderer.sectionOcclusionGraph().invalidate();
                    client.levelRenderer.clearVisibleSections();
                }
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(PointerPackets.OpenTickCounterPayload.TYPE, (payload, context) -> {
            Minecraft client = context.client();
            client.execute(() -> client.setScreenAndShow(new TickCounterScreen(payload.pos(), payload.currentDelay())));
        });
    }
}