package mshok0511.pointerblock.block;

import net.minecraft.world.level.block.RepeaterBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

public class BlueRepeaterBlock extends RepeaterBlock {
    public BlueRepeaterBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected int getDelay(BlockState state) {
        return state.getValue(DELAY) * 3;
    }
}