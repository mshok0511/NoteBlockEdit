package mshok0511.mixin.client;

import mshok0511.noteblockedit.config.ConfigManager;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Mixin(targets = {
        "net.minecraft.server.packs.resources.MultiPackResourceManager",
        "net.minecraft.server.packs.resources.FallbackResourceManager"
})
public abstract class ResourceManagerMixin {

    // 従来の個別取得用フック
    @Inject(method = "getResource", at = @At("HEAD"), cancellable = true)
    private void onGetResource(Identifier id, CallbackInfoReturnable<Optional<Resource>> cir) {
        if (!ConfigManager.getConfig().isBlueRepeaterEnabled) {
            if (id.getNamespace().equals("noteblockedit") && id.getPath().startsWith("textures/") && id.getPath().contains("blue_")) {
                String newPath = id.getPath().replace("blue_", "vanilla_");
                Identifier vanillaId = Identifier.fromNamespaceAndPath(id.getNamespace(), newPath);

                if (this instanceof ResourceProvider provider) {
                    Optional<Resource> resource = provider.getResource(vanillaId);
                    if (resource.isPresent()) {
                        cir.setReturnValue(resource);
                    }
                }
            }
        }
    }

    // アトラス構築時の一括取得用フック
    // 引数（String, Predicate）を省略し、戻り値（CallbackInfoReturnable）のみを受け取ることでシグネチャエラーを回避
    @Inject(method = "listResources", at = @At("RETURN"), cancellable = true)
    private void onListResources(CallbackInfoReturnable<Map<Identifier, Resource>> cir) {
        if (!ConfigManager.getConfig().isBlueRepeaterEnabled) {
            Map<Identifier, Resource> originalMap = cir.getReturnValue();
            if (originalMap == null || originalMap.isEmpty()) return;

            Map<Identifier, Resource> modifiedMap = new HashMap<>(originalMap);
            boolean changed = false;

            for (Map.Entry<Identifier, Resource> entry : originalMap.entrySet()) {
                Identifier id = entry.getKey();
                String namespace = id.getNamespace();
                String filePath = id.getPath();

                // noteblockeditのテクスチャで、blue_が含まれるものを探す
                if (namespace.equals("noteblockedit") && filePath.startsWith("textures/") && filePath.contains("blue_")) {
                    String vanillaPath = filePath.replace("blue_", "vanilla_");
                    Identifier vanillaId = Identifier.fromNamespaceAndPath(namespace, vanillaPath);

                    // vanilla_の画像が存在すればすり替える
                    if (originalMap.containsKey(vanillaId)) {
                        modifiedMap.put(id, originalMap.get(vanillaId));
                        changed = true;
                        System.out.println("[NBE Mixin] アトラス用テクスチャ一括置換発動: " + filePath + " -> " + vanillaPath);
                    }
                }
            }

            // 変更があった場合のみマップを上書きする
            if (changed) {
                cir.setReturnValue(modifiedMap);
            }
        }
    }
}