package mshok0511.manager;

import java.util.*;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class SurveillanceManager {
    // 最終的な統計用の履歴（平均計算用）
    private static final Map<UUID, List<Integer>> recordHistory = new HashMap<>();

    // 現在鳴っている各音の「残り寿命（ティック数）」を管理するリスト
    // 1.20の音符ブロックの減衰に合わせて、約40ティック（2秒）と設定
    private static final Map<UUID, List<Integer>> activeSoundLifetimes = new HashMap<>();

    // そのティックで新しく発生した音の数
    private static final Map<UUID, Integer> newSoundsInTick = new HashMap<>();

    private static final int SOUND_DURATION_TICKS = 40; // 音の持続時間（調整可能）

    public static boolean isMonitoring(UUID uuid) {
        return recordHistory.containsKey(uuid);
    }

    public static void start(class_3222 player) {
        UUID uuid = player.method_5667();
        if (isMonitoring(uuid)) {
            player.method_7353(class_2561.method_43470("soundsSurveillanceは実行中です。"), false);
            return;
        }
        recordHistory.put(uuid, new ArrayList<>());
        activeSoundLifetimes.put(uuid, new ArrayList<>());
        newSoundsInTick.put(uuid, 0);
        player.method_7353(class_2561.method_43470("音符ブロック（残響込み）の監視を開始しました。"), false);
    }

    public static void incrementTickCount(UUID uuid) {
        if (isMonitoring(uuid)) {
            newSoundsInTick.put(uuid, newSoundsInTick.get(uuid) + 1);
        }
    }

    public static void tickEnd() {
        for (UUID uuid : recordHistory.keySet()) {
            List<Integer> lifetimes = activeSoundLifetimes.get(uuid);

            // 1. 既存の音の寿命をすべて1減らす (List.replaceAllを使用)
            lifetimes.replaceAll(life -> life - 1);

            // 2. 寿命が尽きた(0以下)音を削除
            lifetimes.removeIf(life -> life <= 0);

            // 3. このティックで新しく鳴った音をリストに追加
            int newCount = newSoundsInTick.getOrDefault(uuid, 0);
            for (int i = 0; i < newCount; i++) {
                lifetimes.add(SOUND_DURATION_TICKS);
            }

            // 4. 「0」も含めて毎ティック必ず記録する
            int currentTotalVolume = lifetimes.size();
            recordHistory.get(uuid).add(currentTotalVolume);

/*
            0以外をカウントする
            if (currentTotalVolume > 0) {
                recordHistory.get(uuid).add(currentTotalVolume);
            }
*/
            // ティックごとのカウンタをリセット
            newSoundsInTick.put(uuid, 0);
        }
    }

    public static void finish(class_3222 player) {
        UUID uuid = player.method_5667();
        if (!isMonitoring(uuid)) {
            player.method_7353(class_2561.method_43470("soundsSurveillanceは実行されていません。"), false);
            return;
        }

        List<Integer> values = recordHistory.get(uuid);
        if (values.isEmpty()) {
            player.method_7353(class_2561.method_43470("音は検出されませんでした。"), false);
        } else {
            double average = values.stream().mapToDouble(Integer::doubleValue).average().orElse(0.0);
            player.method_7353(class_2561.method_43470(String.format("監視終了。平均同時再生数(残響込): %.2f", average)), false);
        }

        recordHistory.remove(uuid);
        activeSoundLifetimes.remove(uuid);
        newSoundsInTick.remove(uuid);
    }

    public static void resetAll() {
        recordHistory.clear();
        activeSoundLifetimes.clear();
        newSoundsInTick.clear();
    }
}