package mshok0511;

import mshok0511.command.NbeCommand;
import mshok0511.manager.SurveillanceManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;

public class SoundSurveillanceMod implements ModInitializer {
    @Override
    public void onInitialize() {
        // コマンド登録
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            NbeCommand.register(dispatcher);
        });

        // 毎ティック終了時の処理
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            SurveillanceManager.tickEnd();
        });

        // ワールド終了・サーバー停止時のリセット
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            SurveillanceManager.resetAll();
        });
    }
}