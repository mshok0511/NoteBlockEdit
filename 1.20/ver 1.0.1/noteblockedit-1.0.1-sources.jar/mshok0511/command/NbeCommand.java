package mshok0511.command;

import mshok0511.manager.SurveillanceManager;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_3222;
import com.mojang.brigadier.CommandDispatcher;

public class NbeCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("nbe")
                .then(class_2170.method_9247("soundsSurveillance")
                        .then(class_2170.method_9244("target", class_2186.method_9305())
                                .then(class_2170.method_9247("start")
                                        .executes(context -> {
                                            class_3222 target = class_2186.method_9315(context, "target");
                                            SurveillanceManager.start(target);
                                            return 1;
                                        }))
                                .then(class_2170.method_9247("finish")
                                        .executes(context -> {
                                            class_3222 target = class_2186.method_9315(context, "target");
                                            SurveillanceManager.finish(target);
                                            return 1;
                                        }))
                        )
                )
        );
    }
}