package mshok0511.mixin;

import mshok0511.manager.SurveillanceManager;
import net.minecraft.class_2596;
import net.minecraft.class_2767;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public abstract class ServerPlayNetworkHandlerMixin {
    @Shadow public class_3222 player;

    // 引数型を明示的に指定して、曖昧さを解消します
    @Inject(
            method = "sendPacket(Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD")
    )
    private void onSendPacket(class_2596<?> packet, CallbackInfo ci) {
        if (packet instanceof class_2767 soundPacket) {
            class_2960 id = soundPacket.method_11894().comp_349().method_14833();

            if (id != null && id.method_12832().contains("note_block")) {
                SurveillanceManager.incrementTickCount(player.method_5667());
            }
        }
    }
}