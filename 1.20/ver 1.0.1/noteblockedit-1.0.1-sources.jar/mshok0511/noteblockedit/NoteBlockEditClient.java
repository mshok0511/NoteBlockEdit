package mshok0511.noteblockedit;

import mshok0511.noteblockedit.client.SelectionRenderer;
import mshok0511.noteblockedit.client.screen.NbeConfigScreen;
import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.config.NbeConfig;
import mshok0511.noteblockedit.network.NbeNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2561;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class NoteBlockEditClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        SelectionRenderer.register();
        NbeNetworking.registerClientReceivers();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1755 != null) return;

            NbeConfig config = ConfigManager.getConfig();
            long window = client.method_22683().method_4490();

            // --- 判定ロジックの修正 ---

            // 1. 設定画面キー (ALT + 保存されたキー)
            if (isKeyCurrentlyPressed(window, config.openGuiKey)) {
                if (class_3675.method_15987(window, GLFW.GLFW_KEY_LEFT_ALT) ||
                        class_3675.method_15987(window, GLFW.GLFW_KEY_RIGHT_ALT)) {
                    client.method_1507(new NbeConfigScreen(null));
                }
            }

            // Shift + 保存されたキー でリセット
            if (isKeyCurrentlyPressed(window, config.resetKey)) {
                if (class_3675.method_15987(window, GLFW.GLFW_KEY_LEFT_SHIFT) ||
                        class_3675.method_15987(window, GLFW.GLFW_KEY_RIGHT_SHIFT)) {

                    // サーバー側で処理が終わると、同期パケットが返ってきて自動的に枠が消えます
                    NbeNetworking.sendResetRequestC2S();

                    client.field_1724.method_7353(class_2561.method_43470("§b[NBE] 選択範囲と各座標をリセットしました"), true);
                }
            }
        });
    }

    private boolean isKeyCurrentlyPressed(long window, String translationKey) {
        try {
            class_3675.class_306 key = class_3675.method_15981(translationKey);
            return class_3675.method_15987(window, key.method_1444());
        } catch (Exception e) {
            return false;
        }
    }
}