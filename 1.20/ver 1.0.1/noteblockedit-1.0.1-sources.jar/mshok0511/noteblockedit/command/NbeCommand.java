package mshok0511.noteblockedit.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import mshok0511.noteblockedit.util.ModulationHistoryManager;
import mshok0511.noteblockedit.util.ModulationLogic;
import mshok0511.noteblockedit.util.SelectionManager;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import mshok0511.noteblockedit.network.NbeNetworking;

public class NbeCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("nbe")
                // 要件2: modulationSelectArea start/goal
                .then(class_2170.method_9247("modulationSelectArea")
                        .then(class_2170.method_9247("start")
                                .then(class_2170.method_9244("pos", class_2262.method_9698())
                                        .executes(ctx -> setPos(ctx, true, class_2262.method_48299(ctx, "pos"))))
                                .executes(ctx -> {
                                    // 要件2: コマンドブロック（エンティティがnull）等の場合はエラーを投げる
                                    class_3222 player = getPlayerOrThrow(ctx);
                                    return setPos(ctx, true, player.method_24515());
                                }))
                        .then(class_2170.method_9247("goal")
                                .then(class_2170.method_9244("pos", class_2262.method_9698())
                                        .executes(ctx -> setPos(ctx, false, class_2262.method_48299(ctx, "pos"))))
                                .executes(ctx -> {
                                    class_3222 player = getPlayerOrThrow(ctx);
                                    return setPos(ctx, false, player.method_24515());
                                })))

                // 要件3: configコマンド (画面を開くためのトリガー)
                .then(class_2170.method_9247("config")
                        .executes(ctx -> {
                            class_3222 player = ctx.getSource().method_44023();
                            if (player != null) {
                                // サーバーからクライアントへパケットを送信
                                NbeNetworking.sendOpenConfigS2C(player);
                            }
                            return 1;
                        }))

                // 要件5-1: modulationUp [1-24]
                .then(class_2170.method_9247("modulationUp")
                        .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1, 24))
                                .executes(ctx -> {
                                    int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                    int count = ModulationLogic.executeModulation(ctx.getSource(), amount, true);
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§b" + count + " 個の音符ブロックを上げました"), true);
                                    return count;
                                })))

                // 要件5-2: modulationDown [1-24]
                .then(class_2170.method_9247("modulationDown")
                        .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1, 24))
                                .executes(ctx -> {
                                    int amount = IntegerArgumentType.getInteger(ctx, "amount");
                                    int count = ModulationLogic.executeModulation(ctx.getSource(), amount, false);
                                    ctx.getSource().method_9226(() -> class_2561.method_43470("§b" + count + " 個の音符ブロックを下げました"), true);
                                    return count;
                                })))
                // modulationUndo
                .then(class_2170.method_9247("modulationUndo")
                        .then(class_2170.method_9244("count", IntegerArgumentType.integer(1))
                                .executes(ctx -> runUndo(ctx, IntegerArgumentType.getInteger(ctx, "count"))))
                        .executes(ctx -> runUndo(ctx, 1)))

                // modulationRedo
                .then(class_2170.method_9247("modulationRedo")
                        .then(class_2170.method_9244("count", IntegerArgumentType.integer(1))
                                .executes(ctx -> runRedo(ctx, IntegerArgumentType.getInteger(ctx, "count"))))
                        .executes(ctx -> runRedo(ctx, 1)))
        );
    }

    private static int runUndo(CommandContext<class_2168> ctx, int amount) {
        class_3222 player = ctx.getSource().method_44023();
        if (player == null) return 0;

        int result = ModulationHistoryManager.undo(player, amount);
        if (result == -1) {
            ctx.getSource().method_9226(() -> class_2561.method_43470("§c変更履歴が存在しません。"), false);
            return 0;
        }
        ctx.getSource().method_9226(() -> class_2561.method_43470("§b" + result + " 回の操作を元に戻しました。"), false);
        return result;
    }

    private static int runRedo(CommandContext<class_2168> ctx, int amount) {
        class_3222 player = ctx.getSource().method_44023();
        if (player == null) return 0;

        int result = ModulationHistoryManager.redo(player, amount);
        if (result == -1) {
            ctx.getSource().method_9226(() -> class_2561.method_43470("§c変更履歴が存在しません。"), false);
            return 0;
        }
        ctx.getSource().method_9226(() -> class_2561.method_43470("§b" + result + " 回の操作をやり直しました。"), false);
        return result;
    }

    private static int setPos(CommandContext<class_2168> ctx, boolean isStart, class_2338 pos) {
        class_3222 player = ctx.getSource().method_44023();
        if (player == null) return 0;

        // BlockPos ArgumentTypeを使用しているため、posは既に整数(int)のBlockPosオブジェクト
        if (isStart) {
            SelectionManager.setPos1(player, pos);
            ctx.getSource().method_9226(() -> class_2561.method_43470("§c[NBE] Start (赤) を整数座標でセット: " + pos.method_23854()), false);
        } else {
            SelectionManager.setPos2(player, pos);
            ctx.getSource().method_9226(() -> class_2561.method_43470("§a[NBE] Goal (緑) を整数座標でセット: " + pos.method_23854()), false);
        }
        return 1;
    }

    /**
     * 要件2のためのヘルパーメソッド。
     * 実行者がプレイヤーでない（コマンドブロック等）かつ座標が指定されていない場合に例外を投げます。
     */
    private static class_3222 getPlayerOrThrow(CommandContext<class_2168> ctx) throws CommandSyntaxException {
        class_3222 player = ctx.getSource().method_44023();
        if (player == null) {
            throw new SimpleCommandExceptionType(class_2561.method_43470("コマンドブロックから実行する場合は座標を入力してください。")).create();
        }
        return player;
    }
}