package mshok0511.noteblockedit.client;

import net.minecraft.class_2338;

public class ClientSelectionManager {
    private static class_2338 pos1 = null;
    private static class_2338 pos2 = null;

    public static void setPos1(class_2338 pos) { pos1 = pos; }
    public static void setPos2(class_2338 pos) { pos2 = pos; }
    public static class_2338 getPos1() { return pos1; }
    public static class_2338 getPos2() { return pos2; }

    public static void clear() {
        pos1 = null;
        pos2 = null;
    }
}