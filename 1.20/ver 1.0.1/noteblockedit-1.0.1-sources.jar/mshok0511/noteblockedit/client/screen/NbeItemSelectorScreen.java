package mshok0511.noteblockedit.client.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3489;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class NbeItemSelectorScreen extends class_437 {
    private final class_437 parent;
    private final Consumer<List<String>> onConfirm; // 複数選択のために List<String> を受け取るように変更
    private class_342 searchBox;

    private final List<class_1792> allBlocks;
    private List<class_1792> displayItems;
    private final List<class_1792> selectedItems = new ArrayList<>(); // 複数選択用リスト
    private int scrollOffset = 0;

    private enum Category {
        ALL("すべて"), WOOD("木材"), STONE("石材"), ORE("鉱石"), REDSTONE("回路"), DECORATION("装飾");
        final String label;
        Category(String label) { this.label = label; }
    }
    private Category currentCategory = Category.ALL;

    public NbeItemSelectorScreen(class_437 parent, Consumer<List<String>> onConfirm) {
        super(class_2561.method_43470("Block Selector"));
        this.parent = parent;
        this.onConfirm = onConfirm;
        this.allBlocks = new ArrayList<>();
        class_7923.field_41178.forEach(item -> {
            if (item instanceof class_1747) this.allBlocks.add(item);
        });
        this.displayItems = new ArrayList<>(allBlocks);
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;

        this.searchBox = new class_342(this.field_22793, centerX - 100, 15, 200, 20, class_2561.method_43473());
        this.searchBox.method_1863(s -> updateFilter());
        this.method_25429(this.searchBox);

        int btnW = 50;
        int startX = centerX - (btnW * 3);
        for (int i = 0; i < Category.values().length; i++) {
            Category cat = Category.values()[i];
            this.method_37063(class_4185.method_46430(class_2561.method_43470(cat.label), b -> {
                this.currentCategory = cat;
                updateFilter();
            }).method_46434(startX + (i * (btnW + 2)), 40, btnW, 20).method_46431());
        }

        // 下部ボタン
        this.method_37063(class_4185.method_46430(class_2561.method_43470("選択したブロックを追加"), b -> {
            // 選択された全アイテムのIDをリストにして親に返す
            List<String> ids = selectedItems.stream()
                    .map(item -> class_7923.field_41178.method_10221(item).toString())
                    .collect(Collectors.toList());
            onConfirm.accept(ids);
            closeScreen(); // 設定画面に戻る
        }).method_46434(centerX - 105, 210, 100, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("設定画面に戻る"), b -> closeScreen())
                .method_46434(centerX + 5, 210, 100, 20).method_46431());

        updateFilter();
    }

    private void updateFilter() {
        String query = searchBox.method_1882().toLowerCase();
        this.displayItems = allBlocks.stream()
                .filter(item -> {
                    class_2960 id = class_7923.field_41178.method_10221(item);
                    String path = id.method_12832();
                    var entry = class_7923.field_41178.method_47983(item);

                    boolean catMatch = switch (currentCategory) {
                        case ALL -> true;
                        case WOOD -> entry.method_40220(class_3489.field_15537) || entry.method_40220(class_3489.field_15539);
                        case STONE -> (entry.method_40220(class_3489.field_15531) || path.contains("stone"))
                                && !path.contains("redstone") && !path.equals("pointed_dripstone");
                        case ORE -> (path.contains("ore") || entry.method_40220(class_3489.field_23065) || (path.startsWith("raw_") && path.endsWith("_block")))
                                && !path.equals("spore_blossom");
                        case REDSTONE -> path.contains("redstone") || path.contains("piston") || path.contains("repeater") || path.contains("comparator");
                        case DECORATION -> (entry.method_40220(class_3489.field_20344) || entry.method_40220(class_3489.field_15558)) && !entry.method_40220(class_3489.field_16444);
                    };
                    return catMatch && id.toString().contains(query);
                })
                .collect(Collectors.toList());
        this.scrollOffset = 0;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);
        int centerX = this.field_22789 / 2;
        this.searchBox.method_25394(context, mouseX, mouseY, delta);
        context.method_25303(this.field_22793, "カテゴリー:", centerX - 205, 45, 0xFFFFFF);

        int startX = centerX - 90;
        int startY = 70;
        int columns = 9;
        int rows = 6;

        for (int i = 0; i < columns * rows; i++) {
            int index = i + (scrollOffset * columns);
            if (index >= displayItems.size()) break;

            class_1792 item = displayItems.get(index);
            int x = startX + (i % columns) * 20;
            int y = startY + (i / columns) * 20;

            // 複数選択されているものを緑色でハイライト
            if (selectedItems.contains(item)) {
                context.method_25294(x - 2, y - 2, x + 18, y + 18, 0x8000FF00);
            }

            context.method_51427(new class_1799(item), x, y);

            if (mouseX >= x && mouseX <= x + 16 && mouseY >= y && mouseY <= y + 16) {
                context.method_25294(x, y, x + 16, y + 16, 0x40FFFFFF);
                context.method_51438(this.field_22793, item.method_7848(), mouseX, mouseY);
            }
        }

        // 選択中の個数を表示
        context.method_25303(this.field_22793, "選択中: " + selectedItems.size() + "個", centerX + 110, 215, 0xFFFF00);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int startX = this.field_22789 / 2 - 90;
        int startY = 70;
        int columns = 9;
        int rows = 6;

        for (int i = 0; i < columns * rows; i++) {
            int index = i + (scrollOffset * columns);
            if (index >= displayItems.size()) break;

            int x = startX + (i % columns) * 20;
            int y = startY + (i / columns) * 20;

            if (mouseX >= x && mouseX <= x + 16 && mouseY >= y && mouseY <= y + 16) {
                class_1792 item = displayItems.get(index);
                // 既に選択されていたら削除、なければ追加（要件のトグル動作）
                if (selectedItems.contains(item)) {
                    selectedItems.remove(item);
                } else {
                    selectedItems.add(item);
                }
                return true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double amount) {
        if (amount > 0 && scrollOffset > 0) scrollOffset--;
        else if (amount < 0 && (scrollOffset + 6) * 9 < displayItems.size()) scrollOffset++;
        return true;
    }

    private void closeScreen() {
        class_310.method_1551().method_1507(this.parent);
    }
}