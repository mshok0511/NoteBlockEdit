package mshok0511.noteblockedit.client.screen;

import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.config.NbeConfig;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class NbeConfigScreen extends class_437 {
    private final class_437 parent;
    private class_4185 openGuiKeyBtn;
    private class_4185 resetKeyBtn;
    private String tempOpenGuiKey;
    private String tempResetKey;
    private String waitingForKeyFor = null;

    private class_342 groupNameField;
    private final List<String> groupNames = new ArrayList<>();
    private int currentGroupIndex = 0;
    private final List<String> currentBlocks = new ArrayList<>();

    private class_2561 statusMessage = class_2561.method_43473();

    public NbeConfigScreen(class_437 parent) {
        super(class_2561.method_43470("NoteBlockEdit Config"));
        this.parent = parent;
        NbeConfig config = ConfigManager.getConfig();
        this.tempOpenGuiKey = config.openGuiKey;
        this.tempResetKey = config.resetKey;
    }

    @Override
    protected void method_25426() {
        NbeConfig config = ConfigManager.getConfig();
        int centerX = this.field_22789 / 2;

        // 1. キーバインドセクション (Y=40-60)
        this.openGuiKeyBtn = this.method_37063(class_4185.method_46430(getFriendlyKeyName("open", tempOpenGuiKey), button -> {
            this.waitingForKeyFor = "open";
            updateButtonLabels();
        }).method_46434(centerX - 100, 55, 95, 20).method_46431());

        this.resetKeyBtn = this.method_37063(class_4185.method_46430(getFriendlyKeyName("reset", tempResetKey), button -> {
            this.waitingForKeyFor = "reset";
            updateButtonLabels();
        }).method_46434(centerX + 5, 55, 95, 20).method_46431());

        // 2. 楽器グループセクション (Y=90)
        groupNames.clear();
        groupNames.addAll(config.instrumentSets.keySet());
        if (groupNames.isEmpty()) {
            groupNames.add("Harp");
            config.instrumentSets.put("Harp", new ArrayList<>());
        }

        this.method_37063(class_4185.method_46430(class_2561.method_43470("<"), b -> changeGroup(-1)).method_46434(centerX - 100, 93, 20, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470(">"), b -> changeGroup(1)).method_46434(centerX + 80, 93, 20, 20).method_46431());

        this.groupNameField = new class_342(this.field_22793, centerX - 75, 93, 150, 20, class_2561.method_43473());
        this.method_37063(this.groupNameField);

        // 3. ブロック選択ボタン (Y=145)
        this.method_37063(class_4185.method_46430(class_2561.method_43470("ブロックを追加..."), b -> {
            // NbeItemSelectorScreen を開く。コールバックで選択された全IDリストを受け取る。
            Objects.requireNonNull(this.field_22787).method_1507(new NbeItemSelectorScreen(this, (newIds) -> {
                // 返ってきたIDリストを現在のリストに追加する
                this.currentBlocks.addAll(newIds);
                // 念のためメモリにも反映
                saveCurrentGroupToMemory();
            }));
        }).method_46434(centerX - 100, 147, 95, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("リストを空にする"), b -> currentBlocks.clear())
                .method_46434(centerX + 5, 147, 95, 20).method_46431());

        // 追加・削除ボタン
        this.method_37063(class_4185.method_46430(class_2561.method_43470("グループ追加"), b -> addGroup()).method_46434(centerX - 100, 172, 95, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("グループ削除"), b -> deleteGroup()).method_46434(centerX + 5, 172, 95, 20).method_46431());

        // 4. 保存・キャンセル (Y=210)
        this.method_37063(class_4185.method_46430(class_2561.method_43470("保存する"), b -> { saveConfig(); this.statusMessage = class_2561.method_43470("§a設定を保存しました"); }).method_46434(centerX - 155, 210, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("保存して閉じる"), b -> { saveConfig(); closeScreen(); }).method_46434(centerX - 50, 210, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("キャンセル"), b -> closeScreen()).method_46434(centerX + 55, 210, 100, 20).method_46431());

        updateGroupFields();
    }

    private void changeGroup(int delta) {
        saveCurrentGroupToMemory();
        currentGroupIndex = (currentGroupIndex + delta + groupNames.size()) % groupNames.size();
        updateGroupFields();
    }

    private void updateGroupFields() {
        String name = groupNames.get(currentGroupIndex);
        groupNameField.method_1852(name);
        currentBlocks.clear();
        List<String> blocks = ConfigManager.getConfig().instrumentSets.get(name);
        if (blocks != null) currentBlocks.addAll(blocks);
    }

    private void saveCurrentGroupToMemory() {
        NbeConfig config = ConfigManager.getConfig();
        if (groupNames.isEmpty()) return;
        String oldName = groupNames.get(currentGroupIndex);
        String newName = groupNameField.method_1882();
        config.instrumentSets.remove(oldName);
        config.instrumentSets.put(newName, new ArrayList<>(currentBlocks));
        groupNames.set(currentGroupIndex, newName);
    }

    private void saveConfig() {
        saveCurrentGroupToMemory();
        NbeConfig config = ConfigManager.getConfig();
        config.openGuiKey = tempOpenGuiKey;
        config.resetKey = tempResetKey;
        ConfigManager.save();
    }

    private void addGroup() {
        saveCurrentGroupToMemory();
        String name = "NewGroup" + (groupNames.size() + 1);
        ConfigManager.getConfig().instrumentSets.put(name, new ArrayList<>());
        groupNames.add(name);
        currentGroupIndex = groupNames.size() - 1;
        updateGroupFields();
    }

    private void deleteGroup() {
        if (groupNames.size() > 1) {
            ConfigManager.getConfig().instrumentSets.remove(groupNames.get(currentGroupIndex));
            groupNames.remove(currentGroupIndex);
            currentGroupIndex = 0;
            updateGroupFields();
        }
    }

    private void closeScreen() { if (this.field_22787 != null) this.field_22787.method_1507(this.parent); }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (waitingForKeyFor != null) {
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                String keyName = class_3675.method_15985(keyCode, scanCode).method_1441();
                if (waitingForKeyFor.equals("open")) tempOpenGuiKey = keyName;
                else if (waitingForKeyFor.equals("reset")) tempResetKey = keyName;
            }
            waitingForKeyFor = null;
            updateButtonLabels();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private void updateButtonLabels() {
        if (openGuiKeyBtn != null) openGuiKeyBtn.method_25355(waitingForKeyFor != null && waitingForKeyFor.equals("open") ? class_2561.method_43470("> ??? <") : getFriendlyKeyName("open", tempOpenGuiKey));
        if (resetKeyBtn != null) resetKeyBtn.method_25355(waitingForKeyFor != null && waitingForKeyFor.equals("reset") ? class_2561.method_43470("> ??? <") : getFriendlyKeyName("reset", tempResetKey));
    }

    private class_2561 getFriendlyKeyName(String type, String translationKey) {
        String baseName;
        try { baseName = class_3675.method_15981(translationKey).method_27445().getString().toUpperCase(); } catch (Exception e) { baseName = "???"; }
        return class_2561.method_43470((type.equals("open") ? "ALT + " : "SHIFT + ") + baseName);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);
        int centerX = this.field_22789 / 2;

        context.method_27534(this.field_22793, this.field_22785, centerX, 10, 0xFFFFFF);

        // ラベル (重ならないように配置)
        context.method_25303(this.field_22793, "ショートカットキー設定:", centerX - 100, 32, 0xA0A0A0);

        context.method_25303(this.field_22793, "設定画面を開く", centerX - 100, 45, 0xFFFFFF);
        context.method_25303(this.field_22793, "選択範囲のリセット", centerX + 5, 45, 0xFFFFFF);

        context.method_25303(this.field_22793, "楽器グループ設定:", centerX - 100, 80, 0xA0A0A0);
        context.method_25303(this.field_22793, "登録ブロック (クリックで削除):", centerX - 100, 120, 0xA0A0A0);

        // --- 楽器セットのアイコン表示 ---
        int startX = centerX - 100;
        int startY = 130;
        for (int i = 0; i < currentBlocks.size(); i++) {
            int x = startX + (i % 10) * 20;
            int y = startY + (i / 10) * 20;
            if (y > 140) break; // 2行以上は表示しない（簡易化）

            class_2960 id = new class_2960(currentBlocks.get(i));
            class_1799 stack = new class_1799(class_7923.field_41178.method_10223(id));

            // アイコン描画
            context.method_51427(stack, x, y);

            // マウスオーバーで削除判定
            if (mouseX >= x && mouseX <= x + 16 && mouseY >= y && mouseY <= y + 16) {
                context.method_25294(x, y, x + 16, y + 16, 0x50FF0000);
            }
        }

        context.method_27534(this.field_22793, this.statusMessage, centerX, 195, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int centerX = this.field_22789 / 2;
        int startX = centerX - 100;
        int startY = 130;
        for (int i = 0; i < currentBlocks.size(); i++) {
            int x = startX + (i % 10) * 20;
            int y = startY + (i / 10) * 20;
            if (mouseX >= x && mouseX <= x + 16 && mouseY >= y && mouseY <= y + 16) {
                currentBlocks.remove(i);
                return true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }
}