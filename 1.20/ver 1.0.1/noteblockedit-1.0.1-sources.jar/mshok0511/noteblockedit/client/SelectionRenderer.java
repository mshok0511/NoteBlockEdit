package mshok0511.noteblockedit.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

public class SelectionRenderer {

    public static void register() {
        // AFTER_TRANSLUCENT（半透明描画後）または LAST（最後）で描画することで
        // 他のオブジェクトとの描画順序を安定させます
        WorldRenderEvents.LAST.register(context -> {
            class_2338 p1 = ClientSelectionManager.getPos1();
            class_2338 p2 = ClientSelectionManager.getPos2();
            if (p1 == null && p2 == null) return;

            class_4587 matrices = context.matrixStack();
            class_243 cameraPos = context.camera().method_19326();
            class_4597 consumers = context.consumers();
            if (consumers == null) return;

            // 線描画用のバッファ（深度テストあり、常に地形に重なる）
            class_4588 lines = consumers.getBuffer(class_1921.method_23594());

            matrices.method_22903();

            // 重要：カメラの相対位置への移動を double の精度で維持しつつ
            // MatrixStack に直接適用してズレを防ぎます
            matrices.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);

            // 1. Start地点 (赤色)
            if (p1 != null) {
                drawPrecisionBox(matrices, lines, p1, p1, 1.0f, 0.0f, 0.0f);
            }

            // 2. Goal地点 (黄緑色)
            if (p2 != null) {
                drawPrecisionBox(matrices, lines, p2, p2, 0.6f, 1.0f, 0.0f);
            }

            // 3. 全体範囲 (水色)
            if (p1 != null && p2 != null) {
                drawPrecisionBox(matrices, lines, p1, p2, 0.0f, 1.0f, 1.0f);
            }

            matrices.method_22909();
        });
    }

    /**
     * ブロックの格子に完全に一致させるための精密描画メソッド
     */
    private static void drawPrecisionBox(class_4587 matrices, class_4588 vertexConsumer, class_2338 pos1, class_2338 pos2, float r, float g, float b) {
        // 整数座標の最小・最大を特定
        int minX = Math.min(pos1.method_10263(), pos2.method_10263());
        int minY = Math.min(pos1.method_10264(), pos2.method_10264());
        int minZ = Math.min(pos1.method_10260(), pos2.method_10260());

        int maxX = Math.max(pos1.method_10263(), pos2.method_10263()) + 1;
        int maxY = Math.max(pos1.method_10264(), pos2.method_10264()) + 1;
        int maxZ = Math.max(pos1.method_10260(), pos2.method_10260()) + 1;

        // 描画時のZ-fighting（チラつき）を防ぐための極小のオフセット
        // 0.001f よりも小さい値に設定し、見た目上は「完全に重なっている」状態にします
        float offset = 0.001f;

        float x1 = (float)minX - offset;
        float y1 = (float)minY - offset;
        float z1 = (float)minZ - offset;
        float x2 = (float)maxX + offset;
        float y2 = (float)maxY + offset;
        float z2 = (float)maxZ + offset;

        Matrix4f model = matrices.method_23760().method_23761();

        // 12本の線を手動で定義することで、WorldRenderer.drawBox よりも安定した制御を行います
        // 下面
        line(model, vertexConsumer, x1, y1, z1, x2, y1, z1, r, g, b);
        line(model, vertexConsumer, x2, y1, z1, x2, y1, z2, r, g, b);
        line(model, vertexConsumer, x2, y1, z2, x1, y1, z2, r, g, b);
        line(model, vertexConsumer, x1, y1, z2, x1, y1, z1, r, g, b);
        // 上面
        line(model, vertexConsumer, x1, y2, z1, x2, y2, z1, r, g, b);
        line(model, vertexConsumer, x2, y2, z1, x2, y2, z2, r, g, b);
        line(model, vertexConsumer, x2, y2, z2, x1, y2, z2, r, g, b);
        line(model, vertexConsumer, x1, y2, z2, x1, y2, z1, r, g, b);
        // 柱
        line(model, vertexConsumer, x1, y1, z1, x1, y2, z1, r, g, b);
        line(model, vertexConsumer, x2, y1, z1, x2, y2, z1, r, g, b);
        line(model, vertexConsumer, x2, y1, z2, x2, y2, z2, r, g, b);
        line(model, vertexConsumer, x1, y1, z2, x1, y2, z2, r, g, b);
    }

    private static void line(Matrix4f model, class_4588 buffer, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b) {
        buffer.method_22918(model, x1, y1, z1).method_22915(r, g, b, 1.0f).method_22914(0, 0, 0).method_1344();
        buffer.method_22918(model, x2, y2, z2).method_22915(r, g, b, 1.0f).method_22914(0, 0, 0).method_1344();
    }
}