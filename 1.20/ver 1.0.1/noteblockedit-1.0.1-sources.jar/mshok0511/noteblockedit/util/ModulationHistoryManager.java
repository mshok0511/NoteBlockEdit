package mshok0511.noteblockedit.util;

import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class ModulationHistoryManager {
    // 1つの操作による全ブロック変更の記録
    public static record BlockChange(class_2338 pos, class_2680 oldState, class_2680 newState) {}

    // プレイヤーUUIDごとのUndo/Redoスタック
    private static final Map<UUID, Deque<List<BlockChange>>> undoStacks = new HashMap<>();
    private static final Map<UUID, Deque<List<BlockChange>>> redoStacks = new HashMap<>();

    private static final int MAX_HISTORY = 20; // 履歴の最大保持数

    public static void pushHistory(UUID uuid, List<BlockChange> changes) {
        undoStacks.computeIfAbsent(uuid, k -> new ArrayDeque<>()).push(changes);
        if (undoStacks.get(uuid).size() > MAX_HISTORY) undoStacks.get(uuid).removeLast();
        redoStacks.remove(uuid); // 新しい操作をしたらRedo履歴は消去
    }

    public static int undo(class_3222 player, int amount) {
        Deque<List<BlockChange>> stack = undoStacks.get(player.method_5667());
        if (stack == null || stack.isEmpty()) return -1;

        int count = 0;
        for (int i = 0; i < amount && !stack.isEmpty(); i++) {
            List<BlockChange> changes = stack.pop();
            // 戻す前に現在の状態をRedo用に保存
            redoStacks.computeIfAbsent(player.method_5667(), k -> new ArrayDeque<>()).push(changes);

            // ブロックを古い状態に戻す
            for (BlockChange change : changes) {
                player.method_37908().method_8501(change.pos, change.oldState);
            }
            count++;
        }
        return count;
    }

    public static int redo(class_3222 player, int amount) {
        Deque<List<BlockChange>> stack = redoStacks.get(player.method_5667());
        if (stack == null || stack.isEmpty()) return -1;

        int count = 0;
        for (int i = 0; i < amount && !stack.isEmpty(); i++) {
            List<BlockChange> changes = stack.pop();
            undoStacks.computeIfAbsent(player.method_5667(), k -> new ArrayDeque<>()).push(changes);

            // ブロックを新しい状態（変調後）にする
            for (BlockChange change : changes) {
                player.method_37908().method_8501(change.pos, change.newState);
            }
            count++;
        }
        return count;
    }
}