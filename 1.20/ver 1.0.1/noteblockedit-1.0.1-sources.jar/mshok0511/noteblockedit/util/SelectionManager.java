package mshok0511.noteblockedit.util;

import mshok0511.noteblockedit.network.NbeNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SelectionManager {
    private static final Map<UUID, class_2338> pos1 = new HashMap<>();
    private static final Map<UUID, class_2338> pos2 = new HashMap<>();

    // プレイヤーエンティティを受け取るように変更（同期のため）
    public static void setPos1(class_3222 player, class_2338 pos) {
        pos1.put(player.method_5667(), pos);
        // 要件1: クライアントに通知して枠を表示させる
        syncToClient(player);
    }

    public static void setPos2(class_3222 player, class_2338 pos) {
        pos2.put(player.method_5667(), pos);
        // 要件1: クライアントに通知して枠を表示させる
        syncToClient(player);
    }

    public static class_2338 getPos1(UUID player) { return pos1.get(player); }
    public static class_2338 getPos2(UUID player) { return pos2.get(player); }

    public static void clear(class_3222 player) {
        pos1.remove(player.method_5667());
        pos2.remove(player.method_5667());
        syncToClient(player);
    }

    private static void syncToClient(class_3222 player) {
        class_2338 p1 = pos1.get(player.method_5667());
        class_2338 p2 = pos2.get(player.method_5667());
        // ネットワーク経由でクライアント側の ClientSelectionManager を更新する
        NbeNetworking.sendSelectionS2C(player, p1, p2);
    }
}