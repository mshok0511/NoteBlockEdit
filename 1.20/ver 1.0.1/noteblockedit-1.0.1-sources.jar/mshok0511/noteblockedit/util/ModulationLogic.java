package mshok0511.noteblockedit.util;

import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.config.NbeConfig;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2428;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ModulationLogic {

    public static int executeModulation(class_2168 source, int amount, boolean isUp) {
        class_3218 world = source.method_9225();
        if (source.method_44023() == null) return 0;

        class_2338 p1 = SelectionManager.getPos1(source.method_44023().method_5667());
        class_2338 p2 = SelectionManager.getPos2(source.method_44023().method_5667());

        if (p1 == null || p2 == null) {
            source.method_9213(class_2561.method_43470("エリアが選択されていません。"));
            return 0;
        }

        int minX = Math.min(p1.method_10263(), p2.method_10263());
        int maxX = Math.max(p1.method_10263(), p2.method_10263());
        int minY = Math.min(p1.method_10264(), p2.method_10264());
        int maxY = Math.max(p1.method_10264(), p2.method_10264());
        int minZ = Math.min(p1.method_10260(), p2.method_10260());
        int maxZ = Math.max(p1.method_10260(), p2.method_10260());

        NbeConfig config = ConfigManager.getConfig();
        List<ModulationHistoryManager.BlockChange> history = new ArrayList<>();
        int affectedCount = 0;

        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    class_2338 notePos = new class_2338(x, y, z);
                    class_2680 noteState = world.method_8320(notePos);

                    if (noteState.method_27852(class_2246.field_10179)) {
                        class_2338 basePos = notePos.method_10074();
                        // 5-3: 下のブロックがエリア外なら対象外
                        if (basePos.method_10263() < minX || basePos.method_10263() > maxX ||
                                basePos.method_10264() < minY || basePos.method_10264() > maxY ||
                                basePos.method_10260() < minZ || basePos.method_10260() > maxZ) continue;

                        class_2680 baseState = world.method_8320(basePos);

                        // 履歴を記録しながら変調処理を実行
                        if (processAndRecord(source, world, notePos, basePos, noteState, baseState, config, amount, isUp, history)) {
                            affectedCount++;
                        }
                    }
                }
            }
        }

        // 変更があった場合のみ履歴スタックに積む
        if (!history.isEmpty()) {
            ModulationHistoryManager.pushHistory(source.method_44023().method_5667(), history);
        }

        return affectedCount;
    }

    private static boolean processAndRecord(class_2168 source, class_3218 world, class_2338 notePos, class_2338 basePos,
                                            class_2680 noteState, class_2680 baseState, NbeConfig config,
                                            int amount, boolean isUp, List<ModulationHistoryManager.BlockChange> history) {

        String baseId = class_7923.field_41175.method_10221(baseState.method_26204()).toString();

        for (Map.Entry<String, List<String>> entry : config.instrumentSets.entrySet()) {
            List<String> blocks = entry.getValue();
            if (blocks.contains(baseId)) {
                int currentNote = noteState.method_11654(class_2428.field_11324);
                int targetNote = isUp ? (currentNote + amount) : (currentNote - amount);
                boolean wrapped = false;

                // 5-1-2, 5-2-2: ラップアラウンド処理
                if (targetNote > 24) {
                    targetNote -= 24;
                    wrapped = true;
                } else if (targetNote < 0) {
                    targetNote += 24;
                    wrapped = true;
                }

                // 変更後の音符ブロック状態
                class_2680 newNoteState = noteState.method_11657(class_2428.field_11324, targetNote);

                // 履歴に記録 (音符ブロックの変更)
                history.add(new ModulationHistoryManager.BlockChange(notePos, noteState, newNoteState));
                world.method_8501(notePos, newNoteState);

                // 5-1-3, 5-2-3: ブロック置換
                if (wrapped) {
                    int currentIndex = blocks.indexOf(baseId);
                    int nextIndex = isUp ? currentIndex + 1 : currentIndex - 1;

                    if (nextIndex >= 0 && nextIndex < blocks.size()) {
                        class_2248 nextBlock = class_7923.field_41175.method_10223(new class_2960(blocks.get(nextIndex)));
                        class_2680 newBaseState = nextBlock.method_9564();

                        // 履歴に記録 (下のブロックの変更)
                        history.add(new ModulationHistoryManager.BlockChange(basePos, baseState, newBaseState));
                        world.method_8501(basePos, newBaseState);
                    } else {
                        // 失敗時の座標表示
                        source.method_9226(() -> class_2561.method_43470("§c置換失敗(範囲外): " + basePos.method_23854()), false);
                    }
                }
                return true;
            }
        }
        return false;
    }
}