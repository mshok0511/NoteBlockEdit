package mshok0511.noteblockedit.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Path;

public class ConfigManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("NoteBlockEdit");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // 要件: ファイル名を noteblockeditConfig.json に変更
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("noteblockeditConfig.json");

    private static NbeConfig config = new NbeConfig();

    /**
     * 設定ファイルを読み込みます。ワールド起動時や設定変更時に呼び出します。
     */
    public static void load() {
        File configFile = CONFIG_PATH.toFile();
        if (configFile.exists()) {
            try (Reader reader = new FileReader(configFile)) {
                NbeConfig loadedConfig = GSON.fromJson(reader, NbeConfig.class);
                if (loadedConfig != null) {
                    config = loadedConfig;
                }
            } catch (IOException e) {
                LOGGER.error("[NBE] 設定ファイルの読み込みに失敗しました: ", e);
            }
        } else {
            // ファイルがない場合はデフォルトを生成して保存
            save();
        }
    }

    /**
     * 現在のメモリ上の設定を JSON ファイルに保存します。
     */
    public static void save() {
        try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(config, writer);
        } catch (IOException e) {
            LOGGER.error("[NBE] 設定ファイルの保存に失敗しました: ", e);
        }
    }

    /**
     * 常に最新のデータを取得するために、取得前に再ロードすることも可能ですが、
     * 基本的にはこのインスタンスを介してアクセスします。
     */
    public static NbeConfig getConfig() {
        return config;
    }
}