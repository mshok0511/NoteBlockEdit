package mshok0511.noteblockedit.config;

import java.util.*;

public class NbeConfig {
    // toolId を削除
    public String openGuiKey = "key.keyboard.c";
    public String resetKey = "key.keyboard.c";
    public Map<String, List<String>> instrumentSets = new LinkedHashMap<>();

    public NbeConfig() {
        // デフォルト設定
        instrumentSets.put("Harp", new ArrayList<>(Arrays.asList(
                "minecraft:diamond_ore", "minecraft:barrier", "minecraft:diamond_block"
        )));
    }
}