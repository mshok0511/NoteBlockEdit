package mshok0511.noteblockedit;

import mshok0511.noteblockedit.command.NbeCommand;
import mshok0511.noteblockedit.config.ConfigManager;
import mshok0511.noteblockedit.util.SelectionManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

public class NoteBlockEdit implements ModInitializer {
    @Override
    public void onInitialize() {
        ConfigManager.load();
        mshok0511.noteblockedit.network.NbeNetworking.registerServerReceivers();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> NbeCommand.register(dispatcher));

        // 1. 左クリック時：木の剣で破壊検知して復元
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (!world.field_9236 && isHoldingWoodenSword(player) && hand == class_1268.field_5808) {
                class_2680 originalState = world.method_8320(pos);
                SelectionManager.setPos1((class_3222) player, pos);
                player.method_7353(class_2561.method_43470("§c[NBE] Start (赤) をセットしました"), true);

                // 復元処理
                world.method_8652(pos, originalState, class_2248.field_31028 | class_2248.field_31031);
                return class_1269.field_5814;
            }
            return class_1269.field_5811;
        });

        // 2. 右クリック時：木の剣で変更検知して復元
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.field_9236 && isHoldingWoodenSword(player) && hand == class_1268.field_5808) {
                class_2338 pos = hitResult.method_17777();
                class_2680 originalState = world.method_8320(pos);
                SelectionManager.setPos2((class_3222) player, pos);
                player.method_7353(class_2561.method_43470("§a[NBE] Goal (緑) をセットしました"), true);

                // 復元処理
                world.method_8652(pos, originalState, class_2248.field_31028 | class_2248.field_31031);
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        });
    }

    private boolean isHoldingWoodenSword(net.minecraft.class_1657 player) {
        // 木の剣に固定
        return player.method_5998(class_1268.field_5808).method_31574(class_1802.field_8091);
    }
}