package mshok0511.noteblockedit.network;

import mshok0511.noteblockedit.client.ClientSelectionManager;
import mshok0511.noteblockedit.client.screen.NbeConfigScreen;
import mshok0511.noteblockedit.util.SelectionManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class NbeNetworking {
    // パケットIDの定義
    public static final class_2960 SELECTION_SYNC_ID = new class_2960("noteblockedit", "selection_sync");
    public static final class_2960 OPEN_CONFIG_ID = new class_2960("noteblockedit", "open_config");
    public static final class_2960 RESET_REQUEST_ID = new class_2960("noteblockedit", "reset_request");

    /**
     * S2C: サーバーからクライアントへ座標を同期する
     */
    public static void sendSelectionS2C(class_3222 player, class_2338 p1, class_2338 p2) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeBoolean(p1 != null);
        if (p1 != null) buf.method_10807(p1);
        buf.writeBoolean(p2 != null);
        if (p2 != null) buf.method_10807(p2);
        ServerPlayNetworking.send(player, SELECTION_SYNC_ID, buf);
    }

    /**
     * S2C: サーバーからクライアントへ「設定画面を開け」と命令する (NbeCommandから呼ばれる)
     */
    public static void sendOpenConfigS2C(class_3222 player) {
        // 中身は空のパケットでOK
        ServerPlayNetworking.send(player, OPEN_CONFIG_ID, PacketByteBufs.empty());
    }

    /**
     * C2S: クライアントからサーバーへ「座標をリセットして」とリクエストする
     */
    public static void sendResetRequestC2S() {
        ClientPlayNetworking.send(RESET_REQUEST_ID, PacketByteBufs.empty());
    }

    /**
     * サーバー側でパケットを受け取る設定 (NoteBlockEdit.java の onInitialize で呼ぶ)
     */
    public static void registerServerReceivers() {
        ServerPlayNetworking.registerGlobalReceiver(RESET_REQUEST_ID, (server, player, handler, buf, responseSender) -> {
            server.execute(() -> {
                // サーバー側のデータを消去し、同期パケットを飛ばす
                SelectionManager.clear(player);
            });
        });
    }

    /**
     * クライアント側でパケットを受け取る設定 (NoteBlockEditClient.java の onInitializeClient で呼ぶ)
     */
    public static void registerClientReceivers() {
        // 座標同期を受け取る
        ClientPlayNetworking.registerGlobalReceiver(SELECTION_SYNC_ID, (client, handler, buf, responseSender) -> {
            class_2338 p1 = buf.readBoolean() ? buf.method_10811() : null;
            class_2338 p2 = buf.readBoolean() ? buf.method_10811() : null;
            client.execute(() -> {
                ClientSelectionManager.setPos1(p1);
                ClientSelectionManager.setPos2(p2);
            });
        });

        // 設定画面を開く命令を受け取る
        ClientPlayNetworking.registerGlobalReceiver(OPEN_CONFIG_ID, (client, handler, buf, responseSender) -> {
            client.execute(() -> {
                // 親画面なし(null)で設定画面を表示
                client.method_1507(new NbeConfigScreen(null));
            });
        });
    }
}