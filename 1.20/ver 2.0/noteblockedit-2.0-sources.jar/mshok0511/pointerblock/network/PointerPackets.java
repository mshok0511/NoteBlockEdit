package mshok0511.pointerblock.network;

import mshok0511.pointerblock.PointerBlockMod;
import net.minecraft.class_2960;

public class PointerPackets {
    public static final class_2960 SAVE_POINTER_DATA = new class_2960(PointerBlockMod.MOD_ID, "save_pointer_data");
    public static final class_2960 OPEN_POINTER_SCREEN = new class_2960(PointerBlockMod.MOD_ID, "open_pointer_screen");
    public static final class_2960 SYNC_SETTINGS = new class_2960(PointerBlockMod.MOD_ID, "sync_settings");
    public static final class_2960 OPEN_TICK_COUNTER = new class_2960(PointerBlockMod.MOD_ID, "open_tick_counter");
    public static final class_2960 SAVE_TICK_COUNTER = new class_2960(PointerBlockMod.MOD_ID, "save_tick_counter");
}