package mshok0511.pointerblock.block;

import mshok0511.pointerblock.PointerBlockMod;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PointerBlockEntity extends class_2586 {
    public static final Map<class_2338, PointerBlockEntity> TRACKED_POINTERS = new ConcurrentHashMap<>();

    private String pointerName;
    private class_2338 targetPos;

    public PointerBlockEntity(class_2338 pos, class_2680 state) {
        super(PointerBlockMod.POINTER_BLOCK_ENTITY_TYPE, pos, state);
        this.targetPos = pos;
        this.pointerName = pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260();
        TRACKED_POINTERS.put(pos.method_10062(), this);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        this.pointerName = nbt.method_10558("PointerName");
        this.targetPos = class_2338.method_10092(nbt.method_10537("TargetPos"));
        TRACKED_POINTERS.put(this.field_11867.method_10062(), this);
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        nbt.method_10582("PointerName", pointerName);
        nbt.method_10544("TargetPos", targetPos.method_10063());
        super.method_11007(nbt);
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() { return class_2622.method_38585(this); }
    @Override
    public class_2487 method_16887() { return method_38244(); }

    public String getPointerName() { return pointerName; }
    public void setPointerName(String name) { this.pointerName = name; method_5431(); sync(); }
    public class_2338 getTargetPos() { return targetPos; }
    public void setTargetPos(class_2338 pos) { this.targetPos = pos; method_5431(); sync(); }

    private void sync() {
        if (this.field_11863 != null && !this.field_11863.field_9236) {
            this.field_11863.method_8413(this.field_11867, method_11010(), method_11010(), 3);
        }
    }

    @Override
    public void method_11012() {
        super.method_11012();
        TRACKED_POINTERS.remove(this.field_11867);
    }
}