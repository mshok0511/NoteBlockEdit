package mshok0511.pointerblock.block;

import mshok0511.pointerblock.network.PointerPackets;
import mshok0511.pointerblock.util.PointerDataManager;
import mshok0511.pointerblock.util.PointerState;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3222;
import net.minecraft.class_3619;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

public class PointerBlock extends class_2237 {
    public static final class_2753 FACING = class_2741.field_12481;

    public PointerBlock(class_2251 settings) {
        // nonOpaque() を追加することで、このブロックが透明化された時に隣接するブロックの面が表示されるようになる
        super(settings.method_50012(class_3619.field_15972).method_22488());
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        if (!world.field_9236 && world.method_8503() != null) {
            String defaultName = pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260();
            PointerDataManager.addPointer(world.method_8503(), pos, defaultName, state.method_11654(FACING).method_10161());
        }
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            if (!world.field_9236 && world.method_8503() != null) {
                PointerDataManager.removePointer(world.method_8503(), pos);
            }
            super.method_9536(state, world, pos, newState, moved);
        }
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof PointerBlockEntity pbe) {
                class_2540 buf = PacketByteBufs.create();
                buf.method_10807(pos);
                buf.method_10814(pbe.getPointerName());
                buf.method_10807(pbe.getTargetPos());
                buf.writeInt(state.method_11654(FACING).method_10161());
                ServerPlayNetworking.send((class_3222) player, PointerPackets.OPEN_POINTER_SCREEN, buf);
            }
        }
        return class_1269.field_5812;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PointerBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return PointerState.transparency ? class_2464.field_11455 : class_2464.field_11458;
    }
}