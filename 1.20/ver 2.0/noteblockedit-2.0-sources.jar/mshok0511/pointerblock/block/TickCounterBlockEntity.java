package mshok0511.pointerblock.block;

import mshok0511.pointerblock.PointerBlockMod;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class TickCounterBlockEntity extends class_2586 {
    private int delay = 0;

    public TickCounterBlockEntity(class_2338 pos, class_2680 state) {
        super(PointerBlockMod.TICK_COUNTER_BLOCK_ENTITY_TYPE, pos, state);
    }

    public int getDelay() { return delay; }
    public void setDelay(int delay) {
        this.delay = Math.max(0, Math.min(8, delay));
        method_5431();
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        this.delay = nbt.method_10550("Delay");
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        nbt.method_10569("Delay", delay);
        super.method_11007(nbt);
    }
}