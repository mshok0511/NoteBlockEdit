package mshok0511.pointerblock.block;

import mshok0511.pointerblock.network.PointerPackets;
import mshok0511.pointerblock.util.PointerDataManager;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3619;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class TickCounterBlock extends class_2237 {
    public static final class_2746 POWERED = class_2741.field_12484;

    public TickCounterBlock(class_2251 settings) {
        super(settings.method_50012(class_3619.field_15972));
        this.method_9590(this.field_10647.method_11664().method_11657(POWERED, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(POWERED);
    }

    @Override
    public boolean method_9506(class_2680 state) { return true; }

    @Override
    public int method_9524(class_2680 state, class_1922 world, class_2338 pos, class_2350 direction) {
        return state.method_11654(POWERED) ? 15 : 0;
    }

    @Override
    public int method_9603(class_2680 state, class_1922 world, class_2338 pos, class_2350 direction) {
        return state.method_11654(POWERED) ? 15 : 0;
    }

    // 設置時にJSONへ保存
    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        if (!world.field_9236 && world.method_8503() != null) {
            PointerDataManager.addTickCounter(world.method_8503(), pos, 0); // 初期遅延0で保存
        }
    }

    // 破壊時にJSONから削除
    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            if (!world.field_9236 && world.method_8503() != null) {
                PointerDataManager.removeTickCounter(world.method_8503(), pos);
            }
            super.method_9536(state, world, pos, newState, moved);
        }
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof TickCounterBlockEntity tbe) {
                class_2540 buf = PacketByteBufs.create();
                buf.method_10807(pos);
                buf.writeInt(tbe.getDelay());
                ServerPlayNetworking.send((class_3222) player, PointerPackets.OPEN_TICK_COUNTER, buf);
            }
        }
        return class_1269.field_5812;
    }

    @Override
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (!state.method_11654(POWERED)) {
            world.method_8652(pos, state.method_11657(POWERED, true), 3);
            updateNeighbors(world, pos);
            world.method_39279(pos, this, 20);
        } else {
            world.method_8652(pos, state.method_11657(POWERED, false), 3);
            updateNeighbors(world, pos);
        }
    }

    private void updateNeighbors(class_1937 world, class_2338 pos) {
        world.method_8452(pos, this);
        for (class_2350 direction : class_2350.values()) {
            world.method_8452(pos.method_10093(direction), this);
        }
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new TickCounterBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) { return class_2464.field_11458; }
}