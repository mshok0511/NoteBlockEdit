package mshok0511.pointerblock.util;

import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public class PointerState extends class_18 {
    public static boolean transparency = false;

    public static PointerState fromNbt(class_2487 nbt) {
        PointerState state = new PointerState();
        transparency = nbt.method_10577("transparency");
        return state;
    }

    @Override
    public class_2487 method_75(class_2487 nbt) {
        nbt.method_10556("transparency", transparency);
        return nbt;
    }

    public static PointerState getServerState(MinecraftServer server) {
        class_3218 world = server.method_3847(class_1937.field_25179);
        if (world == null) return null;
        return world.method_17983()
                .method_17924(PointerState::fromNbt, PointerState::new, "pointer_block_data");
    }

    public static void markDirty(MinecraftServer server) {
        PointerState state = getServerState(server);
        if (state != null) {
            state.method_78(true);
        }
    }
}