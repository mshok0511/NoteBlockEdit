package mshok0511.pointerblock.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2338;
import net.minecraft.server.MinecraftServer;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PointerDataManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path POINTER_PATH = FabricLoader.getInstance().getConfigDir().resolve("pointerlist.json");
    private static final Path TICK_PATH = FabricLoader.getInstance().getConfigDir().resolve("tickcounterlist.json");

    private static Map<String, Map<String, int[]>> pointerData = new HashMap<>();
    private static Map<String, Map<String, int[]>> tickData = new HashMap<>();

    // --- コピー＆ペースト用クリップボード (方向対応版) ---
    public static class TickCounterClipboardEntry {
        // horizontalOffset: ポインターの向きに対して右方向への距離
        // verticalOffset: 上方向への距離
        public final int horizontalOffset, verticalOffset, delay;

        public TickCounterClipboardEntry(int h, int v, int d) {
            this.horizontalOffset = h;
            this.verticalOffset = v;
            this.delay = d;
        }
    }

    private static List<TickCounterClipboardEntry> clipboard = new ArrayList<>();

    public static void setClipboard(List<TickCounterClipboardEntry> data) {
        clipboard = new ArrayList<>(data);
    }

    public static List<TickCounterClipboardEntry> getClipboard() {
        return clipboard;
    }
    // --------------------------------------------------

    public static void loadAll() {
        Map<String, Map<String, int[]>> p = load(POINTER_PATH, new TypeToken<>() {
        });
        if (p != null) pointerData = p;

        Map<String, Map<String, int[]>> t = load(TICK_PATH, new TypeToken<>() {
        });
        if (t != null) tickData = t;
    }

    private static <T> T load(Path path, TypeToken<T> token) {
        if (!Files.exists(path)) return null;
        try (Reader r = Files.newBufferedReader(path)) {
            return GSON.fromJson(r, token.getType());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean isNameDuplicate(MinecraftServer s, String name, class_2338 excludePos) {
        String w = s.method_27728().method_150();
        Map<String, int[]> worldPointers = pointerData.get(w);
        if (worldPointers == null || !worldPointers.containsKey(name)) return false;
        int[] data = worldPointers.get(name);
        return !(data[0] == excludePos.method_10263() && data[1] == excludePos.method_10264() && data[2] == excludePos.method_10260());
    }

    public static void addPointer(MinecraftServer s, class_2338 p, String name, int f) {
        String w = s.method_27728().method_150();
        Map<String, int[]> worldPointers = pointerData.computeIfAbsent(w, k -> new HashMap<>());
        worldPointers.entrySet().removeIf(entry -> {
            int[] d = entry.getValue();
            return d[0] == p.method_10263() && d[1] == p.method_10264() && d[2] == p.method_10260();
        });
        worldPointers.put(name, new int[]{p.method_10263(), p.method_10264(), p.method_10260(), f});
        save(POINTER_PATH, pointerData);
    }

    public static void removePointer(MinecraftServer s, class_2338 p) {
        String w = s.method_27728().method_150();
        Map<String, int[]> worldPointers = pointerData.get(w);
        if (worldPointers != null) {
            worldPointers.entrySet().removeIf(entry -> {
                int[] d = entry.getValue();
                return d[0] == p.method_10263() && d[1] == p.method_10264() && d[2] == p.method_10260();
            });
            save(POINTER_PATH, pointerData);
        }
    }

    public static void addTickCounter(MinecraftServer s, class_2338 p, int delay) {
        String w = s.method_27728().method_150();
        String key = p.method_10263() + "," + p.method_10264() + "," + p.method_10260();
        tickData.computeIfAbsent(w, k -> new HashMap<>()).put(key, new int[]{p.method_10263(), p.method_10264(), p.method_10260(), delay});
        save(TICK_PATH, tickData);
    }

    public static void removeTickCounter(MinecraftServer s, class_2338 p) {
        String w = s.method_27728().method_150();
        String key = p.method_10263() + "," + p.method_10264() + "," + p.method_10260();
        if (tickData.containsKey(w)) {
            tickData.get(w).remove(key);
            save(TICK_PATH, tickData);
        }
    }

    public static Map<String, int[]> getWorldPointers(MinecraftServer s) {
        return pointerData.getOrDefault(s.method_27728().method_150(), new HashMap<>());
    }

    public static Map<String, int[]> getWorldTickCounters(MinecraftServer s) {
        return tickData.getOrDefault(s.method_27728().method_150(), new HashMap<>());
    }

    private static void save(Path p, Object d) {
        try (Writer w = Files.newBufferedWriter(p)) {
            GSON.toJson(d, w);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}