package mshok0511.pointerblock;

import mshok0511.pointerblock.block.PointerBlock;
import mshok0511.pointerblock.block.PointerBlockEntity;
import mshok0511.pointerblock.block.TickCounterBlock;
import mshok0511.pointerblock.block.TickCounterBlockEntity;
import mshok0511.pointerblock.command.NbeCommands;
import mshok0511.pointerblock.network.PointerPackets;
import mshok0511.pointerblock.util.PointerDataManager;
import mshok0511.pointerblock.util.PointerState;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1747;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class PointerBlockMod implements ModInitializer {
    public static final String MOD_ID = "noteblockedit";

    public static final class_2248 POINTER_BLOCK = new PointerBlock(FabricBlockSettings.copyOf(class_2246.field_10340));
    public static final class_1747 POINTER_BLOCK_ITEM = new class_1747(POINTER_BLOCK, new FabricItemSettings());
    public static final class_2591<PointerBlockEntity> POINTER_BLOCK_ENTITY_TYPE = class_2378.method_10230(
            class_7923.field_41181,
            new class_2960(MOD_ID, "pointer_block_entity"),
            FabricBlockEntityTypeBuilder.create(PointerBlockEntity::new, POINTER_BLOCK).build()
    );

    public static final class_2248 TICK_COUNTER_BLOCK = new TickCounterBlock(FabricBlockSettings.copyOf(class_2246.field_10340));
    public static final class_1747 TICK_COUNTER_ITEM = new class_1747(TICK_COUNTER_BLOCK, new FabricItemSettings());
    public static final class_2591<TickCounterBlockEntity> TICK_COUNTER_BLOCK_ENTITY_TYPE = class_2378.method_10230(
            class_7923.field_41181,
            new class_2960(MOD_ID, "tick_counter_entity"),
            FabricBlockEntityTypeBuilder.create(TickCounterBlockEntity::new, TICK_COUNTER_BLOCK).build()
    );

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTING.register(server -> PointerDataManager.loadAll());
        ServerLifecycleEvents.SERVER_STARTED.register(PointerState::getServerState);
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> NbeCommands.register(dispatcher));

        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "pointer_block"), POINTER_BLOCK);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "pointer_block"), POINTER_BLOCK_ITEM);
        class_2378.method_10230(class_7923.field_41175, new class_2960(MOD_ID, "tick_counter_block"), TICK_COUNTER_BLOCK);
        class_2378.method_10230(class_7923.field_41178, new class_2960(MOD_ID, "tick_counter_block"), TICK_COUNTER_ITEM);

        ServerPlayNetworking.registerGlobalReceiver(PointerPackets.SAVE_POINTER_DATA, (server, player, handler, buf, responseSender) -> {
            class_2338 pos = buf.method_10811();
            String name = buf.method_19772();
            class_2338 targetPos = buf.method_10811();
            int facingIndex = buf.readInt();

            server.execute(() -> {
                if (PointerDataManager.isNameDuplicate(server, name, pos)) {
                    player.method_7353(class_2561.method_43470("§cエラー: 「" + name + "」は既に他のポインターで使用されています。"), false);
                    return;
                }
                class_1937 world = player.method_37908();
                if (world.method_8321(pos) instanceof PointerBlockEntity pbe) {
                    pbe.setPointerName(name);
                    pbe.setTargetPos(targetPos);
                    pbe.method_5431();
                    class_2680 state = world.method_8320(pos);
                    if (state.method_28498(PointerBlock.FACING)) {
                        class_2350 newFacing = class_2350.method_10139(facingIndex);
                        world.method_8652(pos, state.method_11657(PointerBlock.FACING, newFacing), 3);
                        PointerDataManager.addPointer(server, pos, name, facingIndex);
                    }
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(PointerPackets.SAVE_TICK_COUNTER, (server, player, handler, buf, responseSender) -> {
            class_2338 pos = buf.method_10811();
            int delay = buf.readInt();
            server.execute(() -> {
                if (player.method_37908().method_8321(pos) instanceof TickCounterBlockEntity tbe) {
                    tbe.setDelay(delay);
                    PointerDataManager.addTickCounter(server, pos, delay);
                }
            });
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_2540 buf = PacketByteBufs.create();
            buf.writeBoolean(PointerState.transparency);
            // buf.writeInt(0); // 個別座標データも不要ならここで 0 を送る
            sender.sendPacket(PointerPackets.SYNC_SETTINGS, buf);
        });
    }
}