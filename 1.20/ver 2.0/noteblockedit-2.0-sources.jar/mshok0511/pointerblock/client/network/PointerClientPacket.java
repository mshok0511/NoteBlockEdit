package mshok0511.pointerblock.client.network;

import mshok0511.pointerblock.client.screen.PointerBlockScreen;
import mshok0511.pointerblock.client.screen.TickCounterScreen;
import mshok0511.pointerblock.network.PointerPackets;
import mshok0511.pointerblock.util.PointerState;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_310;

public class PointerClientPacket {
    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(PointerPackets.OPEN_POINTER_SCREEN, (client, handler, buf, responseSender) -> {
            class_2338 pos = buf.method_10811();
            String currentName = buf.method_19772();
            class_2338 targetPos = buf.method_10811();
            int facingIndex = buf.readInt();
            client.execute(() -> class_310.method_1551().method_1507(new PointerBlockScreen(pos, currentName, targetPos, facingIndex)));
        });

        ClientPlayNetworking.registerGlobalReceiver(PointerPackets.SYNC_SETTINGS, (client, handler, buf, responseSender) -> {
            boolean transparency = buf.readBoolean();
            client.execute(() -> {
                PointerState.transparency = transparency;
                if (client.field_1769 != null) {
                    client.field_1769.method_3279();
                }
            });
        });

        ClientPlayNetworking.registerGlobalReceiver(PointerPackets.OPEN_TICK_COUNTER, (client, handler, buf, responseSender) -> {
            class_2338 pos = buf.method_10811();
            int currentDelay = buf.readInt();
            client.execute(() -> class_310.method_1551().method_1507(new TickCounterScreen(pos, currentDelay)));
        });
    }
}