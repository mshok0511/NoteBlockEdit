package mshok0511.pointerblock.client.screen;

import mshok0511.pointerblock.network.PointerPackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class TickCounterScreen extends class_437 {
    private final class_2338 pos;
    private final int initialDelay;
    private class_342 delayField;

    public TickCounterScreen(class_2338 pos, int currentDelay) {
        super(class_2561.method_43470("Tick Counter Settings"));
        this.pos = pos;
        this.initialDelay = currentDelay;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        this.delayField = new class_342(this.field_22793, centerX - 25, 80, 50, 20, class_2561.method_43473());
        this.delayField.method_1852(String.valueOf(initialDelay));
        this.delayField.method_1890(s -> s.matches("^\\d*$"));
        this.method_37063(this.delayField);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("-"), b -> adjustDelay(-1)).method_46434(centerX - 50, 80, 20, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("+"), b -> adjustDelay(1)).method_46434(centerX + 30, 80, 20, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("完了"), b -> saveAndClose()).method_46434(centerX - 105, 120, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("閉じる"), b -> this.method_25419()).method_46434(centerX + 5, 120, 100, 20).method_46431());
    }

    private void adjustDelay(int amount) {
        try {
            int current = Integer.parseInt(delayField.method_1882());
            delayField.method_1852(String.valueOf(Math.max(0, Math.min(8, current + amount))));
        } catch (NumberFormatException ignored) {}
    }

    private void saveAndClose() {
        try {
            int val = Math.max(0, Math.min(8, Integer.parseInt(delayField.method_1882())));
            class_2540 buf = PacketByteBufs.create();
            buf.method_10807(pos);
            buf.writeInt(val);
            ClientPlayNetworking.send(PointerPackets.SAVE_TICK_COUNTER, buf);
            this.method_25419();
        } catch (NumberFormatException ignored) {}
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 40, 0xFFFFFF);
        context.method_25300(this.field_22793, "遅延設定 (0-8 tick):", this.field_22789 / 2, 65, 0xA0A0A0);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}