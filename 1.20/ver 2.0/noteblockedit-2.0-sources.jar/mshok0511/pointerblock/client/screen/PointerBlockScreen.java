package mshok0511.pointerblock.client.screen;

import mshok0511.pointerblock.network.PointerPackets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class PointerBlockScreen extends class_437 {
    private final class_2338 blockPos;
    private final String initialName;
    private final class_2338 initialTargetPos;

    private class_342 nameField;
    private class_342 xField, yField, zField;
    private class_2350 currentFacing;

    public PointerBlockScreen(class_2338 pos, String name, class_2338 targetPos, int facingIndex) {
        super(class_2561.method_43470("Pointer Settings"));
        this.blockPos = pos;
        this.initialName = name;
        this.initialTargetPos = targetPos;
        this.currentFacing = class_2350.method_10139(facingIndex);
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;

        this.nameField = new class_342(this.field_22793, centerX - 100, 45, 200, 20, class_2561.method_43473());
        this.nameField.method_1852(initialName);
        // 要件4-2: 日本語・全角文字入力を制限 (ASCIIのみ許可)
        this.nameField.method_1890(s -> s.matches("^[\\x00-\\x7F]*$"));
        this.method_37063(this.nameField);

        this.xField = new class_342(this.field_22793, centerX - 100, 85, 60, 20, class_2561.method_43473());
        this.yField = new class_342(this.field_22793, centerX - 30, 85, 60, 20, class_2561.method_43473());
        this.zField = new class_342(this.field_22793, centerX + 40, 85, 60, 20, class_2561.method_43473());

        // 要件4-3: 数字以外を入力できないようにする
        this.xField.method_1890(s -> s.matches("^-?\\d*$"));
        this.yField.method_1890(s -> s.matches("^-?\\d*$"));
        this.zField.method_1890(s -> s.matches("^-?\\d*$"));

        this.xField.method_1852(String.valueOf(initialTargetPos.method_10263()));
        this.yField.method_1852(String.valueOf(initialTargetPos.method_10264()));
        this.zField.method_1852(String.valueOf(initialTargetPos.method_10260()));

        this.method_37063(this.xField);
        this.method_37063(this.yField);
        this.method_37063(this.zField);

        class_4185 facingButton = class_4185.method_46430(class_2561.method_43470("向き: " + currentFacing.method_15434().toUpperCase()), button -> {
            this.currentFacing = this.currentFacing.method_10170();
            button.method_25355(class_2561.method_43470("向き: " + currentFacing.method_15434().toUpperCase()));
        }).method_46434(centerX - 100, 125, 200, 20).method_46431();
        this.method_37063(facingButton);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("完了"), b -> saveAndClose()).method_46434(centerX - 105, 160, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("キャンセル"), b -> this.method_25419()).method_46434(centerX + 5, 160, 100, 20).method_46431());
    }

    private void saveAndClose() {
        try {
            class_2540 buf = PacketByteBufs.create();
            buf.method_10807(blockPos);
            buf.method_10814(nameField.method_1882());
            int tx = Integer.parseInt(xField.method_1882());
            int ty = Integer.parseInt(yField.method_1882());
            int tz = Integer.parseInt(zField.method_1882());
            buf.method_10807(new class_2338(tx, ty, tz));
            buf.writeInt(currentFacing.method_10161());
            ClientPlayNetworking.send(PointerPackets.SAVE_POINTER_DATA, buf);
            this.method_25419();
        } catch (NumberFormatException e) {
            this.method_25419();
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);
        int centerX = this.field_22789 / 2;
        context.method_27534(this.field_22793, this.field_22785, centerX, 15, 0xFFFFFF);
        context.method_25303(this.field_22793, "ポインター名称:", centerX - 100, 33, 0xA0A0A0);
        context.method_25303(this.field_22793, "ターゲット座標 (X/Y/Z):", centerX - 100, 73, 0xA0A0A0);
        context.method_25303(this.field_22793, "ポインターの向き:", centerX - 100, 113, 0xA0A0A0);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}