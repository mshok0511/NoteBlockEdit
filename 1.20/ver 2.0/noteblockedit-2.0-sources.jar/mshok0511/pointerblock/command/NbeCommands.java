package mshok0511.pointerblock.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import mshok0511.pointerblock.PointerBlockMod;
import mshok0511.pointerblock.block.TickCounterBlockEntity;
import mshok0511.pointerblock.network.PointerPackets;
import mshok0511.pointerblock.util.PointerDataManager;
import mshok0511.pointerblock.util.PointerState;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class NbeCommands {
    private static final SuggestionProvider<class_2168> SUGGESTION_PROVIDER = (context, builder) -> class_2172.method_9265(PointerDataManager.getWorldPointers(context.getSource().method_9211()).keySet(), builder);

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("nbe")
                .then(method_9247("getPointerBlock").executes(context -> giveItem(context.getSource(), new class_1799(PointerBlockMod.POINTER_BLOCK_ITEM))))
                .then(method_9247("getTickCounterBlock").executes(context -> giveItem(context.getSource(), new class_1799(PointerBlockMod.TICK_COUNTER_ITEM))))

                .then(method_9247("pointerTeleport").then(method_9244("name", StringArgumentType.string()).suggests(SUGGESTION_PROVIDER).executes(context -> {
                    String name = StringArgumentType.getString(context, "name");
                    Map<String, int[]> pointers = PointerDataManager.getWorldPointers(context.getSource().method_9211());
                    if (pointers.containsKey(name) && context.getSource().method_44023() != null) {
                        int[] d = pointers.get(name);
                        context.getSource().method_44023().method_20620(d[0] + 0.5, d[1] + 1.0, d[2] + 0.5);
                        return 1;
                    }
                    context.getSource().method_9213(class_2561.method_43470("ポインターが見つかりません: " + name));
                    return 0;
                })))

                .then(method_9247("pointerPlay").then(method_9244("name", StringArgumentType.string()).suggests(SUGGESTION_PROVIDER).executes(context -> {
                    String name = StringArgumentType.getString(context, "name");
                    class_3222 player = context.getSource().method_44023();
                    if (player != null) {
                        int count = PointerPlayRunner.execute(player, context.getSource().method_9211(), name);
                        if (count >= 0) {
                            context.getSource().method_9226(() -> class_2561.method_43470("§aポインター「" + name + "」を実行しました。(対象: " + count + "個)"), false);
                            return 1;
                        } else {
                            context.getSource().method_9213(class_2561.method_43470("ポインターが見つかりません: " + name));
                        }
                    }
                    return 0;
                })))

                .then(method_9247("pointerTransparency").then(method_9244("value", BoolArgumentType.bool()).executes(context -> {
                    PointerState.transparency = BoolArgumentType.getBool(context, "value");
                    PointerState.markDirty(context.getSource().method_9211());
                    syncTransparency(context.getSource());
                    return 1;
                })))

                .then(method_9247("pointerList").executes(context -> {
                    Map<String, int[]> pointers = PointerDataManager.getWorldPointers(context.getSource().method_9211());
                    context.getSource().method_9226(() -> class_2561.method_43470("§6--- ポインター一覧 ---"), false);
                    pointers.forEach((name, data) -> context.getSource().method_9226(() -> class_2561.method_43470("§e- " + name + " §7(X:" + data[0] + " Y:" + data[1] + " Z:" + data[2] + ")"), false));
                    return 1;
                }))

                // --- コピー機能 (JSONを読み取るためチャンク未ロードでもOK) ---
                .then(method_9247("tickCounterBlockCopy").then(method_9244("name", StringArgumentType.string()).suggests(SUGGESTION_PROVIDER).executes(context -> {
                    String name = StringArgumentType.getString(context, "name");
                    MinecraftServer server = context.getSource().method_9211();
                    Map<String, int[]> pointers = PointerDataManager.getWorldPointers(server);
                    if (!pointers.containsKey(name)) { context.getSource().method_9213(class_2561.method_43470("ポインターが見つかりません: " + name)); return 0; }

                    int[] pData = pointers.get(name);
                    class_2338 pPos = new class_2338(pData[0], pData[1], pData[2]);
                    class_2350 facing = class_2350.method_10139(pData[3]);

                    Map<String, int[]> allTickCounters = PointerDataManager.getWorldTickCounters(server);
                    List<PointerDataManager.TickCounterClipboardEntry> newClipboard = new ArrayList<>();

                    for (int[] tData : allTickCounters.values()) {
                        if (isInArea(pPos, facing, tData[0], tData[1], tData[2])) {
                            int hOffset = getHorizontalOffset(pPos, facing, tData[0], tData[2]);
                            int vOffset = tData[1] - pPos.method_10264();
                            newClipboard.add(new PointerDataManager.TickCounterClipboardEntry(hOffset, vOffset, tData[3]));
                        }
                    }
                    PointerDataManager.setClipboard(newClipboard);
                    context.getSource().method_9226(() -> class_2561.method_43470("§aコピー完了 (" + newClipboard.size() + "個)"), false);
                    return 1;
                })))

                // --- ペースト機能 (強制チャンクロード処理を追加) ---
                .then(method_9247("tickCounterBlockPaste").then(method_9244("name", StringArgumentType.string()).suggests(SUGGESTION_PROVIDER).executes(context -> {
                    String name = StringArgumentType.getString(context, "name");
                    MinecraftServer server = context.getSource().method_9211();
                    Map<String, int[]> pointers = PointerDataManager.getWorldPointers(server);
                    List<PointerDataManager.TickCounterClipboardEntry> clipboard = PointerDataManager.getClipboard();

                    if (clipboard.isEmpty()) { context.getSource().method_9213(class_2561.method_43470("クリップボードが空です")); return 0; }
                    if (!pointers.containsKey(name)) { context.getSource().method_9213(class_2561.method_43470("ポインターが見つかりません")); return 0; }

                    int[] pData = pointers.get(name);
                    class_2338 pPos = new class_2338(pData[0], pData[1], pData[2]);
                    class_2350 facing = class_2350.method_10139(pData[3]);
                    class_3218 world = (class_3218) context.getSource().method_9225();

                    int count = 0;
                    for (PointerDataManager.TickCounterClipboardEntry entry : clipboard) {
                        class_2338 targetPos = getRelativePosFromOffset(pPos, facing, entry.horizontalOffset, entry.verticalOffset);

                        // ★重要: チャンクを強制的にロードして設置を確実にする
                        world.method_22350(targetPos);

                        world.method_8652(targetPos, PointerBlockMod.TICK_COUNTER_BLOCK.method_9564(), 3);
                        if (world.method_8321(targetPos) instanceof TickCounterBlockEntity tbe) {
                            tbe.setDelay(entry.delay);
                            PointerDataManager.addTickCounter(server, targetPos, entry.delay);
                            count++;
                        }
                    }
                    final int finalCount = count;
                    context.getSource().method_9226(() -> class_2561.method_43470("§aペースト完了 (" + finalCount + "個)"), false);
                    return 1;
                })))
        );
    }

    private static void syncTransparency(class_2168 source) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeBoolean(PointerState.transparency);
        source.method_9211().method_3760().method_14571().forEach(p -> ServerPlayNetworking.send(p, PointerPackets.SYNC_SETTINGS, buf));
    }

    private static int getHorizontalOffset(class_2338 pPos, class_2350 facing, int tx, int tz) {
        return switch (facing) {
            case field_11043 -> tx - pPos.method_10263();
            case field_11035 -> pPos.method_10263() - tx;
            case field_11039 -> pPos.method_10260() - tz;
            case field_11034 -> tz - pPos.method_10260();
            default -> 0;
        };
    }

    private static class_2338 getRelativePosFromOffset(class_2338 pPos, class_2350 facing, int hOffset, int vOffset) {
        int ty = pPos.method_10264() + vOffset;
        return switch (facing) {
            case field_11043 -> new class_2338(pPos.method_10263() + hOffset, ty, pPos.method_10260());
            case field_11035 -> new class_2338(pPos.method_10263() - hOffset, ty, pPos.method_10260());
            case field_11039 -> new class_2338(pPos.method_10263(), ty, pPos.method_10260() - hOffset);
            case field_11034 -> new class_2338(pPos.method_10263(), ty, pPos.method_10260() + hOffset);
            default -> pPos;
        };
    }

    private static boolean isInArea(class_2338 pPos, class_2350 facing, int tx, int ty, int tz) {
        boolean yInRange = (ty >= pPos.method_10264() - 55 && ty <= pPos.method_10264() + 55);
        if (facing == class_2350.field_11034 || facing == class_2350.field_11039) {
            return (tx == pPos.method_10263()) && yInRange && (tz >= pPos.method_10260() - 55 && tz <= pPos.method_10260() + 55);
        } else {
            return (tz == pPos.method_10260()) && yInRange && (tx >= pPos.method_10263() - 55 && tx <= pPos.method_10263() + 55);
        }
    }

    private static int giveItem(class_2168 source, class_1799 stack) {
        class_3222 player = source.method_44023();
        if (player == null) return 0;
        if (player.method_31548().method_7376() != -1 && player.method_31548().method_7376() < 9) {
            player.method_31548().method_7394(stack);
        } else if (player.method_6079().method_7960()) {
            player.method_6122(class_1268.field_5810, stack);
        } else {
            player.method_7353(class_2561.method_43470("§cホットバーとオフハンドが埋まっています。"), false);
            return 0;
        }
        return 1;
    }
}