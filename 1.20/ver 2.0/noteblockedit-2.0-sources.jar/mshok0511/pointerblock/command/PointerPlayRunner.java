package mshok0511.pointerblock.command;

import mshok0511.pointerblock.PointerBlockMod;
import mshok0511.pointerblock.util.PointerDataManager;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Map;

public class PointerPlayRunner {

    /**
     * 要件8-4に基づき、指定されたポインター名称から領域内のティックカウンターを探索し、実行します。
     */
    public static int execute(class_3222 player, MinecraftServer server, String pointerName) {
        // 1. JSONからポインターのデータを取得
        Map<String, int[]> allPointers = PointerDataManager.getWorldPointers(server);
        if (!allPointers.containsKey(pointerName)) return -1; // ポインター名が見つからない場合

        int[] pData = allPointers.get(pointerName);
        class_2338 pPos = new class_2338(pData[0], pData[1], pData[2]);
        int facingIndex = pData[3];
        class_2350 facing = class_2350.method_10139(facingIndex);
        class_3218 world = player.method_51469();

        // 2. ポインター位置へテレポート
        player.method_14251(world, pPos.method_10263() + 0.5, pPos.method_10264() + 1.0, pPos.method_10260() + 0.5, player.method_36454(), player.method_36455());

        // 3. JSONから全ティックカウンターを取得して探索
        Map<String, int[]> allTickCounters = PointerDataManager.getWorldTickCounters(server);
        int foundCount = 0;

        for (int[] tData : allTickCounters.values()) {
            int tx = tData[0];
            int ty = tData[1];
            int tz = tData[2];
            int delay = tData[3];

            boolean isInArea = false;

            // Y座標の判定 (±55ブロック以内)
            boolean yInRange = (ty >= pPos.method_10264() - 55 && ty <= pPos.method_10264() + 55);

            if (facing == class_2350.field_11034 || facing == class_2350.field_11039) {
                // 東西向き：Xが同じ、Zが±55以内
                boolean xMatch = (tx == pPos.method_10263());
                boolean zInRange = (tz >= pPos.method_10260() - 55 && tz <= pPos.method_10260() + 55);
                if (xMatch && yInRange && zInRange) isInArea = true;
            } else {
                // 南北向き：Zが同じ、Xが±55以内
                boolean zMatch = (tz == pPos.method_10260());
                boolean xInRange = (tx >= pPos.method_10263() - 55 && tx <= pPos.method_10263() + 55);
                if (zMatch && yInRange && xInRange) isInArea = true;
            }

            // 4. 領域内の場合の処理
            if (isInArea) {
                class_2338 targetPos = new class_2338(tx, ty, tz);

                // チャンクを強制的にロード（実行を確実にするため）
                world.method_22350(targetPos);
                class_2680 tState = world.method_8320(targetPos);

                // 対象がティックカウンターブロックであれば信号を予約
                if (tState.method_27852(PointerBlockMod.TICK_COUNTER_BLOCK)) {
                    // 要件8-4: 8tickの溜め + 個別設定(0-8tick)
                    int totalDelay = 8 + delay;
                    world.method_39279(targetPos, tState.method_26204(), totalDelay);
                    foundCount++;
                }
            }
        }

        return foundCount;
    }
}